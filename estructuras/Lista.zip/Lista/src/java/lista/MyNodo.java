/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lista;

/**
 *
 * @author gerardo
 */
public class MyNodo {
    protected String nombre;
    protected int id;
    public MyNodo siguiente;
    
    public MyNodo(String nombre,int id){
        this.nombre=nombre;
        this.id=id;
    }
}
