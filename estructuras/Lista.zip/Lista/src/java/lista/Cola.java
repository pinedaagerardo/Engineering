/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package lista;

/**
 *
 * @author gerardo
 */
public class Cola {
    /**Atributo que contiene todos los nodos de la cola*/
    public MyNodo tope; //es la cabeza.
    /**Un contador para saber cuantos nodos se han ingresado a la cola*/
    
    /** Crea una nueva instancia de Cola */
    public Cola() {
        tope = null;
    }
    
    /** Verifica si la cola esta vacia
     * @return true si la cola esta vacia, si no, false
     */
    public boolean esVacia(){
        return tope == null;
    }

    /** Borra todos los datos de la cola */
    public void vaciar(){
        tope = null;    
    }

    /** Inserta datos en la cola
     * @param nombre El nombre a guardar
     * @param id El id a guardar
     */
    public void push(String nombre,int id){
        if(esVacia())
            tope = new MyNodo(nombre,id);
        else{
            MyNodo temp=tope;
            while(temp.siguiente!=null)
                temp=temp.siguiente;
            temp.siguiente=new MyNodo(nombre,id);
        }
    }

    /** Metodo que borra el primer nodo para que el segundo tome su lugar
     * @exception ColaVacia si la cola esta vacia
     */
    public void pop() throws Exception{
        if(esVacia())
            throw new Exception("Cola vacia");

        tope = tope.siguiente;
    }
    
    /** Metodo que muestra el contenido de un MyNodo*/
    public String mostrar(MyNodo n){
        return n.nombre+", "+Integer.toString(n.id);
    }
}
