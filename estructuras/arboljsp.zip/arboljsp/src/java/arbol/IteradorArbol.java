/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package arbol;

import java.util.Iterator;
import java.util.Stack;

/**
 *
 * @author gerardo
 */
abstract class IteradorArbol<E> implements Iterator<E> {
    private Stack cola;
    NABinario sig;
    
    public IteradorArbol(){
        cola=new Stack();
        sig=null;
    }
    
    public boolean hasNext(){
        return (sig!=null);
    }
    
    public void remove(){
        throw new UnsupportedOperationException("falta programar remove");
    }
    
    public E nextValuePre() {
        if(sig==null) return null;
        else{
            E elem=(E)sig.getElement();
            sig=calcularPreSig();
            return elem;
        }
    }
    
    public E nextKeyPre() {
        if(sig==null) return null;
        else{
            E elem=(E)sig.getKey();
            sig=calcularPreSig();
            return elem;
        }
    }
    
    public E nextValuePost() {
        if(sig==null) return null;
        else{
            E elem=(E)sig.getElement();
            sig=calcularPostSig();
            return elem;
        }
    }
    
    public E nextKeyPost() {
        if(sig==null) return null;
        else{
            E elem=(E)sig.getElement();
            sig=calcularPostSig();
            return elem;
        }
    }
    
    private NABinario calcularPreSig(){
        if(sig.izq()!=null)
            sig=(NABinario)sig.izq();
        else
            if(sig.der()!=null)
                sig=(NABinario)sig.der();
            else
                sig=null;
        
        return sig;
    }
    
    private NABinario calcularPostSig(){
        //
        return sig;
    }
}
