/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package arbol;

import java.io.Serializable;
import java.util.Iterator;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author gerardo
 */
public class bean implements Serializable {
    private ABBusqueda<String,Integer> busq=new ABBusqueda<String,Integer>();
    
    public bean(){}
    
    public void saveValores(String valor,int key){
        if(!busq.add(valor, key))
            JOptionPane.showMessageDialog(new JFrame(), "ya existe","Error",JOptionPane.ERROR_MESSAGE);
    }
    
    public String getValor(){
        //StringBuffer sb=new StringBuffer();
        busq.Orden((NABinario)busq.raiz.getHijo(Integer.valueOf(busq.raiz.llave.toString())));
        return null;//sb.substring(0);
    }
    
    public String PreOrdenValues(){
        return busq.it.PreOrdenValues();
    }
    
    public String PreOrdenKeys(){
        return busq.it.PreOrdenKeys();
    }
    
    public String PostOrdenValues(){
        StringBuffer s=new StringBuffer();
        busq.postOrden((NABinario)busq.raiz.getHijo(Integer.valueOf(busq.raiz.llave.toString())),s);
        return s.substring(0);
    }
    
    public String PostOrdenKeys(){
        StringBuffer s=new StringBuffer();
        busq.postOrdenKeys((NABinario)busq.raiz.getHijo(Integer.valueOf(busq.raiz.llave.toString())),s);
        return s.substring(0);
    }
    
    int llave(String s){
        int llave=0;
        for(int i=0;i<s.length();i++)
            llave=llave+s.charAt(i);
        
        return llave;
    }
    
    public String buscar(int k){
        return String.valueOf(busq.get(k));
    }
}
