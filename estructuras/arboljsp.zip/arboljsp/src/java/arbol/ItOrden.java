/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package arbol;

/**
 *
 * @author gerardo
 */
class ItOrden extends IteradorArbol {

    public ItOrden(NABinario n){
        super();
        sig=n;
    }
    
    
    public String PreOrdenValues(){
        StringBuffer s=new StringBuffer();
        while(hasNext()){
            s.append(nextValuePre().toString()+"   ");
        }
        if(s.length()==0)
            return null;
        return s.substring(0);
    }
    
    public String PreOrdenKeys(){
        StringBuffer s=new StringBuffer();
        while(hasNext()){
            s.append(nextKeyPre().toString()+"   ");
        }
        if(s.length()==0)
            return null;
        return s.substring(0);
    }
    
    public String PostOrdenValues(){
        StringBuffer s=new StringBuffer();
        while(hasNext()){
            s.append(nextValuePost().toString()+"   ");
        }
        if(s.length()==0)
            return null;
        return s.substring(0);
    }
    
    public String PostOrdenKeys(){
        StringBuffer s=new StringBuffer();
        while(hasNext()){
            s.append(nextValuePost().toString()+"   ");
        }
        if(s.length()==0)
            return null;
        return s.substring(0);
    }

    public Object next() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
