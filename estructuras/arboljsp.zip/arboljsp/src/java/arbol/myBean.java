/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package arbol;

import java.io.Serializable;

/**
 *
 * @author gerardo
 */
public class myBean implements Serializable{
    private String Valor;
    private int Key;
    
    public myBean(){}
    
    public void setValor(String v){
        Valor=v;
    }
    
    public void setKey(String k){
        Key=Integer.valueOf(k);
    }
    
    public String getValor(){
        return Valor;
    }
    
    public int getKey(){
        return Key;
    }
}
