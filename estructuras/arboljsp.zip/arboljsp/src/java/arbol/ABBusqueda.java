/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package arbol;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/**
 *
 * @author gerardo
 */
public class ABBusqueda<E,K> implements Arbol<E,K>,Iterable<K> {
    public ItOrden it;
    NABinario raiz;
    public boolean add(E element,K key){
        if(raiz==null){
            raiz=new NABinario(element,key);
            return true;
        }else return raiz.add(element, key);
    }
    
    public NodoArbol getRoot() {
        return raiz;
    }

    public int altura() {
        if(raiz!=null) return raiz.altura();
        else return 0;
    }
    
    public void Orden(NABinario n){
        if(n==null) return;
        //a.append(n.getElement().toString()+"   ");
        if(it==null) it=new ItOrden(n);
        //preOrden(n.der);
        //preOrden(n.izq);
    }
    
    public void postOrden(NABinario n,StringBuffer s){
        if(n!=null){
            postOrden(n.izq,s);
            postOrden(n.der,s);
            s.append(n.getElement().toString());
        }
    }
    
    public void postOrdenKeys(NABinario n,StringBuffer s){
        if(n!=null){
            postOrden(n.izq,s);
            postOrden(n.der,s);
            s.append(n.getKey().toString());
        }
    }

    public Iterator preOrden() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Iterator postOrden() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Iterator enOrden() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public int size() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean isEmpty() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean containsKey(Object key) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean containsValue(Object value) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public K get(Object key) {
        return ((K)raiz.get(Integer.parseInt(key.toString()), raiz).getElement());
    }

    public K put(E key, K value) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public K remove(Object key) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void putAll(Map<? extends E, ? extends K> m) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void clear() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Set<E> keySet() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Collection<K> values() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Set<Entry<E, K>> entrySet() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Iterator<K> iterator() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
