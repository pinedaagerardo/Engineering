/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package arbol;

/**
 *
 * @author gerardo
 */
public class NABinario<E,K> implements NodoArbol<E,K> {
    
    E elemento;
    K llave;
    NABinario izq;
    NABinario der;
    
    /** Creates a new instance of NABinario */
    public NABinario(E element,K key) {
        elemento=element;
        llave=key;
    }

    public E getElement() {
        return elemento;
    }

    public K getKey() {
        return llave;
    }

    public boolean isEqual(K key) {
        return (key.equals(this));
    }

    public NodoArbol izq() {
        return izq;
    }

    public NodoArbol der() {
        return der;
    }

    public NodoArbol getHijo(int i) {
        if(altura()==0) return null;
        else return get(i,this);
    }
    
    NodoArbol get(int i,NABinario n){
        if(n==null) return null;
        if(i==Integer.parseInt(n.getKey().toString()))
            return (NodoArbol)n;
        else
            if(Integer.parseInt(n.getKey().toString())<i) return get(i,n.der);
            else return get(i,n.izq);
    }

    public boolean esHoja() {
        return !esInterno();
    }

    public boolean esInterno() {
        return (izq==null && der==null);
    }

    public int altura() {
        int altIzq=izq!=null?izq.altura():0;
        int altDer=der!=null?der.altura():0;
        return (Math.max(altIzq,altDer)+1);
    }
    
    boolean add(E element,K key){
        if(key==getKey())
            return false;
        else
            if(Integer.parseInt(getKey().toString())<Integer.parseInt(key.toString()))
                if(der==null){
                    der=new NABinario<E,K>(element,key);
                    return true;
                } else return der.add(element,key);
            else
                if(izq==null){
                    izq=new NABinario<E,K>(element,key);
                    return true;
                } else return izq.add(element,key);
    }

}
