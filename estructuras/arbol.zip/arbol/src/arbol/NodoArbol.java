/*
 * NodoArbol.java
 *
 * Created on 31 de marzo de 2008, 10:54 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package arbol;

/**
 *
 * @author gerardo
 */
public interface NodoArbol <E,K> {
    E getElement();
    K getKey();
    boolean isEqual(K key);
    NodoArbol izq();
    NodoArbol der();
    NodoArbol getHijo(int i);
    boolean esHoja();
    boolean esInterno();
    int altura();
}
