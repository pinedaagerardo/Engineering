/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package arbol;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.swing.JTextArea;

/**
 *
 * @author gerardo
 */
public class ABBusqueda<E,K> implements Arbol<E,K> {

    NABinario raiz;
    public boolean add(E element,K key){
        if(raiz==null){
            raiz=new NABinario(element,key);
            return true;
        }else return raiz.add(element, key);
    }
    
    public NodoArbol getRoot() {
        return raiz;
    }

    public int altura() {
        if(raiz!=null) return raiz.altura();
        else return 0;
    }
    
    public void preOrden(NABinario n,JTextArea a){
        if(n==null) return;
        a.append(n.getElement().toString()+"\n");
        preOrden(n.der,a);
        preOrden(n.izq,a);
    }

    public Iterator preOrden() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Iterator postOrden() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Iterator enOrden() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public int size() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean isEmpty() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean containsKey(Object key) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public boolean containsValue(Object value) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public K get(Object key) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public K put(E key, K value) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public K remove(Object key) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void putAll(Map<? extends E, ? extends K> m) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void clear() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Set<E> keySet() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Collection<K> values() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Set<Entry<E, K>> entrySet() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
