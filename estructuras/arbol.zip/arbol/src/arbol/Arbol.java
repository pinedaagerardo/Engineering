/*
 * Arbol.java
 *
 * Created on 31 de marzo de 2008, 09:54 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package arbol;

import java.util.Iterator;
import java.util.Map;

/**
 *
 * @author gerardo
 */
public interface Arbol<E,K> extends Map <E,K> {
    NodoArbol getRoot();
    int altura();
    Iterator preOrden();
    Iterator postOrden();
    Iterator enOrden();
}
