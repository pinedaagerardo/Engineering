/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package arbol;

/**
 *
 * @author gerardo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        App a=new App();
        a.setVisible(true);
    }

}
