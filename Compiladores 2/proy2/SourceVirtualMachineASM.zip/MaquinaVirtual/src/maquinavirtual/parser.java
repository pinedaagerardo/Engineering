


package maquinavirtual;

import java_cup.runtime.*;
import java.lang.*;
import java_cup.runtime.Symbol;
import java.io.*;
import java.io.BufferedReader;

/** CUP v0.10k generated parser.
  * @version Tue Dec 08 21:07:46 CST 2009
  */
public class parser extends java_cup.runtime.lr_parser {

  /** Default constructor. */
  public parser() {super();}

  /** Constructor which sets the default scanner. */
  public parser(java_cup.runtime.Scanner s) {super(s);}

  /** Production table. */
  protected static final short _production_table[][] = 
    unpackFromStrings(new String[] {
    "\000\074\000\002\002\004\000\002\003\003\000\002\003" +
    "\004\000\002\004\003\000\002\004\003\000\002\004\003" +
    "\000\002\004\003\000\002\004\003\000\002\005\004\000" +
    "\002\005\003\000\002\006\003\000\002\006\003\000\002" +
    "\006\003\000\002\006\003\000\002\007\004\000\002\007" +
    "\003\000\002\010\003\000\002\010\003\000\002\010\003" +
    "\000\002\010\003\000\002\010\005\000\002\010\003\000" +
    "\002\010\003\000\002\010\003\000\002\010\003\000\002" +
    "\011\004\000\002\011\003\000\002\011\003\000\002\012" +
    "\003\000\002\012\003\000\002\012\003\000\002\012\003" +
    "\000\002\012\003\000\002\015\006\000\002\015\004\000" +
    "\002\016\003\000\002\016\003\000\002\016\003\000\002" +
    "\016\006\000\002\016\006\000\002\016\003\000\002\016" +
    "\003\000\002\014\003\000\002\014\003\000\002\014\003" +
    "\000\002\014\003\000\002\014\003\000\002\014\003\000" +
    "\002\014\003\000\002\014\003\000\002\014\003\000\002" +
    "\014\003\000\002\014\003\000\002\014\003\000\002\014" +
    "\003\000\002\014\003\000\002\014\003\000\002\014\003" +
    "\000\002\014\003\000\002\013\004" });

  /** Access to production table. */
  public short[][] production_table() {return _production_table;}

  /** Parse-action table. */
  protected static final short[][] _action_table = 
    unpackFromStrings(new String[] {
    "\000\113\000\120\003\036\004\041\005\024\006\064\007" +
    "\006\010\050\011\045\012\043\013\042\014\040\015\023" +
    "\016\047\017\054\020\046\021\015\022\017\023\033\036" +
    "\027\037\044\040\063\041\035\042\025\043\013\044\011" +
    "\045\026\046\030\047\020\050\005\051\010\052\057\053" +
    "\037\054\012\055\016\056\056\057\055\060\007\061\053" +
    "\062\034\064\031\001\002\000\014\002\ufffe\004\041\015" +
    "\023\016\047\017\054\001\002\000\020\024\uffcd\025\uffcd" +
    "\026\uffcd\027\uffcd\062\uffcd\063\uffcd\064\uffcd\001\002\000" +
    "\026\002\uffef\005\uffef\006\uffef\007\uffef\010\uffef\011\uffef" +
    "\012\uffef\013\uffef\014\uffef\062\uffef\001\002\000\004\002" +
    "\uffe6\001\002\000\020\024\uffcc\025\uffcc\026\uffcc\027\uffcc" +
    "\062\uffcc\063\uffcc\064\uffcc\001\002\000\020\024\uffd1\025" +
    "\uffd1\026\uffd1\027\uffd1\062\uffd1\063\uffd1\064\uffd1\001\002" +
    "\000\020\024\uffc9\025\uffc9\026\uffc9\027\uffc9\062\uffc9\063" +
    "\uffc9\064\uffc9\001\002\000\020\024\uffd2\025\uffd2\026\uffd2" +
    "\027\uffd2\062\uffd2\063\uffd2\064\uffd2\001\002\000\004\002" +
    "\ufffc\001\002\000\004\002\uffe3\001\002\000\020\024\uffc8" +
    "\025\uffc8\026\uffc8\027\uffc8\062\uffc8\063\uffc8\064\uffc8\001" +
    "\002\000\004\002\uffe2\001\002\000\020\024\uffce\025\uffce" +
    "\026\uffce\027\uffce\062\uffce\063\uffce\064\uffce\001\002\000" +
    "\004\002\000\001\002\000\014\002\ufff8\004\ufff8\015\ufff8" +
    "\016\ufff8\017\ufff8\001\002\000\014\002\ufff5\004\ufff5\015" +
    "\ufff5\016\ufff5\017\ufff5\001\002\000\026\002\ufff1\005\ufff1" +
    "\006\ufff1\007\ufff1\010\ufff1\011\ufff1\012\ufff1\013\ufff1\014" +
    "\ufff1\062\ufff1\001\002\000\020\024\uffd3\025\uffd3\026\uffd3" +
    "\027\uffd3\062\uffd3\063\uffd3\064\uffd3\001\002\000\020\024" +
    "\uffd0\025\uffd0\026\uffd0\027\uffd0\062\uffd0\063\uffd0\064\uffd0" +
    "\001\002\000\020\024\uffd7\025\uffd7\026\uffd7\027\uffd7\062" +
    "\uffd7\063\uffd7\064\uffd7\001\002\000\020\024\uffcf\025\uffcf" +
    "\026\uffcf\027\uffcf\062\uffcf\063\uffcf\064\uffcf\001\002\000" +
    "\004\030\114\001\002\000\004\002\uffe5\001\002\000\004" +
    "\002\uffe1\001\002\000\004\035\112\001\002\000\020\024" +
    "\uffd4\025\uffd4\026\uffd4\027\uffd4\062\uffd4\063\uffd4\064\uffd4" +
    "\001\002\000\120\003\036\004\041\005\024\006\064\007" +
    "\006\010\050\011\045\012\043\013\042\014\040\015\023" +
    "\016\047\017\054\020\046\021\015\022\017\023\033\036" +
    "\027\037\044\040\063\041\035\042\025\043\013\044\011" +
    "\045\026\046\030\047\020\050\005\051\010\052\057\053" +
    "\037\054\012\055\016\056\056\057\055\060\007\061\053" +
    "\062\034\064\031\001\002\000\020\024\uffca\025\uffca\026" +
    "\uffca\027\uffca\062\uffca\063\uffca\064\uffca\001\002\000\026" +
    "\002\uffe9\005\uffe9\006\uffe9\007\uffe9\010\uffe9\011\uffe9\012" +
    "\uffe9\013\uffe9\014\uffe9\062\uffe9\001\002\000\014\002\ufff7" +
    "\004\ufff7\015\ufff7\016\ufff7\017\ufff7\001\002\000\026\002" +
    "\uffea\005\uffea\006\uffea\007\uffea\010\uffea\011\uffea\012\uffea" +
    "\013\uffea\014\uffea\062\uffea\001\002\000\026\002\uffeb\005" +
    "\uffeb\006\uffeb\007\uffeb\010\uffeb\011\uffeb\012\uffeb\013\uffeb" +
    "\014\uffeb\062\uffeb\001\002\000\020\024\uffd6\025\uffd6\026" +
    "\uffd6\027\uffd6\062\uffd6\063\uffd6\064\uffd6\001\002\000\026" +
    "\002\uffec\005\uffec\006\uffec\007\uffec\010\uffec\011\uffec\012" +
    "\uffec\013\uffec\014\uffec\062\uffec\001\002\000\004\002\uffe7" +
    "\001\002\000\014\002\ufff6\004\ufff6\015\ufff6\016\ufff6\017" +
    "\ufff6\001\002\000\026\002\ufff0\005\ufff0\006\ufff0\007\ufff0" +
    "\010\ufff0\011\ufff0\012\ufff0\013\ufff0\014\ufff0\062\ufff0\001" +
    "\002\000\026\002\ufffd\005\024\006\064\007\006\010\050" +
    "\011\045\012\043\013\042\014\040\062\034\001\002\000" +
    "\004\002\107\001\002\000\004\002\ufffa\001\002\000\014" +
    "\002\ufff4\004\ufff4\015\ufff4\016\ufff4\017\ufff4\001\002\000" +
    "\004\064\106\001\002\000\020\024\uffc7\025\uffc7\026\uffc7" +
    "\027\uffc7\062\uffc7\063\uffc7\064\uffc7\001\002\000\020\024" +
    "\uffcb\025\uffcb\026\uffcb\027\uffcb\062\uffcb\063\uffcb\064\uffcb" +
    "\001\002\000\004\002\ufffb\001\002\000\004\002\uffe4\001" +
    "\002\000\026\002\ufff2\005\ufff2\006\ufff2\007\ufff2\010\ufff2" +
    "\011\ufff2\012\ufff2\013\ufff2\014\ufff2\062\ufff2\001\002\000" +
    "\020\024\uffd5\025\uffd5\026\uffd5\027\uffd5\062\uffd5\063\uffd5" +
    "\064\uffd5\001\002\000\026\002\uffee\005\uffee\006\uffee\007" +
    "\uffee\010\uffee\011\uffee\012\uffee\013\uffee\014\uffee\062\uffee" +
    "\001\002\000\020\024\073\025\074\026\075\027\067\062" +
    "\070\063\071\064\066\001\002\000\006\002\uffde\032\uffde" +
    "\001\002\000\006\002\uffd8\032\uffd8\001\002\000\006\002" +
    "\uffdd\032\uffdd\001\002\000\006\002\uffdc\032\uffdc\001\002" +
    "\000\006\002\uffdf\032\104\001\002\000\004\033\101\001" +
    "\002\000\004\033\076\001\002\000\006\002\uffd9\032\uffd9" +
    "\001\002\000\004\064\077\001\002\000\004\034\100\001" +
    "\002\000\006\002\uffda\032\uffda\001\002\000\004\064\102" +
    "\001\002\000\004\034\103\001\002\000\006\002\uffdb\032" +
    "\uffdb\001\002\000\020\024\073\025\074\026\075\027\067" +
    "\062\070\063\071\064\066\001\002\000\004\002\uffe0\001" +
    "\002\000\004\002\uffe8\001\002\000\004\002\001\001\002" +
    "\000\026\002\ufff3\005\ufff3\006\ufff3\007\ufff3\010\ufff3\011" +
    "\ufff3\012\ufff3\013\ufff3\014\ufff3\062\ufff3\001\002\000\004" +
    "\002\uffff\001\002\000\004\031\113\001\002\000\026\002" +
    "\uffed\005\uffed\006\uffed\007\uffed\010\uffed\011\uffed\012\uffed" +
    "\013\uffed\014\uffed\062\uffed\001\002\000\004\002\uffc6\001" +
    "\002\000\014\002\ufff9\004\ufff9\015\ufff9\016\ufff9\017\ufff9" +
    "\001\002" });

  /** Access to parse-action table. */
  public short[][] action_table() {return _action_table;}

  /** <code>reduce_goto</code> table. */
  protected static final short[][] _reduce_table = 
    unpackFromStrings(new String[] {
    "\000\113\000\030\003\051\004\020\005\003\006\021\007" +
    "\050\010\061\011\013\012\057\013\060\014\064\015\031" +
    "\001\001\000\004\006\114\001\001\000\002\001\001\000" +
    "\002\001\001\000\002\001\001\000\002\001\001\000\002" +
    "\001\001\000\002\001\001\000\002\001\001\000\002\001" +
    "\001\000\002\001\001\000\002\001\001\000\002\001\001" +
    "\000\002\001\001\000\002\001\001\000\002\001\001\000" +
    "\002\001\001\000\002\001\001\000\002\001\001\000\002" +
    "\001\001\000\002\001\001\000\002\001\001\000\002\001" +
    "\001\000\002\001\001\000\002\001\001\000\002\001\001" +
    "\000\002\001\001\000\030\003\110\004\020\005\003\006" +
    "\021\007\050\010\061\011\013\012\057\013\060\014\064" +
    "\015\031\001\001\000\002\001\001\000\002\001\001\000" +
    "\002\001\001\000\002\001\001\000\002\001\001\000\002" +
    "\001\001\000\002\001\001\000\002\001\001\000\002\001" +
    "\001\000\002\001\001\000\004\010\107\001\001\000\002" +
    "\001\001\000\002\001\001\000\002\001\001\000\002\001" +
    "\001\000\002\001\001\000\002\001\001\000\002\001\001" +
    "\000\002\001\001\000\002\001\001\000\002\001\001\000" +
    "\002\001\001\000\004\016\071\001\001\000\002\001\001" +
    "\000\002\001\001\000\002\001\001\000\002\001\001\000" +
    "\002\001\001\000\002\001\001\000\002\001\001\000\002" +
    "\001\001\000\002\001\001\000\002\001\001\000\002\001" +
    "\001\000\002\001\001\000\002\001\001\000\002\001\001" +
    "\000\004\016\104\001\001\000\002\001\001\000\002\001" +
    "\001\000\002\001\001\000\002\001\001\000\002\001\001" +
    "\000\002\001\001\000\002\001\001\000\002\001\001\000" +
    "\002\001\001" });

  /** Access to <code>reduce_goto</code> table. */
  public short[][] reduce_table() {return _reduce_table;}

  /** Instance of action encapsulation class. */
  protected CUP$parser$actions action_obj;

  /** Action encapsulation object initializer. */
  protected void init_actions()
    {
      action_obj = new CUP$parser$actions(this);
    }

  /** Invoke a user supplied parse action. */
  public java_cup.runtime.Symbol do_action(
    int                        act_num,
    java_cup.runtime.lr_parser parser,
    java.util.Stack            stack,
    int                        top)
    throws java.lang.Exception
  {
    /* call code in generated class */
    return action_obj.CUP$parser$do_action(act_num, parser, stack, top);
  }

  /** Indicates start state. */
  public int start_state() {return 0;}
  /** Indicates start production. */
  public int start_production() {return 0;}

  /** <code>EOF</code> Symbol index. */
  public int EOF_sym() {return 0;}

  /** <code>error</code> Symbol index. */
  public int error_sym() {return 1;}




public void syntax_error(Symbol s)
	{
            
	}

public void unrecovered_syntax_error(Symbol s)
	{
            
	}

public static void main(String args[]) throws Exception
	{
		new parser(new Yylex(new BufferedReader(new InputStreamReader(System.in)))).parse();
	}


}

/** Cup generated class to encapsulate user supplied action code.*/
class CUP$parser$actions {



  private final parser parser;

  /** Constructor */
  CUP$parser$actions(parser parser) {
    this.parser = parser;
  }

  /** Method with the actual generated action code. */
  public final java_cup.runtime.Symbol CUP$parser$do_action(
    int                        CUP$parser$act_num,
    java_cup.runtime.lr_parser CUP$parser$parser,
    java.util.Stack            CUP$parser$stack,
    int                        CUP$parser$top)
    throws java.lang.Exception
    {
      /* Symbol object for return from actions */
      java_cup.runtime.Symbol CUP$parser$result;

      /* select the action based on the action number */
      switch (CUP$parser$act_num)
        {
          /*. . . . . . . . . . . . . . . . . . . .*/
          case 59: 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(9/*etiqueta*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-1)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 58: // comando ::= PUTC 
            {
              String RESULT = null;
		int comleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int comright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String com = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		RESULT=com;
              CUP$parser$result = new java_cup.runtime.Symbol(10/*comando*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 57: // comando ::= JNE 
            {
              String RESULT = null;
		int comleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int comright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String com = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		RESULT=com;
              CUP$parser$result = new java_cup.runtime.Symbol(10/*comando*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 56: // comando ::= JE 
            {
              String RESULT = null;
		int comleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int comright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String com = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		RESULT=com;
              CUP$parser$result = new java_cup.runtime.Symbol(10/*comando*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 55: // comando ::= JGE 
            {
              String RESULT = null;
		int comleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int comright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String com = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		RESULT=com;
              CUP$parser$result = new java_cup.runtime.Symbol(10/*comando*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 54: // comando ::= JLE 
            {
              String RESULT = null;
		int comleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int comright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String com = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		RESULT=com;
              CUP$parser$result = new java_cup.runtime.Symbol(10/*comando*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 53: // comando ::= JG 
            {
              String RESULT = null;
		int comleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int comright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String com = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		RESULT=com;
              CUP$parser$result = new java_cup.runtime.Symbol(10/*comando*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 52: // comando ::= JL 
            {
              String RESULT = null;
		int comleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int comright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String com = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		RESULT=com;
              CUP$parser$result = new java_cup.runtime.Symbol(10/*comando*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 51: // comando ::= CMP 
            {
              String RESULT = null;
		int comleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int comright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String com = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		RESULT=com;
              CUP$parser$result = new java_cup.runtime.Symbol(10/*comando*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 50: 
            {
              String RESULT = null;
		int comleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int comright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String com = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		RESULT=com;
              CUP$parser$result = new java_cup.runtime.Symbol(10/*comando*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 49: // comando ::= CALL 
            {
              String RESULT = null;
		int comleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int comright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String com = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		RESULT=com;
              CUP$parser$result = new java_cup.runtime.Symbol(10/*comando*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 48: // comando ::= POP 
            {
              String RESULT = null;
		int comleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int comright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String com = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		RESULT=com;
              CUP$parser$result = new java_cup.runtime.Symbol(10/*comando*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 47: // comando ::= PUSH 
            {
              String RESULT = null;
		int comleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int comright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String com = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		RESULT=com;
              CUP$parser$result = new java_cup.runtime.Symbol(10/*comando*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 46: // comando ::= IDIV 
            {
              String RESULT = null;
		int comleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int comright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String com = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		RESULT=com;
              CUP$parser$result = new java_cup.runtime.Symbol(10/*comando*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 45: // comando ::= IMUL 
            {
              String RESULT = null;
		int comleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int comright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String com = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		RESULT=com;
              CUP$parser$result = new java_cup.runtime.Symbol(10/*comando*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 44: // comando ::= SUB 
            {
              String RESULT = null;
		int comleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int comright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String com = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		RESULT=com;
              CUP$parser$result = new java_cup.runtime.Symbol(10/*comando*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 43: // comando ::= ADD 
            {
              String RESULT = null;
		int comleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int comright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String com = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		RESULT=com;
              CUP$parser$result = new java_cup.runtime.Symbol(10/*comando*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 42: // comando ::= MOV 
            {
              String RESULT = null;
		int comleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int comright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String com = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		RESULT=com;
              CUP$parser$result = new java_cup.runtime.Symbol(10/*comando*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 41: // Param ::= PTR_HEAP 
            {
              String RESULT = null;
		int valleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int valright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String val = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		RESULT=val;
              CUP$parser$result = new java_cup.runtime.Symbol(12/*Param*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 40: // Param ::= PTR_PILA 
            {
              String RESULT = null;
		int valleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int valright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String val = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		RESULT=val;
              CUP$parser$result = new java_cup.runtime.Symbol(12/*Param*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 39: // Param ::= HEAP ACOR ID CCOR 
            {
              String RESULT = null;
		int idleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-1)).left;
		int idright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-1)).right;
		String id = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-1)).value;
		RESULT="heap["+id+"]";
              CUP$parser$result = new java_cup.runtime.Symbol(12/*Param*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-3)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 38: 
            {
              String RESULT = null;
		int idleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-1)).left;
		int idright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-1)).right;
		String id = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-1)).value;
		RESULT="pila["+id+"]";
              CUP$parser$result = new java_cup.runtime.Symbol(12/*Param*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-3)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 37: // Param ::= NUMERO 
            {
              String RESULT = null;
		int valleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int valright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String val = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		RESULT=val;
              CUP$parser$result = new java_cup.runtime.Symbol(12/*Param*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 36: // Param ::= TEMPORAL 
            {
              String RESULT = null;
		int valleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int valright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String val = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		RESULT=val;
              CUP$parser$result = new java_cup.runtime.Symbol(12/*Param*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 35: // Param ::= ID 
            {
              String RESULT = null;
		int valleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int valright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String val = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		RESULT=val;
              CUP$parser$result = new java_cup.runtime.Symbol(12/*Param*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 34: // instruccion ::= comando Param 
            {
              String RESULT = null;
		int comleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-1)).left;
		int comright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-1)).right;
		String com = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-1)).value;
		int p1left = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int p1right = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String p1 = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		
    Consola.ejecutar(com, p1, "");

              CUP$parser$result = new java_cup.runtime.Symbol(11/*instruccion*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-1)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 33: // instruccion ::= comando Param COMA Param 
            {
              String RESULT = null;
		int comleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-3)).left;
		int comright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-3)).right;
		String com = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-3)).value;
		int p1left = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-2)).left;
		int p1right = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-2)).right;
		String p1 = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-2)).value;
		int p2left = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left;
		int p2right = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right;
		String p2 = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-0)).value;
		
    Consola.ejecutar(com, p1, p2);

              CUP$parser$result = new java_cup.runtime.Symbol(11/*instruccion*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-3)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 32: // codigos ::= WAIT 
            {
              String RESULT = null;
		
    Consola.waitEnterKey();

              CUP$parser$result = new java_cup.runtime.Symbol(8/*codigos*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 31: // codigos ::= CALLSN 
            {
              String RESULT = null;
		
    Consola.scan_num();

              CUP$parser$result = new java_cup.runtime.Symbol(8/*codigos*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 30: 
            {
              String RESULT = null;
		
    Consola.print_num();

              CUP$parser$result = new java_cup.runtime.Symbol(8/*codigos*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 29: // codigos ::= etiqueta 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(8/*codigos*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 28: // codigos ::= instruccion 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(8/*codigos*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 27: // metodos ::= RET 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(7/*metodos*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 26: // metodos ::= START 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(7/*metodos*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 25: // metodos ::= PROC ID 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(7/*metodos*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-1)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 24: // declaracion ::= DEF4 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(6/*declaracion*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 23: // declaracion ::= DEF3 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(6/*declaracion*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 22: // declaracion ::= DEF2 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(6/*declaracion*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 21: // declaracion ::= DEF1 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(6/*declaracion*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 20: // declaracion ::= TEMPORAL DW INTERROGACION 
            {
              String RESULT = null;
		int templeft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-2)).left;
		int tempright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-2)).right;
		String temp = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-2)).value;
		
    Consola.agregarVar(temp, "");

              CUP$parser$result = new java_cup.runtime.Symbol(6/*declaracion*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-2)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 19: // declaracion ::= DECHEAP 
            {
              String RESULT = null;
		
    for(int i=0;i<5000;i++)
        Consola.agregarVar("heap["+i+"]", "0");

              CUP$parser$result = new java_cup.runtime.Symbol(6/*declaracion*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 18: // declaracion ::= DECPPILA 
            {
              String RESULT = null;
		
    Consola.agregarVar("ptr_pila", "0");

              CUP$parser$result = new java_cup.runtime.Symbol(6/*declaracion*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 17: // declaracion ::= DECPHEAP 
            {
              String RESULT = null;
		
    Consola.agregarVar("ptr_heap", "0");

              CUP$parser$result = new java_cup.runtime.Symbol(6/*declaracion*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 16: // declaracion ::= DECPILA 
            {
              String RESULT = null;
		
    for(int i=0;i<5000;i++)
        Consola.agregarVar("pila["+i+"]", "0");

              CUP$parser$result = new java_cup.runtime.Symbol(6/*declaracion*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 15: 
            {
              String RESULT = null;
		

              CUP$parser$result = new java_cup.runtime.Symbol(5/*declaraciones*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 14: // declaraciones ::= declaraciones declaracion 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(5/*declaraciones*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-1)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 13: // includes ::= JMPSTART 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(4/*includes*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 12: // includes ::= ORG 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(4/*includes*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 11: // includes ::= NAME 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(4/*includes*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 10: // includes ::= INCLUDE 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(4/*includes*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 9: // include ::= includes 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(3/*include*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 8: // include ::= include includes 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(3/*include*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-1)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 7: 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(2/*inicio*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 6: // inicio ::= codigos 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(2/*inicio*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 5: // inicio ::= metodos 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(2/*inicio*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 4: 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(2/*inicio*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 3: // inicio ::= include 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(2/*inicio*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 2: // s ::= error s 
            {
              String RESULT = null;

              CUP$parser$result = new java_cup.runtime.Symbol(1/*s*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-1)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 1: // s ::= inicio 
            {
              String RESULT = null;
		

              CUP$parser$result = new java_cup.runtime.Symbol(1/*s*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          return CUP$parser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 0: 
            {
              Object RESULT = null;
		int start_valleft = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-1)).left;
		int start_valright = ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-1)).right;
		String start_val = (String)((java_cup.runtime.Symbol) CUP$parser$stack.elementAt(CUP$parser$top-1)).value;
		RESULT = start_val;
              CUP$parser$result = new java_cup.runtime.Symbol(0/*$START*/, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-1)).left, ((java_cup.runtime.Symbol)CUP$parser$stack.elementAt(CUP$parser$top-0)).right, RESULT);
            }
          /* ACCEPT */
          CUP$parser$parser.done_parsing();
          return CUP$parser$result;

          /* . . . . . .*/
          default:
            throw new Exception(
               "Invalid action number found in internal parse table");

        }
    }
}

