


package maquinavirtual;

/** CUP generated class containing symbol constants. */
public class sym {
  /* terminals */
  public static final int NUMERO = 49;
  public static final int DOSPUNTOS = 22;
  public static final int JL = 38;
  public static final int INTERROGACION = 23;
  public static final int DECPPILA = 5;
  public static final int RET = 46;
  public static final int JG = 39;
  public static final int CCOR = 26;
  public static final int POP = 34;
  public static final int JE = 42;
  public static final int PUSH = 33;
  public static final int CALLPN = 15;
  public static final int JNE = 43;
  public static final int CALLSN = 16;
  public static final int CMP = 37;
  public static final int ACOR = 25;
  public static final int PTR_HEAP = 21;
  public static final int ORG = 11;
  public static final int DECPILA = 3;
  public static final int IDIV = 32;
  public static final int CALL = 35;
  public static final int MOV = 28;
  public static final int ID = 50;
  public static final int JMP = 36;
  public static final int WAIT = 17;
  public static final int EOF = 0;
  public static final int TEMPORAL = 48;
  public static final int IMUL = 31;
  public static final int HEAP = 19;
  public static final int JGE = 41;
  public static final int error = 1;
  public static final int DEF4 = 10;
  public static final int COMA = 24;
  public static final int INCLUDE = 2;
  public static final int DEF3 = 9;
  public static final int DEF2 = 8;
  public static final int ADD = 29;
  public static final int DEF1 = 7;
  public static final int START = 14;
  public static final int NAME = 12;
  public static final int DECPHEAP = 6;
  public static final int PTR_PILA = 20;
  public static final int END = 47;
  public static final int JMPSTART = 13;
  public static final int PROC = 45;
  public static final int PUTC = 44;
  public static final int DW = 27;
  public static final int JLE = 40;
  public static final int PILA = 18;
  public static final int SUB = 30;
  public static final int DECHEAP = 4;
}

