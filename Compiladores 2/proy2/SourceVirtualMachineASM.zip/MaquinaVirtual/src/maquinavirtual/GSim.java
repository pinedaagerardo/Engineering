/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package maquinavirtual;

import java.awt.Color;
import java.util.Vector;
import javax.swing.JLabel;

public class GSim {

    final int sqWidth=Consola.sPanel.getWidth();
    final int pHeight=Consola.sPanel.getHeight();
    final int PHSize=5000;
    final int sqHeight=10;
    final int ptrWidth=30;
    protected int sPtr=0;
    protected int hPtr=0;
    protected int max_pos_heap=0;
    protected int max_pos_stack=0;
    protected JLabel[] hData=new JLabel[PHSize];
    protected JLabel[] sData=new JLabel[PHSize];
    protected Vector<java.awt.Color> rainbow=new Vector();
    public int rainbowIndex=0;

    public GSim(){
        rainbow.add(Color.orange);
        rainbow.add(Color.gray);
        rainbow.add(Color.cyan);
        rainbow.add(Color.red);
        rainbow.add(Color.green);
        rainbow.add(Color.white);
        rainbow.add(Color.magenta);
        rainbow.add(Color.yellow);
        rainbow.add(Color.pink);
        chPtr(0,"ptr_pila");
        chPtr(0,"ptr_heap");
        Consola.container.repaint();
    }

    public void addData(int type,int i){
        JLabel sq=new JLabel();
        sq.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 1));
        sq.setOpaque(true);
        if(type==0){
            sq.setBackground(rainbow.elementAt(rainbowIndex));
            sq.setBounds(0, pHeight-sqHeight*(i+1), sqWidth, sqHeight);
            sData[i]=sq;
            if(i>max_pos_stack) max_pos_stack=i;
        }else{
            sq.setBackground(java.awt.Color.BLUE);
            sq.setBounds(0, pHeight-sqHeight*(i+1), sqWidth, sqHeight);
            hData[i]=sq;
            if(i>max_pos_heap) max_pos_heap=i;
        }
        draw();
    }

    protected void draw(){
        Consola.sPanel.removeAll();
        Consola.hPanel.removeAll();
        for(int i=0;i<=max_pos_stack;i++){
            JLabel sq=sData[i];
            if(sq!=null)
                Consola.sPanel.add(sq);
            else{
                JLabel emptySq=new JLabel();
                emptySq.setBounds(0, pHeight-sqHeight*(i+1), sqWidth, sqHeight);
                emptySq.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 1));
                Consola.sPanel.add(emptySq);
            }
        }
        
        for(int i=0;i<=max_pos_heap;i++){
            JLabel sq=hData[i];
            if(sq!=null)
                Consola.hPanel.add(sq);
            else{
                JLabel emptySq=new JLabel();
                emptySq.setBounds(0, pHeight-sqHeight*(i+1), sqWidth, sqHeight);
                emptySq.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 1));
                Consola.hPanel.add(emptySq);
            }
        }
    }

    public void delArrayData(){
        for(int i=0;i<PHSize;i++){
            hData[i]=null;
            sData[i]=null;
        }
    }

    public void chPtr(int val,String ptr){
        int sX=Consola.sPanel.getX()-ptrWidth;
        int hX=Consola.hPanel.getX()-ptrWidth;
        int sY=pHeight+Consola.hPanel.getY()-sqHeight*(sPtr+1);
        int hY=pHeight+Consola.hPanel.getY()-sqHeight*(hPtr+1);
        try{
            Consola.container.remove(Consola.container.getComponentAt(sX, sY));
            Consola.container.remove(Consola.container.getComponentAt(hX, hY));
        }catch(Exception e){}

        ptr=ptr.toLowerCase();
        if(ptr.equalsIgnoreCase("ptr_pila")){
            sPtr=val;
            Consola.p_p.setText(""+val);
        }else{
            hPtr=val;
            Consola.p_h.setText(""+val);
        }
        
        sY=pHeight+Consola.hPanel.getY()-sqHeight*(sPtr+1);
        hY=pHeight+Consola.hPanel.getY()-sqHeight*(hPtr+1);

        JLabel Hsq=new JLabel();
        JLabel Ssq=new JLabel();
        Hsq.setText(Consola.p_h.getText()+" >");
        Ssq.setText(Consola.p_p.getText()+" >");
        Hsq.setBounds(hX, hY, ptrWidth, sqHeight);
        Ssq.setBounds(sX, sY, ptrWidth, sqHeight);
        Consola.container.add(Hsq);
        Consola.container.add(Ssq);
    }
}
