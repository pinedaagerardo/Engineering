
package maquinavirtual;

import java.io.FileReader;
import java.io.StringReader;
import java.util.Vector;
import java.awt.FileDialog;
import java.io.BufferedReader;
import javax.swing.JOptionPane;
import java.io.InputStreamReader;

public class Consola extends javax.swing.JFrame {

    public static Object regs[]=new Object[Index.numRegs];
    public static Vector virtualStack=new Vector();
    public static Vector symTable=new Vector();
    public static String inputFile="";
    public static boolean flag_continue=true;
    public static boolean flag_efectoJMP=false;
    public static int flag_estaEnMetodo=0;
    public static boolean hasStarted=false;
    protected static GSim graphC;

    public Consola() {
        initComponents();
        reset();
        graphC=new GSim();
    }

    public static void compile(String file,String label,Boolean salto){
        flag_continue=true;
        Yylex miScanner;
        parser miParser;
        String linea="";
        try{
            BufferedReader in = new BufferedReader(new FileReader(file));
            while(salto && (linea=in.readLine())!=null){
                if(linea.equalsIgnoreCase(label+":") || linea.equalsIgnoreCase("proc "+label))
                    salto=false;
            }
            
            while(flag_continue && !((linea=in.readLine()).equalsIgnoreCase("ret") && hasStarted)){
                if(linea.equalsIgnoreCase("start:")) hasStarted=true;
                miScanner=null;
                miParser=null;
                if(hasStarted && !flag_efectoJMP)
                    JOptionPane.showMessageDialog(null, linea);
                try{
                    if(!flag_efectoJMP){
                        miScanner=new Yylex(new BufferedReader(new StringReader(linea)));
                        miParser=new parser(miScanner);
                        miParser.parse();
                    }
                }catch(Exception e){System.out.println("Maquina Virtual: Error en la linea: "+linea);}

                writeReg();
            }
            flag_efectoJMP=false;
            if(graphC.rainbowIndex>0)
                graphC.rainbowIndex--;
        }catch (Exception ex) {System.out.println("Maquina Virtual: Error de lectura. "+ex.toString());}
    }

    protected static String fill(String s){
        for(int i=0;s.length()<4;i++)
            s="0"+s;
        return s;
    }

    protected static void writeReg(){
        String sax=Integer.toHexString(Integer.valueOf(regs[Index.AX].toString()));
        tax.setText(fill(sax));
        String sbx=Integer.toHexString(Integer.valueOf(regs[Index.BX].toString()));
        tbx.setText(fill(sbx));
        String scx=Integer.toHexString(Integer.valueOf(regs[Index.CX].toString()));
        tcx.setText(fill(scx));
        String sdx=Integer.toHexString(Integer.valueOf(regs[Index.DX].toString()));
        tdx.setText(fill(sdx));
        String scf=regs[Index.CF].toString();
        tcf.setText(scf);
        String szf=regs[Index.ZF].toString();
        tzf.setText(szf);

        String scs=Integer.toHexString(Integer.valueOf(regs[Index.CS].toString()));
        tcs.setText(fill(scs));
        String sds=Integer.toHexString(Integer.valueOf(regs[Index.DS].toString()));
        tds.setText(fill(sds));
        String sip=Integer.toHexString(Integer.valueOf(regs[Index.IP].toString()));
        tip.setText(fill(sip));
        String ses=Integer.toHexString(Integer.valueOf(regs[Index.ES].toString()));
        tes.setText(fill(ses));
        String sbp=Integer.toHexString(Integer.valueOf(regs[Index.BP].toString()));
        tbp.setText(fill(sbp));
        String ssi=Integer.toHexString(Integer.valueOf(regs[Index.SI].toString()));
        tsi.setText(fill(ssi));
        String sdi=Integer.toHexString(Integer.valueOf(regs[Index.DI].toString()));
        tdi.setText(fill(sdi));
        String sss=Integer.toHexString(Integer.valueOf(regs[Index.SS].toString()));
        tss.setText(fill(sss));
        String ssp=Integer.toHexString(Integer.valueOf(regs[Index.SP].toString()));
        tsp.setText(fill(ssp));
    }

    public static void comMOV(String param1,String param2){
        if(param1.toLowerCase().startsWith("pila")){
            int u=param1.length()-1;
            int i=Integer.valueOf(param1.substring(5, u));
            graphC.addData(0, i);
        }
        if(param1.toLowerCase().startsWith("heap")){
            int u=param1.length()-1;
            int i=Integer.valueOf(param1.substring(5, u));
            graphC.addData(1, i);
        }

        int a=convert(param1);
        int b=convert(param2);
        if(b==-1){
            int ip2=getIndex(param2);
            if(ip2==-1){
                if(a==-1){
                    int ip1=getIndex(param1);
                    setVal(ip1, param2);
                    if(param1.equalsIgnoreCase("ptr_pila") || param1.equalsIgnoreCase("ptr_heap"))
                        graphC.chPtr(Integer.valueOf(param2), param1);
                }else{
                    regs[a]=param2;
                }
            }else{
                Object o=getVal(ip2);
                if(a==-1){
                    int ip1=getIndex(param1);
                    setVal(ip1, o);
                    if(param1.equalsIgnoreCase("ptr_pila") || param1.equalsIgnoreCase("ptr_heap"))
                        graphC.chPtr(Integer.valueOf(o.toString()), param1);
                }else{
                    regs[a]=o;
                }
            }
        }else{
            if(a==-1){
                int ip1=getIndex(param1);
                setVal(ip1, regs[b]);
                if(param1.equalsIgnoreCase("ptr_pila") || param1.equalsIgnoreCase("ptr_heap"))
                    graphC.chPtr(Integer.valueOf(regs[b].toString()), param1);
            }else{
                regs[a]=regs[b];
            }
        }
    }

    public static void comADD(String param1,String param2){
        int a=convert(param1);
        int b=convert(param2);
        if(b==-1){
            int ip2=getIndex(param2);
            if(ip2==-1){
                int tmp=Integer.valueOf(regs[a].toString());
                tmp=tmp+Integer.valueOf(param2);
                regs[a]=tmp;
            }else{
                Object o=getVal(ip2);
                int tmp=Integer.valueOf(regs[a].toString());
                tmp=tmp+Integer.valueOf(o.toString());
                regs[a]=tmp;
            }
        }
    }

    public static void comSUB(String param1,String param2){
        int a=convert(param1);
        int b=convert(param2);
        if(b==-1){
            int ip2=getIndex(param2);
            if(ip2==-1){
                int tmp=Integer.valueOf(regs[a].toString());
                tmp=tmp-Integer.valueOf(param2);
                regs[a]=tmp;
            }else{
                Object o=getVal(ip2);
                int tmp=Integer.valueOf(regs[a].toString());
                tmp=tmp-Integer.valueOf(o.toString());
                regs[a]=tmp;
            }
        }
    }

    public static void comIMUL(String param1){
        int a=convert(param1);
        if(a==-1){
            int ip1=getIndex(param1);
            Object o=getVal(ip1);
            int tmp=Integer.valueOf(regs[Index.AX].toString());
            tmp=tmp*Integer.valueOf(o.toString());
            regs[Index.AX]=tmp;
        }else{
            int tmp=Integer.valueOf(regs[Index.AX].toString());
            tmp=tmp*Integer.valueOf(regs[a].toString());
            regs[Index.AX]=tmp;
        }
    }

    public static void comIDIV(String param1){
        int a=convert(param1);
        if(a==-1){
            int ip1=getIndex(param1);
            Object o=getVal(ip1);
            int tmp=Integer.valueOf(regs[Index.AX].toString());
            tmp=tmp/Integer.valueOf(o.toString());
            regs[Index.AX]=tmp;
        }else{
            int tmp=Integer.valueOf(regs[Index.AX].toString());
            tmp=tmp/Integer.valueOf(regs[a].toString());
            regs[Index.AX]=tmp;
        }
    }

    public static void comJMP(String param1){
        compile(inputFile, param1, true);
        flag_efectoJMP=true;
        if(flag_estaEnMetodo==0)
            flag_continue=false;
    }

    public static void comCALL(String param1){
        if(graphC.rainbowIndex<graphC.rainbow.size()-1)
            graphC.rainbowIndex++;
        flag_estaEnMetodo++;
        compile(inputFile, param1, true);
        flag_estaEnMetodo--;
    }

    public static void comPUSH(String param1){
        int a=convert(param1);
        virtualStack.add(regs[a]);
    }

    public static void comPOP(String param1){
        int a=convert(param1);
        int tmp=virtualStack.size()-1;
        regs[a]=virtualStack.remove(tmp);
    }

    public static void comCMP(String param1,String param2){
        int ip2=getIndex(param2);
        int res=0;
        if(ip2==-1){
            int tmp_p1=Integer.valueOf(regs[Index.DX].toString());
            int tmp_p2=Integer.valueOf(param2);
            res=tmp_p1-tmp_p2;
        }else{
            Object o=getVal(ip2);
            int tmp_p1=Integer.valueOf(regs[Index.DX].toString());
            int tmp_p2=Integer.valueOf(o.toString());
            res=tmp_p1-tmp_p2;
        }
        if(res==0){
            regs[Index.ZF]=1;
            regs[Index.CF]=0;
        }else{
            if(res<0){
                regs[Index.ZF]=0;
                regs[Index.CF]=0;
            }else{
                regs[Index.ZF]=0;
                regs[Index.CF]=1;
            }
        }
    }

    public static void comJG(String param1){
        int zf=Integer.valueOf(regs[Index.ZF].toString());
        int cf=Integer.valueOf(regs[Index.CF].toString());
        if(zf==0 && cf==1)
            comJMP(param1);
    }

    public static void comJL(String param1){
        int zf=Integer.valueOf(regs[Index.ZF].toString());
        int cf=Integer.valueOf(regs[Index.CF].toString());
        if(zf==0 && cf==0)
            comJMP(param1);
    }

    public static void comJLE(String param1){
        int zf=Integer.valueOf(regs[Index.ZF].toString());
        int cf=Integer.valueOf(regs[Index.CF].toString());
        if(cf==0)
            comJMP(param1);
    }

    public static void comJE(String param1){
        int zf=Integer.valueOf(regs[Index.ZF].toString());
        int cf=Integer.valueOf(regs[Index.CF].toString());
        if(zf==1)
            comJMP(param1);
    }

    public static void comJNE(String param1){
        int zf=Integer.valueOf(regs[Index.ZF].toString());
        int cf=Integer.valueOf(regs[Index.CF].toString());
        if(zf==0)
            comJMP(param1);
    }

    public static void comJGE(String param1){
        int zf=Integer.valueOf(regs[Index.ZF].toString());
        int cf=Integer.valueOf(regs[Index.CF].toString());
        if(zf==1 || cf==1)
            comJMP(param1);
    }

    public static void waitEnterKey(){
        BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
        try{
            in.readLine();
        }catch(Exception e){
            System.out.println("Maquina Virtual: error con el dato de entrada");
        }
    }

    public static void comPUTC(String param1){
        int i=Integer.valueOf(regs[Index.AX].toString());
        char letra=(char)i;
        System.out.print(letra);
    }

    public static void scan_num(){
        BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
        String s="";
        try{
            boolean flag=true;
            while(flag){
                s = ""+in.readLine();
                try{
                    Integer.valueOf(s);
                    flag=false;
                }catch(Exception e){
                    System.out.println("ingresar un numero");
                }
            }
        }catch(Exception e){
            System.out.println("Maquina Virtual: error con el dato de entrada");
        }
        regs[Index.CX]=s;
    }

    public static void print_num(){
        System.out.print(""+regs[Index.AX]);
    }

    public static void ejecutar(String method,String param1,String param2){
        int m=convert(method);
        if(param1.endsWith("[di]")){
            String di=regs[Index.DI].toString();
            param1=param1.substring(0, 4)+"["+di+"]";
        }
        if(param2.endsWith("[di]")){
            String di=regs[Index.DI].toString();
            param2=param2.substring(0, 4)+"["+di+"]";
        }
        switch(m){
            case 34:
                comMOV(param1,param2);
                break;
            case 35:
                comADD(param1,param2);
                break;
            case 36:
                comSUB(param1,param2);
                break;
            case 37:
                comIMUL(param1);
                break;
            case 38:
                comIDIV(param1);
                break;
            case 39:
                comPUSH(param1);
                break;
            case 40:
                comPOP(param1);
                break;
            case 41:
                comCALL(param1);
                break;
            case 42:
                comJMP(param1);
                break;
            case 43:
                comCMP(param1,param2);
                break;
            case 44:
                comJL(param1);
                break;
            case 45:
                comJG(param1);
                break;
            case 46:
                comJLE(param1);
                break;
            case 47:
                comJGE(param1);
                break;
            case 48:
                comJE(param1);
                break;
            case 49:
                comJNE(param1);
                break;
            case 50:
                comPUTC(param1);
                break;
        }
        container.repaint();
    }

    protected  static int convert(String s){
        if(s.equalsIgnoreCase("al")) return Index.AL;
        else if(s.equalsIgnoreCase("ah")) return Index.AH;
        else if(s.equalsIgnoreCase("ax")) return Index.AX;
        else if(s.equalsIgnoreCase("bl")) return Index.BL;
        else if(s.equalsIgnoreCase("bh")) return Index.BH;
        else if(s.equalsIgnoreCase("bx")) return Index.BX;
        else if(s.equalsIgnoreCase("cl")) return Index.CL;
        else if(s.equalsIgnoreCase("ch")) return Index.CH;
        else if(s.equalsIgnoreCase("cx")) return Index.CX;
        else if(s.equalsIgnoreCase("dl")) return Index.DL;
        else if(s.equalsIgnoreCase("dh")) return Index.DH;
        else if(s.equalsIgnoreCase("dx")) return Index.DX;
        else if(s.equalsIgnoreCase("si")) return Index.SI;
        else if(s.equalsIgnoreCase("di")) return Index.DI;
        else if(s.equalsIgnoreCase("ip")) return Index.IP;
        else if(s.equalsIgnoreCase("cs")) return Index.CS;
        else if(s.equalsIgnoreCase("ds")) return Index.DS;
        else if(s.equalsIgnoreCase("es")) return Index.ES;
        else if(s.equalsIgnoreCase("bp")) return Index.BP;
        else if(s.equalsIgnoreCase("sp")) return Index.SP;
        else if(s.equalsIgnoreCase("ss")) return Index.SS;
        else if(s.equalsIgnoreCase("if")) return Index.IF;
        else if(s.equalsIgnoreCase("sf")) return Index.SF;
        else if(s.equalsIgnoreCase("tf")) return Index.TF;
        else if(s.equalsIgnoreCase("df")) return Index.DF;
        else if(s.equalsIgnoreCase("cf")) return Index.CF;
        else if(s.equalsIgnoreCase("pf")) return Index.PF;
        else if(s.equalsIgnoreCase("af")) return Index.AF;
        else if(s.equalsIgnoreCase("of")) return Index.OF;
        else if(s.equalsIgnoreCase("iopl")) return Index.IOPL;
        else if(s.equalsIgnoreCase("nt")) return Index.NT;
        else if(s.equalsIgnoreCase("rf")) return Index.RF;
        else if(s.equalsIgnoreCase("vm")) return Index.VM;
        else if(s.equalsIgnoreCase("zf")) return Index.ZF;

        else if(s.equalsIgnoreCase("mov")) return Index.MOV;
        else if(s.equalsIgnoreCase("imul")) return Index.IMUL;
        else if(s.equalsIgnoreCase("idiv")) return Index.IDIV;
        else if(s.equalsIgnoreCase("add")) return Index.ADD;
        else if(s.equalsIgnoreCase("sub")) return Index.SUB;
        else if(s.equalsIgnoreCase("push")) return Index.PUSH;
        else if(s.equalsIgnoreCase("pop")) return Index.POP;
        else if(s.equalsIgnoreCase("call")) return Index.CALL;
        else if(s.equalsIgnoreCase("cmp")) return Index.CMP;
        else if(s.equalsIgnoreCase("jmp")) return Index.JMP;
        else if(s.equalsIgnoreCase("jl")) return Index.JL;
        else if(s.equalsIgnoreCase("jge")) return Index.JGE;
        else if(s.equalsIgnoreCase("je")) return Index.JE;
        else if(s.equalsIgnoreCase("jne")) return Index.JNE;
        else if(s.equalsIgnoreCase("jg")) return Index.JG;
        else if(s.equalsIgnoreCase("jle")) return Index.JLE;
        else if(s.equalsIgnoreCase("putc")) return Index.PUTC;
        else return -1;
    }

    protected void reset(){
        symTable=new Vector();
        virtualStack=new Vector();
        flag_continue=true;
        flag_efectoJMP=hasStarted=false;
        flag_estaEnMetodo=0;
        inputFile="";
        regs[Index.AH]=regs[Index.BH]=regs[Index.CH]=regs[Index.DH]=regs[Index.AL]=regs[Index.BL]=regs[Index.CL]=regs[Index.DL]="00";
        regs[Index.SI]=regs[Index.DI]=regs[Index.BP]=regs[Index.SP]=regs[Index.IP]=regs[Index.CS]=regs[Index.DS]=regs[Index.ES]=regs[Index.SS]="0000";
        regs[Index.AX]=regs[Index.BX]=regs[Index.CX]=regs[Index.DX]="0000";
        regs[Index.ZF]=regs[Index.CF]="0";
        writeReg();
        sPanel.removeAll();
        sPanel.repaint();
        hPanel.removeAll();
        hPanel.repaint();
        try{
            graphC.delArrayData();
            graphC.chPtr(0,"ptr_pila");
            graphC.chPtr(0,"ptr_heap");
            container.repaint();
        }catch(Exception e){}
    }

    public static Object getVal(int i){
        Object o[]=(Object[])symTable.elementAt(i);
        return o[1];
    }

    public static int getIndex(String var){
        for(int i=0;i<symTable.size();i++){
            Object o[]=(Object[])symTable.elementAt(i);
            if(o[0].toString().equalsIgnoreCase(var))
                return i;
        }
        return -1;
    }

    public static void agregarVar(Object name,Object value){
         Object o[]=new Object[2];
         o[0]=name;
         o[1]=value;
         symTable.add(o);
    }

    public static void setVal(int i,Object value){
        Object o[]=(Object[])symTable.elementAt(i);
        o[1]=new String(value.toString());
        symTable.setElementAt(o, i);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        container = new javax.swing.JPanel();
        sPanel = new javax.swing.JPanel();
        hPanel = new javax.swing.JPanel();
        p_p = new javax.swing.JLabel();
        p_p.setVisible(false);
        p_h = new javax.swing.JLabel();
        p_h.setVisible(false);
        regPanel = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        tzf = new javax.swing.JTextField();
        tcf = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        tax = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        tdx = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        tbx = new javax.swing.JTextField();
        tcx = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        tes = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        tds = new javax.swing.JTextField();
        tdi = new javax.swing.JTextField();
        tsi = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        tbp = new javax.swing.JTextField();
        tsp = new javax.swing.JTextField();
        tss = new javax.swing.JTextField();
        tip = new javax.swing.JTextField();
        tcs = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        sPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        sPanel.setPreferredSize(new java.awt.Dimension(131, 624));

        javax.swing.GroupLayout sPanelLayout = new javax.swing.GroupLayout(sPanel);
        sPanel.setLayout(sPanelLayout);
        sPanelLayout.setHorizontalGroup(
            sPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 115, Short.MAX_VALUE)
        );
        sPanelLayout.setVerticalGroup(
            sPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 608, Short.MAX_VALUE)
        );

        hPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        hPanel.setPreferredSize(new java.awt.Dimension(131, 624));

        javax.swing.GroupLayout hPanelLayout = new javax.swing.GroupLayout(hPanel);
        hPanel.setLayout(hPanelLayout);
        hPanelLayout.setHorizontalGroup(
            hPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 115, Short.MAX_VALUE)
        );
        hPanelLayout.setVerticalGroup(
            hPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 608, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout containerLayout = new javax.swing.GroupLayout(container);
        container.setLayout(containerLayout);
        containerLayout.setHorizontalGroup(
            containerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, containerLayout.createSequentialGroup()
                .addContainerGap(113, Short.MAX_VALUE)
                .addComponent(sPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(97, 97, 97)
                .addComponent(hPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(containerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(p_h, 0, 0, Short.MAX_VALUE)
                    .addComponent(p_p, javax.swing.GroupLayout.PREFERRED_SIZE, 11, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        containerLayout.setVerticalGroup(
            containerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, containerLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(containerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(sPanel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(hPanel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(containerLayout.createSequentialGroup()
                        .addComponent(p_p)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(p_h)))
                .addContainerGap())
        );

        regPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel16.setText("CF");

        jLabel19.setText("ZF");

        tzf.setEditable(false);
        tzf.setPreferredSize(new java.awt.Dimension(50, 20));

        tcf.setEditable(false);
        tcf.setPreferredSize(new java.awt.Dimension(50, 20));
        tcf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tcfActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel16)
                    .addComponent(jLabel19))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tzf, 0, 0, Short.MAX_VALUE)
                    .addComponent(tcf, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(tcf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tzf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel19)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel12.setText("L");

        tax.setEditable(false);
        tax.setPreferredSize(new java.awt.Dimension(50, 20));

        jLabel11.setText("H");

        tdx.setEditable(false);
        tdx.setPreferredSize(new java.awt.Dimension(50, 20));
        tdx.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tdxActionPerformed(evt);
            }
        });

        jLabel2.setText("BX");

        jLabel1.setText("AX");

        tbx.setEditable(false);
        tbx.setPreferredSize(new java.awt.Dimension(50, 20));

        tcx.setEditable(false);
        tcx.setPreferredSize(new java.awt.Dimension(50, 20));
        tcx.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tcxActionPerformed(evt);
            }
        });

        jLabel4.setText("DX");

        jLabel3.setText("CX");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel3)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(tcx, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel2)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(tbx, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel4)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(tdx, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addGap(27, 27, 27)
                                .addComponent(jLabel12))
                            .addComponent(tax, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(jLabel12))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(tax, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(tbx, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(tcx, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(tdx, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel14.setText("DS");

        jLabel13.setText("DI");

        jLabel10.setText("SI");

        tes.setEditable(false);
        tes.setPreferredSize(new java.awt.Dimension(50, 20));

        jLabel15.setText("ES");

        tds.setEditable(false);
        tds.setPreferredSize(new java.awt.Dimension(50, 20));

        tdi.setEditable(false);
        tdi.setPreferredSize(new java.awt.Dimension(50, 20));

        tsi.setEditable(false);
        tsi.setPreferredSize(new java.awt.Dimension(50, 20));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                        .addComponent(tsi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                        .addComponent(tdi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addComponent(jLabel15)
                            .addGap(10, 10, 10)
                            .addComponent(tes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addComponent(jLabel14)
                            .addGap(10, 10, 10)
                            .addComponent(tds, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(tsi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(tdi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(tds, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(tes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel8.setText("SP");

        jLabel9.setText("BP");

        jLabel6.setText("IP");

        jLabel7.setText("SS");

        tbp.setEditable(false);
        tbp.setPreferredSize(new java.awt.Dimension(50, 20));

        tsp.setEditable(false);
        tsp.setPreferredSize(new java.awt.Dimension(50, 20));
        tsp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tspActionPerformed(evt);
            }
        });

        tss.setEditable(false);
        tss.setPreferredSize(new java.awt.Dimension(50, 20));

        tip.setEditable(false);
        tip.setPreferredSize(new java.awt.Dimension(50, 20));
        tip.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tipActionPerformed(evt);
            }
        });

        tcs.setEditable(false);
        tcs.setPreferredSize(new java.awt.Dimension(50, 20));

        jLabel5.setText("CS");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7)
                    .addComponent(jLabel9)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(tip, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tcs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tss, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tsp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tbp, javax.swing.GroupLayout.DEFAULT_SIZE, 51, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(tcs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(tip, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(tss, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(tsp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(tbp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout regPanelLayout = new javax.swing.GroupLayout(regPanel);
        regPanel.setLayout(regPanelLayout);
        regPanelLayout.setHorizontalGroup(
            regPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(regPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(regPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(78, 78, 78)
                .addGroup(regPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        regPanelLayout.setVerticalGroup(
            regPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(regPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(regPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43)
                .addGroup(regPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jMenu1.setText("File");

        jMenuItem1.setText("Abrir");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(container, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 98, Short.MAX_VALUE)
                .addComponent(regPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(63, 63, 63))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(container, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(136, 136, 136)
                        .addComponent(regPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        initComponents();
        reset();
        graphC=new GSim();
        try{
            FileDialog dlg=new FileDialog(this,"Abrir",FileDialog.LOAD);
            dlg.setVisible(true);
            inputFile=dlg.getFile();
            if(inputFile==null) return;
            if(inputFile.toLowerCase().endsWith(".asm")){
                reset();
                inputFile=dlg.getDirectory()+dlg.getFile();
                System.out.println("Maquina Virtual: compilando "+inputFile);
                compile(inputFile,"",false);
            }else
                System.out.println("Maquina Virtual: archivo erroneo");
        }catch(Exception e){
            System.out.println("Maquina Virtual: Error al abrir el archivo");
        }
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void tipActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tipActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tipActionPerformed

    private void tcxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tcxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tcxActionPerformed

    private void tdxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tdxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tdxActionPerformed

    private void tspActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tspActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tspActionPerformed

    private void tcfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tcfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tcfActionPerformed

    /**
    * @param args the command line arguments
    */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Consola().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JPanel container;
    public static javax.swing.JPanel hPanel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    public static javax.swing.JLabel p_h;
    public static javax.swing.JLabel p_p;
    private javax.swing.JPanel regPanel;
    public static javax.swing.JPanel sPanel;
    protected static javax.swing.JTextField tax;
    protected static javax.swing.JTextField tbp;
    protected static javax.swing.JTextField tbx;
    protected static javax.swing.JTextField tcf;
    protected static javax.swing.JTextField tcs;
    protected static javax.swing.JTextField tcx;
    protected static javax.swing.JTextField tdi;
    protected static javax.swing.JTextField tds;
    protected static javax.swing.JTextField tdx;
    protected static javax.swing.JTextField tes;
    protected static javax.swing.JTextField tip;
    protected static javax.swing.JTextField tsi;
    protected static javax.swing.JTextField tsp;
    protected static javax.swing.JTextField tss;
    protected static javax.swing.JTextField tzf;
    // End of variables declaration//GEN-END:variables

}
