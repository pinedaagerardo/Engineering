/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package compilador;

import BlockOpt.OpBloques;
import MirillaOpt.OpMirilla;
import SymT.Manejador;
import java.io.FileReader;
import java.io.Serializable;
import java.util.ArrayList;

public class MyBean implements Serializable{

    protected String path="c:\\cacheTomcat";
    protected String pathOpt=path+"\\optimizacion";

    public MyBean(){}

    public void opMirilla(){
        OpMirilla mi = new OpMirilla(pathOpt,path);
        mi.killComment();
    }

    public void opBloques(){
        OpBloques b = new OpBloques (pathOpt);
        b.mover("optimiza_mirilla.cpp","TmpBloques.cpp");
        b.draw("grafo.txt");
        b.createGraph("grafo.txt","grafo.jpg");
    }

    public void parsear(ArrayList<String> archivo){
    for(int i=0;i<archivo.size();i++){
                 String tpath=path+"\\"+archivo.get(i);
                 Llena1.parser ThisParser;
                 Llena1.Lexico ThisScanner;
                try
                {
                ThisScanner = new Llena1.Lexico (new FileReader(tpath));
                ThisParser=new Llena1.parser (ThisScanner);
                
                ThisParser.parse();
                }catch(Exception e){}
        }

    
    String[] archivosOrdenados=Ordenar(archivo);
     for(int i=0;i<archivosOrdenados.length;i++){
                 String tpath=path+"\\"+archivosOrdenados[i];
                 Llena2.parser ThisParser;
                 Llena1.Lexico ThisScanner;
                try
                {
                ThisScanner = new Llena1.Lexico (new FileReader(tpath));
                ThisParser=new Llena2.parser (ThisScanner);
                
                ThisParser.parse();
                }catch(Exception e)
                {
                }
        }

      
         for(int i=0;i<archivo.size();i++){
         String tpath=path+"\\"+archivo.get(i);

            Generador.parser ThisParser;
            Llena1.Lexico ThisScanner;
            try
            {
            ThisScanner = new Llena1.Lexico (new FileReader(tpath));
            ThisParser=new Generador.parser (ThisScanner);
            
            ThisParser.parse();
            }catch(Exception e)
            {
                e.printStackTrace();
            }
         }
         Manejador.gen.Crear3D(path+"\\salida.cpp");

   }

   public String[] Ordenar(ArrayList<String> archivo){
        boolean[] Leido=new boolean[archivo.size()];
        String[] salida=new String[archivo.size()];
        int j=0;
         for(int i=0;i<archivo.size();i++){
         if((Leido[i]==false)&&((Manejador.Tabla.getPadre(archivo.get(i).replace(".java", "").replaceAll(".cpp", "").replaceAll(".h", "").replaceAll(".py", "").replaceAll(".vb", "")).equalsIgnoreCase(""))||(Padre(archivo,Manejador.Tabla.getPadre(archivo.get(i).replace(".java", "").replaceAll(".cpp", "").replaceAll(".h", "").replaceAll(".py", "").replaceAll(".vb", "")),Leido)))){
                    Leido[i]=true;
                    j++;
                    salida[i]=archivo.get(i);
         }
                if(i==archivo.size()-1){
                    if(j==Leido.length){
                    break;
                     }
                else{
                i=-1;
                }
                }
         }
        return salida;
}

    public Boolean Termine(boolean Leidos[]){
       int x=0;

       for(int i=0;i<Leidos.length;i++){
        if(Leidos[i]){
            x++;
        }
        }

       if(!(Leidos.length==x)){
           return false;
       }else{
           return true;
       }
    }


    public Boolean Padre(ArrayList<String> archivo, String padre, boolean Leido[]){
       Boolean Lei=false;
       for(int i=0;i<archivo.size();i++){
            if(padre.equals(archivo.get(i).replace(".java", "").replace(".cpp", "").replace(".h", "").replace(".py", "").replace(".vb", ""))){
                if(Leido[i]){
                    Lei=true;
                }
                break;
            }
        }
        return Lei;
    }
}
