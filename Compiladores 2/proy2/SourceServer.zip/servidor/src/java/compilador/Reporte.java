/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package compilador;

import java.io.IOException;
import java.io.RandomAccessFile;

public class Reporte {

    private boolean existe=false;
    private String archivo;

    
    public Reporte(String archivo){
        this.archivo=archivo;
    }

    /**
     * retorna un string con la ruta absoluta del archivo generado
     * @return la ruta absoluta del archivo generado
     */
    public String getArchivo(){
        return archivo;
    }

    
    public boolean existenErrores(){
        return existe;
    }

    /**
     * escribe o agrega al archivo nueva informacion
     * @param info la informacion usada en la aplicacion
     */
    void reportar(String info){
            try{
            RandomAccessFile fileout=new RandomAccessFile(archivo,"rw");
            if(!existe){
                    fileout.setLength(0); 
                    fileout.writeBytes("<html>\n");
                    fileout.writeBytes("<head>\n");
                    fileout.writeBytes("<title>Reporte</title>\n");
                    fileout.writeBytes("</head>\n");
                    fileout.writeBytes("<body bgcolor=#000F00 text=white>\n");
                    fileout.writeBytes("<br><p>\n");
                    fileout.writeBytes("<marquee behavior=alternate width=50% height=60 align=center><b><i>Reporte</i></b></marquee>\n");
                    fileout.writeBytes("<br><br><p>\n");
                    fileout.writeBytes("<table width=100% border=1>\n");
                    fileout.writeBytes("<tr align=center>\n");
                    fileout.writeBytes("<td width=100%> <strong>Errores</strong> </td>\n");
                    fileout.writeBytes("</tr>\n");
            }
            if(existe) fileout.seek((fileout.length())-22); 
            else existe=true;
            fileout.writeBytes("<tr align=center>\n");
            fileout.writeBytes("<td width=100%> <strong>"+info+"</strong> </td>\n");
            fileout.writeBytes("</tr>\n");
            fileout.writeBytes("</table></body></html>");
            fileout.close();
            }catch(IOException e){
                System.out.println("No se pudo guardar el reporte "+archivo);
            }
    }
}
