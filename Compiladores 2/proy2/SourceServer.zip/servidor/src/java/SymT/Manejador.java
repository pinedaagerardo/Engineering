package SymT;

public class Manejador {
    public static Tabla Tabla=new Tabla();
    public static Generador gen=new Generador();
}
