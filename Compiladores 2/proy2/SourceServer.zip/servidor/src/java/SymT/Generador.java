package SymT;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Generador{
    private int contadorTemporales;
    private int contadorEtiquetas;

    private StringBuilder encabezado;

    private StringBuilder temporalesINT;
    public StringBuilder definiciones;
    public StringBuilder implementaciones;
    public StringBuilder constructordefault;


    public Generador(){
        this.contadorTemporales = 0;
        this.contadorEtiquetas = 0;
        encabezado = new StringBuilder();
            encabezado.append("#include <stdio.h>"+"\n");
            encabezado.append("#include <conio.h>"+"\n");
            encabezado.append("#include <stdlib.h>"+"\n");
            encabezado.append("\n");
            encabezado.append("int PTR_PILA = 0;"+"\n");
            encabezado.append("int PTR_HEAP = 0;"+"\n");
            encabezado.append("int PILA[5000];"+"\n");
            encabezado.append("int HEAP[5000];"+"\n");
        temporalesINT = new StringBuilder();
        definiciones = new StringBuilder();
        constructordefault = new StringBuilder();
        implementaciones = new StringBuilder();
    }

    public void Clear(){
         this.contadorTemporales = 0;
        this.contadorEtiquetas = 0;
        encabezado = new StringBuilder();
            encabezado.append("#include <stdio.h>"+"\n");
            encabezado.append("#include <conio.h>"+"\n");
            encabezado.append("#include <stdlib.h>"+"\n");
            encabezado.append("\n");
            encabezado.append("int PTR_PILA = 0;"+"\n");
            encabezado.append("int PTR_HEAP = 0;"+"\n");
            encabezado.append("int PILA[5000];"+"\n");
            encabezado.append("int HEAP[5000];"+"\n");
        temporalesINT = new StringBuilder();
        definiciones = new StringBuilder();
        constructordefault = new StringBuilder();
        implementaciones = new StringBuilder();
    }

    public String generarTemporalInt(){
        this.contadorTemporales ++;
        String t = new String("$t"+this.contadorTemporales);
        if(contadorTemporales==1){
        temporalesINT.append(t);
        }else{
        temporalesINT.append(", "+t);
        }
    
        return t;
    }

    public String generarEtiquetaInt(){
        this.contadorEtiquetas ++;
        String t = new String("L"+this.contadorEtiquetas);
        return t;
    }

    public int getContadorEtiquetas() {
        return contadorEtiquetas;
    }

    public int getContadorTemporales() {
        return contadorTemporales;
    }


    public StringBuilder getTemporalesINT() {
        return temporalesINT;
    }

    @SuppressWarnings("empty-statement")
    public void Crear3D(String path){
        StringBuffer texto=new StringBuffer();
        texto.append(this.encabezado+"\n");
        if(!(this.contadorTemporales==0)){
        texto.append("\n//Temporales\nint "+this.temporalesINT+";\n");
        }
        texto.append("\n//Enunciado de Metodos\n"+this.definiciones+"\n//Constructores por Default"+this.constructordefault+"\n//Cuerpo de 3 Direcciones"+this.implementaciones);

        Crear_Archivo(path,texto);
    }

    public String LeerArchivo(String path) {
      File archivo = null;
      FileReader fr = null;
      BufferedReader br = null;
      String txtArchivo="";
      try {
         archivo = new File (path);
         fr = new FileReader (archivo);
         br = new BufferedReader(fr);
         String linea;
         while((linea=br.readLine())!=null)
         txtArchivo=txtArchivo+"\n"+linea;
      }
      catch(Exception e){
         e.printStackTrace();
      }finally{
         try{
            if( null != fr ){
               fr.close();
            }
         }catch (Exception e2){
            e2.printStackTrace();
         }
      }
      return txtArchivo;
   }

    private PrintWriter Escribir(StringBuffer sb, FileWriter fichero){
       PrintWriter pw = new PrintWriter(fichero);
        String linea=sb.toString();
        String s[]=linea.split("\n");
        for(int i=0;i<s.length;i++){
            pw.println(s[i]);
        }
        return pw;
    }

    public void Crear_Archivo(String salida, StringBuffer texto) {
          FileWriter fichero = null;
          PrintWriter pw = null;
        try
        {
            fichero = new FileWriter(salida);
            pw = Escribir(texto,fichero);;


        } catch (Exception e) {
            e.printStackTrace();
        } finally {
           if (null != fichero)
              try {
                fichero.close();
            } catch (IOException ex) {
            }
           try {
           } catch (Exception e2) {
              e2.printStackTrace();
           }
        }
     }

}

