package SymT;

import java.util.ArrayList;
import java.util.Hashtable;

public class Nodo_Clase {
    private String Nombre="";
    private String Padre="";
    private ArrayList<String> Import=new ArrayList();
    private int TamañoHeap=0;
    private int Visibilidad=0;
    private Hashtable Tabla_Metodos_Variables=new Hashtable();

    public Nodo_Clase() {
    }

/**Nodo_Clase para Herencia
 *
 * @param Nombre
 * @param Padre
 * @param TamañoHeap
 * @param Visibilidad
 * @param Tabla_Metodos_Variables
 */
    public Nodo_Clase(String Nombre, String Padre, int TamañoHeap, int Visibilidad, Hashtable Tabla_Metodos_Variables) {
        this.Nombre = Nombre;
        this.Padre = Padre;
        this.TamañoHeap = TamañoHeap;
        this.Visibilidad = Visibilidad;
        this.Tabla_Metodos_Variables=Tabla_Metodos_Variables;
    }

    
/**Nodo_Clase Sin Import
 *
 * @param Nombre
 * @param Padre
 * @param TamañoHeap
 * @param Visibilidad
 */
    public Nodo_Clase(String Nombre, String Padre, int TamañoHeap, int Visibilidad) {
        this.Nombre = Nombre;
        this.Padre = Padre;
        this.TamañoHeap = TamañoHeap;
        this.Visibilidad = Visibilidad;
    }

/**Nodo_Clase Con Import
 *
 * @param Nombre
 * @param Padre
 * @param Import
 * @param TamañoHeap
 * @param Visibilidad
 */
    public Nodo_Clase(String Nombre, String Padre, ArrayList<String> Import, int TamañoHeap, int Visibilidad) {
        this.Nombre = Nombre;
        this.Padre = Padre;
        this.Import = Import;
        this.TamañoHeap = TamañoHeap;
        this.Visibilidad = Visibilidad;
    }

/**
 * @param Nombre
 * @param Padre
 * @param Visibilidad
 */
    public Nodo_Clase(String Nombre, String Padre, int Visibilidad) {
        this.Nombre = Nombre;
        this.Padre = Padre;
        this.Visibilidad = Visibilidad;
    }
    
/**
 *
 * @param Nombre
 * @param Padre
 */
     public Nodo_Clase(String Nombre, String Padre) {
        this.Nombre = Nombre;
        this.Padre = Padre;
    }

/**
 * @param Nombre
 * @param Visibilidad
 */
      public Nodo_Clase(String Nombre, int Visibilidad) {
        this.Nombre = Nombre;
        this.Visibilidad = Visibilidad;
    }

/**
 * @param Nombre
 */
      public Nodo_Clase(String Nombre) {
        this.Nombre = Nombre;
    }

    
    public Hashtable getTabla_Metodos_Variables() {
        return Tabla_Metodos_Variables;
    }

    public void setTabla_Metodos_Variables(Hashtable Tabla_Metodos_Variables) {
        
        this.Tabla_Metodos_Variables = new Hashtable(Tabla_Metodos_Variables);
    }
    
    public int getTamañoHeap() {
        return TamañoHeap;
    }

    public void setTamañoHeap(int TamañoHeap) {
        this.TamañoHeap = TamañoHeap;
    }

    public int getVisibilidad() {
        return Visibilidad;
    }

    public void setVisibilidad(int Visibilidad) {
        this.Visibilidad = Visibilidad;
    }

    public ArrayList<String> getImport() {
        return Import;
    }

    public void setImport(ArrayList<String> Import) {
        this.Import = new ArrayList(Import);
    }

    public String getPadre() {
        return Padre;
    }

    public void setPadre(String Padre) {
        this.Padre = Padre;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    
}
