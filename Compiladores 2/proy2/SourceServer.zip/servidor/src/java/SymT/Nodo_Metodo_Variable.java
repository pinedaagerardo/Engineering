package SymT;

public class Nodo_Metodo_Variable {

private String Nombre="", Ambito="", ListaArgumentos="void";
private int Posicion, Rol, Visibilidad=0, TamañoPila=0, TamañoHeap=0;
private Boolean Estatico=false, Final=false;
private Nodo_Tipo Tipo;

public Nodo_Metodo_Variable(){
    
}
/**Metodos y Constructores
 *
 * @param Nombre
 * @param Rol
 * @param Ambito
 * @param ListaArgumentos
 * @param Posicion
 * @param Visibilidad
 * @param TamañoPila
 * @param Estatico
 * @param Final
 * @param Nodo_Tipo
 */
    public Nodo_Metodo_Variable(String Nombre, int Rol, String Ambito, String ListaArgumentos, int Visibilidad, int TamañoPila, Boolean Estatico, Boolean Final, Nodo_Tipo Tipo) {
        this.Nombre = Nombre;
        this.Rol = Rol;
        this.Ambito = Ambito;
        this.ListaArgumentos = ListaArgumentos;
        this.Visibilidad = Visibilidad;
        this.TamañoPila = TamañoPila;
        this.Estatico = Estatico;
        this.Final = Final;
        this.Tipo = Tipo;
    }

/**Variables Globales
 * 
 * @param Nombre
 * @param Rol
 * @param Ambito
 * @param Posicion
 * @param Visibilidad
 * @param Estatico
 * @param Final
 * @param Nodo_Tipo
 */
    public Nodo_Metodo_Variable(String Nombre, int Rol, String Ambito, int Posicion, int Visibilidad, Boolean Estatico, Boolean Final, Nodo_Tipo Tipo) {
        this.Nombre = Nombre;
        this.Rol = Rol;
        this.Ambito = Ambito;
        this.Posicion = Posicion;
        this.Visibilidad = Visibilidad;
        this.Estatico = Estatico;
        this.Final = Final;
        this.Tipo = Tipo;
    }


/**Variables Locales
 *
 * @param Nombre
 * @param Rol
 * @param Ambito
 * @param Posicion
 * @param Nodo_Tipo
 */
    public Nodo_Metodo_Variable(String Nombre, int Rol, String Ambito, int Posicion, Nodo_Tipo Tipo) {
        this.Nombre = Nombre;
        this.Rol = Rol;
        this.Ambito = Ambito;
        this.Posicion = Posicion;
        this.Tipo = Tipo;
    }


    public String getAmbito() {
        return Ambito;
    }

    public void setAmbito(String Ambito) {
        this.Ambito = Ambito;
    }

    public Boolean getEstatico() {
        return Estatico;
    }

    public void setEstatico(Boolean Estatico) {
        this.Estatico = Estatico;
    }

    public Boolean getFinal() {
        return Final;
    }

    public void setFinal(Boolean Final) {
        this.Final = Final;
    }

    public String getListaArgumentos() {
        return ListaArgumentos;
    }

    public void setListaArgumentos(String ListaArgumentos) {
        this.ListaArgumentos = ListaArgumentos;
    }

    public String getNombre() {
        return Nombre;
    }
    
    public int getTamañoHeap() {
        return TamañoHeap;
    }

    public void setTamañoHeap(int TamañoHeap) {
        this.TamañoHeap = TamañoHeap;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public int getPosicion() {
        return Posicion;
    }

    public void setPosicion(int Posicion) {
        this.Posicion = Posicion;
    }

    public int getRol() {
        return Rol;
    }

    public void setRol(int Rol) {
        this.Rol = Rol;
    }

    public int getTamañoPila() {
        return TamañoPila;
    }

    public void setTamañoPila(int TamañoPila) {
        this.TamañoPila = TamañoPila;
    }

    public int getVisibilidad() {
        return Visibilidad;
    }

    public void setVisibilidad(int Visibilidad) {
        this.Visibilidad = Visibilidad;
    }

    public Nodo_Tipo getTipo() {
        return Tipo;
    }

    public void setTipo(Nodo_Tipo Tipo) {
        this.Tipo = Tipo;
    }



}
