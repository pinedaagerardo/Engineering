/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package SymT;

import java.util.ArrayList;

public class Nodo_Tipo {

    private String Nombre;
    private ArrayList<Integer> Dimensiones=new ArrayList();

    public Nodo_Tipo(String Nombre, ArrayList<Integer> Dimensiones) {
        this.Nombre = Nombre;
        this.Dimensiones = Dimensiones;
    }

    public Nodo_Tipo(String Nombre) {
        this.Nombre = Nombre;
    }

    public ArrayList<Integer> getDimensiones() {
        return Dimensiones;
    }

    public void setDimensiones(ArrayList<Integer> Dimensiones) {
        this.Dimensiones = new ArrayList(Dimensiones);
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

}
