package SymT;

import SymConst.Papel;
import java.util.ArrayList;
import java.util.Hashtable;

public class Tabla {

private ArrayList<Nodo_Clase> Tabla;

public Tabla() {
        Tabla=new ArrayList();
    }

/**Devuelve el Nodo de la Clase Buscada
     *
     * @param Nombre
     * @return
     */
public Nodo_Clase getClase(String Nombre){
       Nodo_Clase Aux=new Nodo_Clase();
       for(int i=0;i<Tabla.size();i++){
           if(Nombre.equals(Tabla.get(i).getNombre())){
               Aux=Tabla.get(i);
                  break;
           }
       }
       return Aux;
   }

 /**Devuelve el Nodo Completo de Constructor o Metodo
 *
 * @param Clase
 * @param Nombre
 * @param Tipo
 * @param Ambito
 * @param ListaArgumentos
 * @return
 */
 public Nodo_Metodo_Variable getMetodo(String Clase, String Nombre, int Rol, String ListaArgumentos){
       String clave=Nombre+"@"+Rol+"@"+ListaArgumentos;
       Nodo_Clase Aux=getClase(Clase);
        return (Nodo_Metodo_Variable)Aux.getTabla_Metodos_Variables().get(clave);
    }


 /**Devuelve el Nodo Completo de una Variable
 *
 * @param Clase
 * @param Nombre
 * @param Tipo
 * @param Ambito
 * @return
 */
 public Nodo_Metodo_Variable getVariable(String Clase, String Nombre, String Ambito){
       String clave=Nombre+"@"+Ambito;
       Nodo_Clase Aux=getClase(Clase);
        return (Nodo_Metodo_Variable)Aux.getTabla_Metodos_Variables().get(clave);
    }

 /**Devuelve la Tabla de Simbolos Completa
  *
  * @return
  */
 public ArrayList<Nodo_Clase> getTabla() {
        return Tabla;
    }

 /**Inserccion de una Clase que no Posee Imports
    *
    * @param Nombre
    * @param Padre
    * @param TamañoHeap
    * @param Visibilidad
    */
 public void AddClase(String Nombre, String Padre, int TamañoHeap, int Visibilidad){
      Tabla.add(new Nodo_Clase(Nombre,Padre,TamañoHeap, Visibilidad));
   }

/**Inserccion de una Clase solo con Visibilidad y Nombre
 *
 * @param Nombre
 * @param Visibilidad
 */
 public void AddClase(String Nombre, int Visibilidad){
      Tabla.add(new Nodo_Clase(Nombre,Visibilidad));
   }

 public void AddClase(String Nombre){
      Tabla.add(new Nodo_Clase(Nombre));
   }

 /**Inserccion de una Clase que Posee Imports
    *
    * @param Nombre
    * @param Padre
    * @param Import
    * @param TamañoHeap
    * @param Visibilidad
    */
 public void AddClaseWithImport(String Nombre, String Padre, int TamañoHeap, int Visibilidad, ArrayList<String> Import){
      Tabla.add(new Nodo_Clase(Nombre,Padre, Import, TamañoHeap, Visibilidad));
   }

 /**Insertar una Clase que ha sido Heredada
 *
 * @param Nombre
 * @param Padre
 * @param TamañoExtend
 * @param Visibilidad
 */
 public void AddClaseExtends(String Nombre, String Padre,int Visibilidad){
      Nodo_Clase ClasePadre=getClase(Padre);
     getClase(Nombre).setTamañoHeap(ClasePadre.getTamañoHeap());
     Hashtable t=ClasePadre.getTabla_Metodos_Variables();
     getClase(Nombre).setTabla_Metodos_Variables(t);
     AddVariableLocal(Nombre, "$a", Papel.VARLOCAL, "$"+Nombre+"$", 0, Nombre, new ArrayList());
     AddMetodo(Nombre, "$"+Nombre+"$", Papel.CONSTRUCTOR, "", "void", 0, 1, false, false, "constructor");
   }

 public void AddClaseWithSuper(String Nombre, String Padre, int Visibilidad){
      Tabla.add(new Nodo_Clase(Nombre,Padre, Visibilidad));
     }

 public void AddClase(String Nombre, String Padre){
      Tabla.add(new Nodo_Clase(Nombre,Padre));
     }

 /**Agregar un Metodo a la Tabla solo Buscando por el Nombre de la Clase
 *
 * @param NombreClase
 * @param NombreMetodo
 * @param Rol
 * @param Ambito
 * @param ListaArgumentos
 * @param Visibilidad
 * @param TamañoPila
 * @param Estatico
 * @param Final
 * @param Tipo
 */
 public void AddMetodo(String NombreClase, String NombreMetodo, int Rol, String Ambito, String ListaArgumentos, int Visibilidad, int TamañoPila, Boolean Estatico, Boolean Final, String NombreTipo){
       ArrayList<Integer> Dimensiones=new ArrayList();
       Nodo_Tipo Tipo=new Nodo_Tipo(NombreTipo, Dimensiones);
       Nodo_Clase Aux=getClase(NombreClase);
       String clave=NombreMetodo+"@"+Rol+"@"+ListaArgumentos;
        if(Aux.getTabla_Metodos_Variables().containsKey(clave)){
            mensaje("Error Semantico: Se Encontraba Declarado con Anterioridad el Metodo "+NombreMetodo);
        }else{
        Aux.getTabla_Metodos_Variables().put(clave, new Nodo_Metodo_Variable(NombreMetodo, Rol,Ambito,ListaArgumentos,Visibilidad,TamañoPila,Estatico,Final,Tipo));
        }

    }

 /** Agregar una Variables Global a la Tabla
  *
  * @param Clase
  * @param Nombre
  * @param Rol
  * @param Ambito
  * @param Posicion
  * @param Visibilidad
  * @param TamañoPila
  * @param Estatico
  * @param Final
  * @param Tipo
  */
 public void AddVariableGlobal(String Clase, String Nombre, int Rol, String Ambito, int Posicion, int Visibilidad, Boolean Estatico, Boolean Final, String NombreTipo, ArrayList<Integer> Dimensiones){
       Nodo_Tipo Tipo=new Nodo_Tipo(NombreTipo, Dimensiones);

       String clave=Nombre+"@"+Ambito;
       Nodo_Clase Aux=getClase(Clase);

        if(Aux.getTabla_Metodos_Variables().containsKey(clave)){
             mensaje("Error Semantico: Se Encontraba Declarado con Anterioridad la Variable "+Nombre);
        }else{
         String [] ambito=Ambito.split("#");
         if(ambito.length>2){
             String a=ambito[0]+"#"+ambito[1];
             clave=Nombre+"@"+a;
             for(int i=2;i<ambito.length;i++){
                 clave=clave+"#"+ambito[i];
               if(Aux.getTabla_Metodos_Variables().containsKey(clave)){
                   mensaje("Error Semantico: Se Encontraba Declarado con Anterioridad la Variable "+Nombre+" en Ambiente Anterior");
                   return;
               }
             }
         }
        Aux.getTabla_Metodos_Variables().put(clave, new Nodo_Metodo_Variable(Nombre, Rol, Ambito,Posicion,Visibilidad,Estatico,Final,Tipo));
        }
    }

 /**
    * @param Clase
    * @param Nombre
    * @param Rol
    * @param Ambito
    * @param Posicion
    * @param NombreTipo
    * @param Dimensiones
    */
 public void AddVariableGlobal(String Clase, String Nombre, int Rol, String Ambito, int Posicion, String NombreTipo, ArrayList<Integer> Dimensiones){
       Nodo_Tipo Tipo=new Nodo_Tipo(NombreTipo, Dimensiones);

       String clave=Nombre+"@"+Ambito;
       Nodo_Clase Aux=getClase(Clase);

        if(Aux.getTabla_Metodos_Variables().containsKey(clave)){
             mensaje("Error Semantico: Se Encontraba Declarado con Anterioridad la Variable "+Nombre);
        }else{
         String [] ambito=Ambito.split("#");
         if(ambito.length>2){
             String a=ambito[0]+"#"+ambito[1];
             clave=Nombre+"@"+a;
             for(int i=2;i<ambito.length;i++){
                 clave=clave+"#"+ambito[i];
               if(Aux.getTabla_Metodos_Variables().containsKey(clave)){
                   mensaje("Error Semantico: Se Encontraba Declarado con Anterioridad la Variable "+Nombre+" en Ambiente Anterior");
                   return;
               }
             }
         }
        Aux.getTabla_Metodos_Variables().put(clave, new Nodo_Metodo_Variable(Nombre, Rol, Ambito,Posicion,0,false,false,Tipo));
        }
    }

/**Agregar una Variable Local
 *
 * @param Clase
 * @param Nombre
 * @param Rol
 * @param Ambito
 * @param Posicion
 * @param NombreTipo
 * @param Dimensiones
 */
 public void AddVariableLocal(String Clase, String Nombre, int Rol, String Ambito, int Posicion, String NombreTipo, ArrayList<Integer> Dimensiones){
       Nodo_Tipo Tipo=new Nodo_Tipo(NombreTipo, Dimensiones);

       String clave=Nombre+"@"+Ambito;
       Nodo_Clase Aux=getClase(Clase);

        if(Aux.getTabla_Metodos_Variables().containsKey(clave)){
             mensaje("Error Semantico: Se Encontraba Declarado con Anterioridad la Variable "+Nombre);
        }else{
         String [] ambito=Ambito.split("#");
         if(ambito.length>2){
             String a=ambito[0]+"#"+ambito[1];
             clave=Nombre+"@"+a;
             for(int i=2;i<ambito.length;i++){
                 clave=clave+"#"+ambito[i];
               if(Aux.getTabla_Metodos_Variables().containsKey(clave)){
                   mensaje("Error Semantico: Se Encontraba Declarado con Anterioridad la Variable "+Nombre+" en Ambiente Anterior");
                   return;
               }
             }
         }
        Aux.getTabla_Metodos_Variables().put(clave, new Nodo_Metodo_Variable(Nombre, Rol, Ambito, Posicion,Tipo));
        }
 }

 /**
 * 
 * @param Clase
 * @param Nombre
 * @param Rol
 * @param Ambito
 * @param Posicion
 * @param TamañoHeap
 * @param NombreTipo
 */
 public void AddVariableLocal(String Clase, String Nombre, int Rol, String Ambito, int Posicion, String NombreTipo){
       Nodo_Tipo Tipo=new Nodo_Tipo(NombreTipo);
       String clave=Nombre+"@"+Ambito;
       Nodo_Clase Aux=getClase(Clase);

        if(Aux.getTabla_Metodos_Variables().containsKey(clave)){
             mensaje("Error Semantico: Se Encontraba Declarado con Anterioridad la Variable "+Nombre);
        }else{
         String [] ambito=Ambito.split("#");
         if(ambito.length>2){
             String a=ambito[0]+"#"+ambito[1];
             clave=Nombre+"@"+a;
             for(int i=2;i<ambito.length;i++){
                 clave=clave+"#"+ambito[i];
               if(Aux.getTabla_Metodos_Variables().containsKey(clave)){
                   mensaje("Error Semantico: Se Encontraba Declarado con Anterioridad la Variable "+Nombre+" en Ambiente Anterior");
                   return;
               }
             }
         }
        Aux.getTabla_Metodos_Variables().put(clave, new Nodo_Metodo_Variable(Nombre, Rol, Ambito,Posicion,Tipo));
        }
 }

 /**
     * Limpia Tabla de Simbolos
     */
 public void Clear(){
            Tabla.clear();
    }

 /**Verifica si Existe la Variable
       *
       * @param NombreClase
       * @param Nombre
       * @param Tipo
       * @param Ambito
       * @return
       */
 public Boolean ExisteVariable(String NombreClase, String Nombre, String Ambito){
       String clave=Nombre+"@"+Ambito;
       Nodo_Clase Aux=getClase(NombreClase);
        return Aux.getTabla_Metodos_Variables().containsKey(clave);
    }

 public Nodo_Metodo_Variable ExisteVariableEnClase(String NombreClase, String Nombre, String Ambito){
        String ambitos[]=Ambito.split("[#]");
        if(ExisteVariable(NombreClase,Nombre,Ambito)){
           return ((Nodo_Metodo_Variable)getClase(NombreClase).getTabla_Metodos_Variables().get(Nombre+"@"+Ambito));
        }else{
            for(int i=ambitos.length-1;0<i;i--){
             Ambito=Ambito.replace("#"+ambitos[i], "").replace(ambitos[i], "");
            if(ExisteVariable(NombreClase,Nombre,Ambito)){
           return ((Nodo_Metodo_Variable)getClase(NombreClase).getTabla_Metodos_Variables().get(Nombre+"@"+Ambito));
            }
            }
            if(ExisteVariable(NombreClase,Nombre,"")){
           return ((Nodo_Metodo_Variable)getClase(NombreClase).getTabla_Metodos_Variables().get(Nombre+"@"+""));
            }else{
                return null;
            }
        }
        
     }

 /**Verifica si Existe el Metodo
      *
      * @param Clase
      * @param Nombre
      * @param Tipo
      * @param Ambito
      * @param ListaArgumentos
      * @return
      */
 public Boolean ExisteMetodo(String Clase, String Nombre, int Rol, String ListaArgumentos){
       String clave=Nombre+"@"+Rol+"@"+ListaArgumentos;

        Nodo_Clase Aux=getClase(Clase);
        return Aux.getTabla_Metodos_Variables().containsKey(clave);
    }

 /**Verifica si Existe la Clase
  *
  * @param Nombre
  * @return
  */
 public Boolean ExisteClase(String Nombre){
        Boolean Existe=false;
        for(int i=0;i<Tabla.size();i++){
           if(Nombre.equals(Tabla.get(i).getNombre())){
               Existe=true;
               break;
           }
       }
        return Existe;
    }

 /**
     * 
     * @param NombreClase
     * @return
     */
 public String getPadre(String NombreClase){
        String padre="";
         for(int i=0;i<Tabla.size();i++){
           if(NombreClase.equals(Tabla.get(i).getNombre())){
           padre=Tabla.get(i).getPadre();
           break;
           }
       }
        return padre;
    }

 public void mensaje(String texto){
     
 }
}
