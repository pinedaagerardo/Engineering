/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package BlockOpt;


public class NodoB {

    int type = 0;
    String content;
    String blockC;


    public NodoB(String content, String num)
    {
        this.content = content;
        this.blockC = num;
            
    }  

        public String getContent()
     {
        return this.content;
     }

     public String getBlockC ()
     {
        return this.blockC;
     }

   


}
