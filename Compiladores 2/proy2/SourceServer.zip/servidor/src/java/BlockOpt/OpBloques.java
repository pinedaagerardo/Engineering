/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package BlockOpt;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class OpBloques {

    String BlockFile="optimiza_bloques.cpp";
    String finalDir = "";
    String gDir = "c:\\Archivos de programa\\Graphviz2.24\\bin\\dot.exe";

    ArrayList<NodoR> run = new ArrayList();
    ArrayList<NodoR> run2 = new ArrayList();
    ArrayList<NodoL> link = new ArrayList();
    ArrayList<NodoB> nodo = new ArrayList();
    ArrayList<String> padres = new ArrayList();
    ArrayList<Nodo2> exp = new ArrayList();
    ArrayList<String> lista = new ArrayList();
    String base = "";
    String file = "";

    public OpBloques(String path){
        finalDir=path+"\\";
    }

    public void mover(String filename, String out)
    {
         String fileIn = finalDir+filename;

        try
        {
            FileReader fr = new FileReader(fileIn);
            BufferedReader  br = new BufferedReader(fr);
            String linea="",etiquetaActual = "", etiquetaSeVa = "", blo= "";
            Boolean pasoIf=false, pasoGoto=false, pasoEtiqueta=false;
            int i = 1;
            String nBlockFile = finalDir+BlockFile;
            Escritor finalBlockFile = new Escritor(nBlockFile);
            Escritor finalFile = new Escritor(finalDir+out);

            while((linea=br.readLine())!=null)
            {
                     if(linea.startsWith("#include") || (linea.startsWith("int")&& linea.contains(";")))
                      {
                             finalBlockFile.println(linea);
                      }
                      else if(linea.startsWith("$t") && (linea.contains(",")))
                         {
                            finalBlockFile.println(linea);
                         }
                     else if((linea.startsWith("int")||linea.startsWith("void"))&& linea.contains("()"))
                      {
                             finalBlockFile.println(linea);
                      }
                     else if(linea.startsWith("}"))
                     {
                                  if(blo.equalsIgnoreCase("")==false)
                                     {
                                        link.add(new NodoL(etiquetaActual));
                                        run.add(new NodoR(etiquetaActual));
                                        nodo.add(new NodoB(blo,etiquetaActual));
                                     }
                          blo = "";
                          pasoIf =false;
                          pasoGoto = false;
                          pasoEtiqueta = false;
                          i++;

                         printCont();
                         divideExpr();

                              for(int m = 0;m<exp.size();m++)
                              {
                                 if(exp.get(m).getLadoIzquierdo()!=null && exp.get(m).getTipo() != 7)
                                            {
                                               if(exp.get(m).getTipo() == 1)
                                               {
                                                   if(exp.get(m).getexp1()!=null)
                                                   {
                                                        finalBlockFile.println(exp.get(m).getLadoIzquierdo()+exp.get(m).getexp1());
                                                   }
                                                   else
                                                   {
                                                        finalBlockFile.println(exp.get(m).getLadoIzquierdo());
                                                   }

                                               }
                                               else
                                               {
                                                finalBlockFile.println(exp.get(m).getLadoIzquierdo()+";");
                                               }
                                           }
                                            else
                                            {

                                                 if(exp.get(m).signo()!=null&&exp.get(m).getexp2()!=null && exp.get(m).getLadoIzquierdo() !=null)
                                                    {
                                                        finalBlockFile.println(exp.get(m).getLadoIzquierdo()+ " = "+exp.get(m).getexp1()+
                                                               " "+exp.get(m).signo()+" "+exp.get(m).getexp2()+";");

                                                    }
                                                  if(exp.get(m).signo()==null&&exp.get(m).getexp2()==null && exp.get(m).getLadoIzquierdo() !=null)
                                                    {
                                                       finalBlockFile.println(exp.get(m).getLadoIzquierdo()+ " = "+exp.get(m).getexp1()+";");
                                                    }
                                            }
                               }

                                            for(int n = 0; n<nodo.size(); n++)
                                         {
                                             finalFile.println("            "+nodo.get(n).getBlockC()+nodo.get(n).getContent());
                                             finalFile.println("");
                                         }

                              exp.clear();
                              nodo.clear();
                              run.clear();
                              finalBlockFile.println(linea);
                              finalBlockFile.println("");
                     }
                     else
                     {
                          if(linea.trim().equalsIgnoreCase("")==false)
                          {
                                  if(linea.startsWith("L")==false && linea.startsWith("if")==false
                                   && linea.startsWith("goto")==false)
                                         {
                                                          if(pasoEtiqueta==false && pasoIf ==false && pasoGoto ==false)
                                                          {
                                                              etiquetaActual = "n"+i;
                                                          }
                                                          if(pasoIf==true)
                                                          {
                                                            nodo.add(new NodoB(blo,etiquetaActual));
                                                            blo = "";
                                                            i++;
                                                            etiquetaSeVa = "n"+i;

                                                            link.add(new NodoL(etiquetaActual,etiquetaSeVa));
                                                            run.add(new NodoR(etiquetaActual,etiquetaSeVa));
                                                            etiquetaActual = "n"+i;
                                                            pasoIf = false;

                                                          }
                                                          if(pasoGoto == true)
                                                          {
                                                               nodo.add(new NodoB(blo,etiquetaActual));
                                                               blo= "";
                                                               i++;
                                                               pasoGoto = false;
                                                          }
                                                          blo = blo + linea.trim()+"\n";

                                                }
                                           if(linea.startsWith("L"))
                                                {
                                                          if(blo.equalsIgnoreCase("")==false)
                                                          {

                                                            etiquetaSeVa = linea.substring(0,linea.indexOf(":"));
                                                                if(pasoGoto ==false)
                                                                     {

                                                                       link.add(new NodoL(etiquetaActual,etiquetaSeVa));
                                                                       run.add(new NodoR(etiquetaActual,etiquetaSeVa));
                                                                     }

                                                             nodo.add(new NodoB(blo,etiquetaActual));
                                                             blo = "";
                                                             i++;
                                                             etiquetaActual = etiquetaSeVa;

                                                          }
                                                            else
                                                          {
                                                                 etiquetaActual = linea.substring(0,linea.indexOf(":"));
                                                          }

                                                     blo = blo + linea+"\n";

                                                     pasoIf = false;
                                                     pasoGoto = false;
                                                     pasoEtiqueta = true;

                                              }

                                              if( linea.startsWith("if")== true)
                                                {
                                                           if(pasoIf==true || pasoGoto==true || blo.equalsIgnoreCase(""))
                                                               {
                                                                 nodo.add(new NodoB(blo,etiquetaActual));
                                                                 blo = "";
                                                                 i++;
                                                                 blo = blo + linea.trim()+ "\n";

                                                                 link.add(new NodoL(etiquetaActual,"n"+i));
                                                                 run.add(new NodoR(etiquetaActual,"n"+i));

                                                                 etiquetaActual = "n"+i;

                                                                 etiquetaSeVa =  linea.substring(linea.indexOf("L"),linea.indexOf(";"));

                                                                 link.add(new NodoL(etiquetaActual,etiquetaSeVa));
                                                                 run.add(new NodoR(etiquetaActual,etiquetaSeVa));
                                                                }
                                                               else
                                                               {
                                                                    blo = blo + linea.trim()+ "\n";
                                                                    etiquetaSeVa =  linea.substring(linea.indexOf("L"),linea.indexOf(";"));

                                                                    link.add(new NodoL(etiquetaActual,etiquetaSeVa));
                                                                    run.add(new NodoR(etiquetaActual,etiquetaSeVa));

                                                               }

                                                              pasoIf = true;
                                                              pasoGoto = false;
                                                              pasoEtiqueta = false;

                                            }
                                            if(linea.startsWith("goto")==true)
                                            {
                                                     if(pasoIf==true || pasoGoto==true || blo.equalsIgnoreCase(""))
                                                               {
                                                                     nodo.add(new NodoB(blo,etiquetaActual));
                                                                     blo = "";
                                                                      i++;
                                                                     blo = blo + linea.trim()+ "\n";

                                                                     link.add(new NodoL(etiquetaActual,"n"+i));
                                                                     run.add(new NodoR(etiquetaActual,"n"+i));
                                                                     etiquetaActual = "n"+i;

                                                                     etiquetaSeVa =  linea.substring(linea.indexOf("L"),linea.indexOf(";"));

                                                                     link.add(new NodoL(etiquetaActual,etiquetaSeVa));
                                                                     run.add(new NodoR(etiquetaActual,etiquetaSeVa));

                                                                }
                                                               else
                                                               {
                                                                  blo = blo + linea+ "\n";
                                                                  etiquetaSeVa =  linea.substring(linea.indexOf("L"),linea.indexOf(";"));
                                                                  link.add(new NodoL(etiquetaActual,etiquetaSeVa));
                                                                  run.add(new NodoR(etiquetaActual,etiquetaSeVa));
                                                               }

                                                              pasoIf = false;
                                                              pasoGoto = true;
                                                              pasoEtiqueta = false;

                                                         }

                                        }

                         }
            }

            finalBlockFile.close();
            finalFile.close();
            asm.Asm tmp=new asm.Asm(nBlockFile);//genera .asm
        }
              catch(java.io.IOException ioex)
        {
            System.out.println("se presento el error: "+ioex.toString());
        }

    }


public void createGraph(String in, String out)
{
     try {

      String dotPath = gDir;

      String fileInputPath = finalDir+in;
      String fileOutputPath = finalDir+out;

      String tParam = "-Tjpg";
      String tOParam = "-o";

      String[] cmd = new String[5];
      cmd[0] = dotPath;
      cmd[1] = tParam;
      cmd[2] = fileInputPath;
      cmd[3] = tOParam;
      cmd[4] = fileOutputPath;

      Runtime rt = Runtime.getRuntime();

      rt.exec( cmd );

    } catch (Exception ex) {
      ex.printStackTrace();
    } finally {
    }
}

public void printCont()
     {
         for(int i = 0; i<link.size(); i++)
         {
              if(link.get(i).getLink()!=null)
              {
                  lista.add(link.get(i).getCode());
                  lista.add(link.get(i).getLink());
              }
         }

}

public void draw(String nombre)
{
       Escritor gr = new Escritor(finalDir+nombre);
        gr.println("digraph G {");
        gr.println("rankdir=LR;");

                   for(int i = 0; i<link.size(); i++)
                     {
                       if(link.get(i).getLink()!=null)
                       {
                         gr.println(link.get(i).getCode()+" -> "+link.get(i).getLink() );
                       }
                       else
                       {
                        gr.println(link.get(i).getCode());
                       }
                     }

                 gr.println("}");
                 gr.close();


     }

public void divideExpr()
    {
        for(int i = 0; i<nodo.size();i++)
        {
            int j = 0;
            String bloq = nodo.get(i).getContent();
            String [] lineas = bloq.split("\n");
            String blo = nodo.get(i).getBlockC().trim();

            while(j<lineas.length)
            {
                if(lineas[j].contains("=") && lineas[j].contains("if")==false && lineas[j].contains("int")==false)
                {
                    String li = lineas[j].trim();
                    String der = li.substring(li.indexOf("=")+1,li.length());
                    String izq= li.substring(0,li.indexOf("="));

                    if(der.contains("+"))
                            {
                                String exp1 = der.substring(der.indexOf("+")+1,der.length());
                                String exp2 = der.substring(0,der.indexOf("+"));
                                exp.add(new Nodo2(blo,izq.trim(),exp2.trim(),"+",exp1.trim().replace(";", ""),7));

                            }
                            else if(der.contains("-"))
                            {
                                String exp1 = der.substring(der.indexOf("-")+1,der.length());
                                String exp2 = der.substring(0,der.indexOf("-"));
                                exp.add(new Nodo2(blo,izq.trim(),exp2.trim(),"-",exp1.trim().replace(";", ""),7));
                            }
                            else if(der.contains("*"))
                            {
                                String exp1 = der.substring(der.indexOf("*")+1,der.length());
                                String exp2 = der.substring(0,der.indexOf("*"));
                                exp.add(new Nodo2(blo,izq.trim(),exp2.trim(),"*",exp1.trim().replace(";", ""),7));
                            }
                            else if(der.contains("/"))
                            {
                                String exp1 = der.substring(der.indexOf("/")+1,der.length());
                                String exp2 = der.substring(0,der.indexOf("/"));
                                exp.add(new Nodo2(blo,izq.trim(),exp2.trim(),"/",exp1.trim().replace(";", ""),7));
                            }
                            else if(der.contains("&&"))
                            {
                                String exp1 = der.substring(der.indexOf("&")+2,der.length());
                                String exp2 = der.substring(0,der.indexOf("&"));
                                exp.add(new Nodo2(blo,izq.trim(),exp2.trim(),"&&",exp1.trim().replace(";", ""),7));
                            }
                             else if(der.contains("||"))
                            {
                                String exp1 = der.substring(der.indexOf("|")+2,der.length());
                                String exp2 = der.substring(0,der.indexOf("|"));
                                exp.add(new Nodo2(blo,izq.trim(),exp2.trim(),"||",exp1.trim().replace(";", ""),7));
                            }
                             else if(der.contains("<="))
                            {
                                String exp1 = der.substring(der.indexOf("<")+2,der.length());
                                String exp2 = der.substring(0,der.indexOf("<"));
                                exp.add(new Nodo2(blo,izq.trim(),exp2.trim(),"<=",exp1.trim().replace(";", ""),7));
                            }
                            else if(der.contains(">="))
                            {
                                String exp1 = der.substring(der.indexOf(">")+2,der.length());
                                String exp2 = der.substring(0,der.indexOf(">"));
                                exp.add(new Nodo2(blo,izq.trim(),exp2.trim(),">=",exp1.trim().replace(";", ""),7));
                            }
                             else if(der.contains(">"))
                            {
                                String exp1 = der.substring(der.indexOf(">")+1,der.length());
                                String exp2 = der.substring(0,der.indexOf(">"));
                                exp.add(new Nodo2(blo,izq.trim(),exp2.trim(),">",exp1.trim().replace(";", ""),7));
                            }
                            else if(der.contains("%"))
                            {
                                String exp1 = der.substring(der.indexOf("%")+1,der.length());
                                String exp2 = der.substring(0,der.indexOf("%"));
                                exp.add(new Nodo2(blo,izq.trim(),exp2.trim(),"%",exp1.trim().replace(";", ""),7));
                            }
                             else if(der.contains("<"))
                            {
                                String exp1 = der.substring(der.indexOf("<")+2,der.length());
                                String exp2 = der.substring(0,der.indexOf("<"));
                                exp.add(new Nodo2(blo,izq.trim(),exp2.trim(),"<",exp1.trim().replace(";", ""),7));
                            }
                            else if(der.contains("=="))
                            {
                                String exp1 = der.substring(der.indexOf("=",6)+2,der.length());
                                String exp2 = der.substring(0,der.indexOf("=",6));
                                exp.add(new Nodo2(blo,izq.trim(),exp2.trim(),"==",exp1.trim().replace(";", ""),7));
                            }
                            else if(der.contains("!="))
                            {
                                String exp1 = der.substring(der.indexOf("!")+2,der.length());
                                String exp2 = der.substring(0,der.indexOf("!"));
                                exp.add(new Nodo2(blo,izq.trim(),exp2.trim(),"!=",exp1.trim().replace(";", ""),7));
                            }
                            else
                            {
                                exp.add(new Nodo2(blo,izq.trim(),der.trim().replace(";", ""),7));
                            }


                }
                else if(lineas[j].contains("L")&&lineas[j].contains(":"))
                {
                       if(lineas[j].contains(";"))
                              {
                                exp.add(new Nodo2(blo.trim(),lineas[j].trim().replace(";", ""),";",1));
                              }
                              else
                              {
                                exp.add(new Nodo2(blo.trim(),lineas[j].trim(),1));
                              }
                }
                else if(lineas[j].contains("if"))
                {
                        exp.add(new Nodo2(blo.trim(),lineas[j].trim().replace(";", ""),2));
                }
                else if(lineas[j].contains("goto") && lineas[j].contains("if")==false)
                {
                        exp.add(new Nodo2(blo.trim(),lineas[j].trim().replace(";", ""),3));
                }
                else if(lineas[j].contains("()")&&lineas[j].contains(";"))
                {
                        exp.add(new Nodo2(blo.trim(),lineas[j].trim().replace(";", ""),4));
                }
                else if(lineas[j].contains("printf"))
                {
                        exp.add(new Nodo2(blo.trim(),lineas[j].trim().replace(";", ""),5));
                }
                else if(lineas[j].contains("scanf"))
                {
                        exp.add(new Nodo2(blo.trim(),lineas[j].trim().replace(";", ""),6));
                }
                else if(lineas[j].contains("return"))
                {
                        exp.add(new Nodo2(blo.trim(),lineas[j].trim().replace(";", ""),8));
                }

                j++;
            }

        }
        cSubExp();
    }

public void cSubExp()
{
   Boolean bandera = false;
   Boolean Asig = false;
   String izquierI = "";
   String izquierJ = "";
   String dereI = "";
   String dereI2 = "";

   for(int i = 0; i<exp.size();i++)
    {
        for(int j = i+1;j<exp.size();j++)
        {
                 if(exp.get(i).getBloque().equalsIgnoreCase(exp.get(j).getBloque()) && i!= j
                         && exp.get(i).SePuedeOpt() && exp.get(j).SePuedeOpt())
                    {
                      dereI = exp.get(i).Exp1();
                      dereI2 = exp.get(i).Exp2();

                      if(exp.get(j).getTipo() == 7 && exp.get(i).getTipo() == 7 &&
                           exp.get(j).getLadoIzquierdo()!= null &&
                            ((dereI!= null && exp.get(j).getLadoIzquierdo().contains(dereI)) ||
                            (dereI2!= null&& exp.get(j).getLadoIzquierdo().contains(dereI2))))
                            {

                                   Asig = true;

                            }
                       if(exp.get(i).getLadoIzquierdo() !=null && exp.get(j).getLadoIzquierdo() != null  && Asig ==false &&
                       exp.get(i).LadoDerecho() !=null && exp.get(j).LadoDerecho() != null  &&
                            exp.get(i).LadoDerecho().equalsIgnoreCase(exp.get(j).LadoDerecho()))
                                {
                                    izquierI = exp.get(i).getLadoIzquierdo();
                                    izquierJ = exp.get(j).getLadoIzquierdo();

                                                        if(izquierJ!= null && izquierI != null &&
                                                            izquierJ.startsWith("$t") && izquierI.startsWith("$t"))
                                                        {
                                                              exp.get(j).setIzq(null);
                                                              bandera = true;
                                                        }
                                                         if(izquierJ!= null && izquierI != null &&
                                                            izquierJ.startsWith("$t")==false && izquierI.startsWith("$t"))
                                                        {
                                                                String blo = exp.get(j).getBloque();
                                                                String izq = exp.get(j).getLadoIzquierdo();
                                                                int tipo = exp.get(j).getTipo();
                                                                exp.set(j,new Nodo2(blo,izq,izquierI,tipo));

                                                        }

                                 }

                                if(exp.get(j).getLadoIzquierdo()!= null && bandera ==true
                                    && exp.get(j).getLadoIzquierdo().contains(izquierJ))
                                {

                                    if(exp.get(j).getLadoIzquierdo().contains(izquierJ+"0") == false && exp.get(j).getLadoIzquierdo().contains(izquierJ+"1") == false
                                            && exp.get(j).getLadoIzquierdo().contains(izquierJ+"2") == false && exp.get(j).getLadoIzquierdo().contains(izquierJ+"3") == false
                                            && exp.get(j).getLadoIzquierdo().contains(izquierJ+"4") == false && exp.get(j).getLadoIzquierdo().contains(izquierJ+"5") == false
                                            && exp.get(j).getLadoIzquierdo().contains(izquierJ+"6") == false && exp.get(j).getLadoIzquierdo().contains(izquierJ+"7") == false
                                            && exp.get(j).getLadoIzquierdo().contains(izquierJ+"8") == false && exp.get(j).getLadoIzquierdo().contains(izquierJ+"9") == false){

                                                    String blo = exp.get(j).getBloque();
                                                    String izq= exp.get(j).getLadoIzquierdo().replace(izquierJ, izquierI);
                                                    String exp1 = exp.get(j).getexp1();
                                                    String exp2 = exp.get(j).getexp2();
                                                    String signo = exp.get(j).signo();
                                                    int tipo = exp.get(j).getTipo();

                                                     exp.set(j,new Nodo2(blo,izq,exp1,signo,exp2,tipo));
                                    }

                                }

                              if(exp.get(j).getLadoIzquierdo()!= null && exp.get(j).LadoDerecho()!= null &&
                                    bandera ==true && exp.get(j).LadoDerecho().contains(izquierJ))
                                {
                                  if(exp.get(j).LadoDerecho().contains(izquierJ+"0") == false && exp.get(j).LadoDerecho().contains(izquierJ+"1") == false
                                            && exp.get(j).LadoDerecho().contains(izquierJ+"2") == false && exp.get(j).LadoDerecho().contains(izquierJ+"3") == false
                                            && exp.get(j).LadoDerecho().contains(izquierJ+"4") == false && exp.get(j).LadoDerecho().contains(izquierJ+"5") == false
                                            && exp.get(j).LadoDerecho().contains(izquierJ+"6") == false && exp.get(j).LadoDerecho().contains(izquierJ+"7") == false
                                            && exp.get(j).LadoDerecho().contains(izquierJ+"8") == false && exp.get(j).LadoDerecho().contains(izquierJ+"9") == false)
                                  {
                                            String blo = exp.get(j).getBloque();
                                            String izq= exp.get(j).getLadoIzquierdo();
                                            String exp1 = exp.get(j).getexp1();
                                            String exp2 = exp.get(j).getexp2();
                                            String signo = exp.get(j).signo();
                                            int tipo = exp.get(j).getTipo();

                                            if(exp1.contains(izquierJ))
                                            {
                                               exp1 = exp1.replace(izquierJ, izquierI);
                                            }

                                              if(exp2!= null &&exp2.contains(izquierJ))
                                             {
                                               exp2 = exp2.replace(izquierJ, izquierI);

                                              }

                                             if(exp2!=null&&signo!=null)
                                              {
                                                       exp.set(j,new Nodo2(blo,izq,exp1,signo,exp2,tipo));
                                              }

                                            if(exp2==null&&signo==null)
                                            {
                                                        exp.set(j,new Nodo2(blo,izq,exp1,tipo));
                                            }

                                }
                              }

                           }

        }
        Asig = false;
        bandera = false;
    }
PCopies();
}

public void road_proc(String left, Boolean begin)
{
    if(begin ==true)
    {
        run2.addAll(run);
    }

    String nuevo;

    for(int i = 0; i<run2.size();i++)
    {
        if(run2.get(i).getLink()!=null && run2.get(i).getLink().equalsIgnoreCase(left)
               )
        {
            nuevo = run2.get(i).getCode();

            if(run2.get(i).getCode().equalsIgnoreCase(base)==false)
            {
                padres.add(run2.get(i).getCode());
            }
            run2.remove(i);
            road_proc(nuevo, false);
        }

    }

}

public ArrayList<String> followRoad()
{
    ArrayList<String> li = new ArrayList();


    for(int i = 0; i<padres.size();i++)
    {
        li.add(padres.get(i));

    }

    road_proc(base, false);

     return li;

}

public void cBSubExp()
{
   Boolean bandera = false;
   Boolean Asig = false;
   String izquierI = "";
   String izquierJ = "";
   String dereI = "";
   String dereI2 = "";

   HashSet hashset = new HashSet();
   hashset.addAll(lista);

   Iterator i_hs = hashset.iterator();


     while (i_hs.hasNext())
        {
                 base = i_hs.next().toString();
                 road_proc(base,true);

       for(int n = 0; n<followRoad().size();n++)
        {

            for(int i = 0;i<exp.size();i++)
            {
                if(exp.get(i).getBloque().equalsIgnoreCase(followRoad().get(n)))
                {
                                for(int j = i+1;j<exp.size();j++)
                                {
                                    if(exp.get(j).getBloque().equalsIgnoreCase(base)
                                                 && exp.get(i).getBloque().equalsIgnoreCase(followRoad().get(n))
                                                 && exp.get(i).getBloque().equalsIgnoreCase(exp.get(j).getBloque())==false
                                                 && i!= j
                                                 && exp.get(i).SePuedeOpt() && exp.get(j).SePuedeOpt())
                                            {

                                                      dereI = exp.get(i).Exp1();
                                                      dereI2 = exp.get(i).Exp2();

                                                       for(int k = 0;k<exp.size();k++)
                                                      {
                                                         if(exp.get(j).getTipo() == 7 && exp.get(i).getTipo() == 7 && exp.get(k).getTipo() == 7 &&
                                                                exp.get(k).getLadoIzquierdo()!= null &&
                                                                ((dereI!= null && exp.get(k).getLadoIzquierdo().contains(dereI)) ||
                                                                 (dereI2!= null&& exp.get(k).getLadoIzquierdo().contains(dereI2))))
                                                            {
                                                                    Asig = true;
                                                            }
                                                      }

                                                         if(exp.get(i).getLadoIzquierdo() !=null && exp.get(j).getLadoIzquierdo() != null
                                                            && Asig == false &&
                                                            exp.get(i).LadoDerecho() !=null && exp.get(j).LadoDerecho() != null  &&
                                                            exp.get(i).LadoDerecho().equalsIgnoreCase(exp.get(j).LadoDerecho()))
                                                                {
                                                                    izquierI = exp.get(i).getLadoIzquierdo();
                                                                    izquierJ = exp.get(j).getLadoIzquierdo();

                                                                                        if(izquierJ!= null && izquierI != null &&
                                                                                            izquierJ.startsWith("$t") && izquierI.startsWith("$t"))
                                                                                        {

                                                                                              exp.get(j).setIzq(null);
                                                                                              bandera = true;
                                                                                        }
                                                                                         if(izquierJ!= null && izquierI != null &&
                                                                                            izquierJ.startsWith("$t")==false && izquierJ.startsWith("$t"))
                                                                                        {
                                                                                                String blo = exp.get(j).getBloque();
                                                                                                String izq = exp.get(j).getLadoIzquierdo();
                                                                                                int tipo = exp.get(j).getTipo();
                                                                                                exp.set(j,new Nodo2(blo,izq,izquierI,tipo));

                                                                                        }

                                                                 }

                                                                if(exp.get(j).getLadoIzquierdo()!= null && bandera ==true
                                                                    && exp.get(j).getLadoIzquierdo().contains(izquierJ))
                                                                {

                                                                    if(exp.get(j).getLadoIzquierdo().contains(izquierJ+"0") == false && exp.get(j).getLadoIzquierdo().contains(izquierJ+"1") == false
                                                                            && exp.get(j).getLadoIzquierdo().contains(izquierJ+"2") == false && exp.get(j).getLadoIzquierdo().contains(izquierJ+"3") == false
                                                                            && exp.get(j).getLadoIzquierdo().contains(izquierJ+"4") == false && exp.get(j).getLadoIzquierdo().contains(izquierJ+"5") == false
                                                                            && exp.get(j).getLadoIzquierdo().contains(izquierJ+"6") == false && exp.get(j).getLadoIzquierdo().contains(izquierJ+"7") == false
                                                                            && exp.get(j).getLadoIzquierdo().contains(izquierJ+"8") == false && exp.get(j).getLadoIzquierdo().contains(izquierJ+"9") == false){

                                                                                    String blo = exp.get(j).getBloque();
                                                                                    String izq= exp.get(j).getLadoIzquierdo().replace(izquierJ, izquierI);
                                                                                    String exp1 = exp.get(j).getexp1();
                                                                                    String exp2 = exp.get(j).getexp2();
                                                                                    String signo = exp.get(j).signo();
                                                                                    int tipo = exp.get(j).getTipo();

                                                                                     exp.set(j,new Nodo2(blo,izq,exp1,signo,exp2,tipo));
                                                                    }

                                                                }

                                                            if(exp.get(j).getLadoIzquierdo()!= null &&exp.get(j).LadoDerecho()!= null &&
                                                                    bandera ==true && exp.get(j).LadoDerecho().contains(izquierJ))
                                                                {
                                                                  if(exp.get(j).LadoDerecho().contains(izquierJ+"0") == false && exp.get(j).LadoDerecho().contains(izquierJ+"1") == false
                                                                            && exp.get(j).LadoDerecho().contains(izquierJ+"2") == false && exp.get(j).LadoDerecho().contains(izquierJ+"3") == false
                                                                            && exp.get(j).LadoDerecho().contains(izquierJ+"4") == false && exp.get(j).LadoDerecho().contains(izquierJ+"5") == false
                                                                            && exp.get(j).LadoDerecho().contains(izquierJ+"6") == false && exp.get(j).LadoDerecho().contains(izquierJ+"7") == false
                                                                            && exp.get(j).LadoDerecho().contains(izquierJ+"8") == false && exp.get(j).LadoDerecho().contains(izquierJ+"9") == false)
                                                                  {
                                                                            String blo = exp.get(j).getBloque();
                                                                            String izq= exp.get(j).getLadoIzquierdo();
                                                                            String exp1 = exp.get(j).getexp1();
                                                                            String exp2 = exp.get(j).getexp2();
                                                                            String signo = exp.get(j).signo();
                                                                            int tipo = exp.get(j).getTipo();

                                                                            if(exp1.contains(izquierJ))
                                                                            {
                                                                               exp1 = exp1.replace(izquierJ, izquierI);
                                                                            }

                                                                              if(exp2!= null &&exp2.contains(izquierJ))
                                                                             {
                                                                               exp2 = exp2.replace(izquierJ, izquierI);

                                                                              }

                                                                             if(exp2!=null&&signo!=null)
                                                                              {
                                                                                       exp.set(j,new Nodo2(blo,izq,exp1,signo,exp2,tipo));
                                                                              }

                                                                            if(exp2==null&&signo==null)
                                                                            {
                                                                                        exp.set(j,new Nodo2(blo,izq,exp1,tipo));
                                                                            }

                                                                }
                                                              }



                                            }

                                }
                                Asig = false;
                                bandera = false;
                }

            }


        }
   }


}

public void PCopies()
{
   Boolean Asig = false;
   String dereI = "";
   String dereI2 = "";

   for(int i = 0; i<exp.size();i++)
    {
        for(int j = i+1;j<exp.size();j++)
        {
                 if(exp.get(i).getBloque().equalsIgnoreCase(exp.get(j).getBloque()) && i!= j
                         && exp.get(i).SePuedeOpt() && exp.get(j).SePuedeOpt())
                    {
                      dereI = exp.get(i).Exp1();
                      dereI2 = exp.get(i).Exp2();


                         if(exp.get(j).getTipo() == 7 && exp.get(i).getTipo() == 7 &&
                                exp.get(j).getLadoIzquierdo()!= null &&
                                ((dereI!= null && exp.get(j).getLadoIzquierdo().contains(dereI)) ||
                                 (dereI2!= null&& exp.get(j).getLadoIzquierdo().contains(dereI2))))
                            {

                                    if(exp.get(i).LadoDerecho()!=null && exp.get(j).LadoDerecho() != null && Asig ==false &&
                                    exp.get(i).LadoDerecho().equalsIgnoreCase(exp.get(j).LadoDerecho()))
                                    {
                                       exp.set(j,new Nodo2(exp.get(j).getBloque(),exp.get(j).getLadoIzquierdo(),exp.get(i).getLadoIzquierdo(),7));

                                    }
                                    Asig = true;
                            }



                 }
        }
        Asig = false;

   }


}

}
