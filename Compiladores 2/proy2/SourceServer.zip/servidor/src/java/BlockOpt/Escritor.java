/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package BlockOpt;


import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;

public class Escritor {

    FileWriter fw;
    BufferedWriter bw;
    PrintWriter out;

    public Escritor(String name)
    {
         try
        {
            fw = new FileWriter(name);
            out = new PrintWriter(fw);
         
        }

        catch(java.io.IOException ioex){}

    }


    public void println(String txt)
    {
        out.println(txt);
    }

    public void close()
    {
       out.close();
    }

    public void erase()
    {
        out.write("");
    }

}
