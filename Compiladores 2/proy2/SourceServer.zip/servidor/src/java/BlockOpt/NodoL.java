/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package BlockOpt;


public class NodoL {

     String code;
     String link;
   
    


    public NodoL(String code, String link)
    {
        this.code = code;
        this.link = link;
        

    }
    
    public NodoL(String code)
    {
        this.code = code;
         
    }

       public String getCode()
     {
        return this.code;
     }

     public String getLink ()
     {
        return this.link;
     }

       

    
  

}
