/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package BlockOpt;

public class Nodo2
{
    String izquierdo;
    String exp1;
    String bloque;
    String exp2;
    String signo;
    int tipo =0;

    public Nodo2(String bloque,String Izquierdo, String exp1, String signo, String exp2, int tipo)
    {
        this.izquierdo = Izquierdo;        
        this.bloque = bloque;
        this.exp1 = exp1;
        this.exp2 = exp2;
        this.signo = signo;
        this.tipo = tipo;
     

    }

    public Nodo2(String bloque,String Izquierdo, String exp1, int tipo)
    {
        this.izquierdo = Izquierdo;
        this.bloque = bloque;
        this.exp1 = exp1;
        this.tipo = tipo;
      

    }

     public Nodo2(String bloque,String Izquierdo, int tipo)
    {
        this.izquierdo = Izquierdo;
        this.bloque = bloque;
        this.tipo = tipo;
       

    }

        public String getexp1()
     {
        return this.exp1;
     }

        public String getexp2()
     {
        return this.exp2;
     }

        public String signo()
     {
        return this.signo;
     }

     public String getLadoIzquierdo ()
     {
        return this.izquierdo;
     }

       public void setIzq(String izq)
     {
         this.izquierdo = izq;

     }




     public String getBloque ()
     {

        return this.bloque;
     }

    
      public int getTipo ()
     {
        return this.tipo;
     }

     public String Exp1()
     {
          if(tipo==7 && exp1!=null && signo != null && exp2 != null && exp1.matches("[a-zA-Z][[0-9]|[a-zA-Z]|[_]|[$]]*"))
         {
            return exp1;
         }

         if(tipo==7 && exp1!=null && signo ==null && exp2 == null && (exp1.matches("[a-zA-Z][[0-9]|[a-zA-Z]|[_]|[$]]*") ||
                  exp1.contains("[")))
         {
             if(exp1.contains("["))
             {
                  return exp1.replace(exp1.substring(exp1.indexOf("[")+1),"");

             }
             else
             {
                return exp1;
             }
            
         }

        return null;
     }

     public String Exp2()
     {
         if(tipo==7 && exp1!=null && signo != null && exp2 != null  && exp2.matches("[a-zA-Z][[0-9]|[a-zA-Z]|[_]|[$]]*") )
         {
            return exp2;
         }

         return null;
     }

     
     public String LadoDerecho()
     {
        if(tipo==7 && exp1!=null && signo != null && exp2 != null)
        {
            return  exp1 + signo +exp2;
        }

        if(tipo==7 && exp1!=null && signo == null && exp2 == null)
        {
            return  exp1;
        }

        return null;
     }


     public Boolean SePuedeOpt()
     {
         if(tipo ==2 || tipo ==5 || tipo ==6 || tipo == 7)
         {
            return true;
         }

         return false;
     }

     

      public Boolean NoExpresion()
     {
         if(tipo ==2 || tipo ==5 || tipo ==6)
         {
            return true;
         }

         return false;
     }


}
