/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package SymConst;

public class SConstantes {
    public static final Boolean GLOBAL=true;
    public static final Boolean LOCAL=false;
    public static final Boolean EXPLICITA=true;
    public static final Boolean IMPLICITA=false;
}
