

package SymConst;

public class Papel {
    public static final int VARGLOBAL = 0;
    public static final int CONSTRUCTOR = 1;
    public static final int METODO = 2;
    public static final int VARLOCAL = 3;
}
