
package SymConst;

public class Mod {
    public static final int FINAL = 1;
    public static final int noFINAL = 0;
    public static final int STATIC = 1;
    public static final int noSTATIC = 0;
}
