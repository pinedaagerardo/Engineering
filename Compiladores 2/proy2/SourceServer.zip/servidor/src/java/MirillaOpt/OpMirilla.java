/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package MirillaOpt;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class OpMirilla
{

    String finalDir = "";
    String sourceDir="";
    String in="salida.cpp";
    String fileNoComment="3DirNoComen.cpp";
    String opMirilla="optimiza_mirilla.cpp";
    ArrayList<Nodo2> expre = new ArrayList();

    public OpMirilla(String path,String sourcePath){
         finalDir=path+"\\";
         sourceDir=sourcePath+"\\";
     }

    public void killComment()
    {
        try
        {
             Escritor salida = new Escritor(finalDir+fileNoComment);
             FileReader fr = new FileReader(sourceDir+in);
             BufferedReader  br = new BufferedReader(fr);
             String linea="";

             while((linea=br.readLine())!=null)
            {
                 if(linea.contains("//"))
                 {
                        salida.println(linea.replace(linea.substring(linea.indexOf("/")),""));

                 }
                 else if(linea.contains("/*")&&linea.contains("*/"))
                 {
                       salida.println(linea.replace(linea.substring(linea.indexOf("/"),linea.indexOf("/",linea.indexOf("/"+1))),""));
                 }
                 else
                 {
                        salida.println(linea);
                 }
            }

             salida.close();

         }
              catch(java.io.IOException ioex)
        {
                System.out.println("error: "+ioex.toString());
        }

        readFile();
    }

    public void readFile()
    {

     try
        {
             Escritor salida = new Escritor(finalDir+opMirilla);
             FileReader fr = new FileReader(finalDir+fileNoComment);
             BufferedReader  br = new BufferedReader(fr);
             String linea="";

             while((linea=br.readLine())!=null)
            {

                         if(linea.startsWith("#include") || (linea.startsWith("int")&& linea.contains(";")))
                         {
                             salida.println(linea);
                         }
                         else if((linea.startsWith("int")&&linea.startsWith("void"))&& linea.contains("()"))
                         {
                             salida.println(linea);

                         }
                         else if((linea.startsWith("int")||linea.startsWith("void"))&& linea.contains("()"))
                         {
                             salida.println(linea);

                         }
                         else if(linea.contains("=") && linea.contains("if")==false && linea.contains("int")==false)
                        {
                            String li = linea.trim();
                            String der = li.substring(li.indexOf("=")+1,li.length());
                            String izq= li.substring(0,li.indexOf("="));

                            if(der.contains("+"))
                            {
                                String exp1 = der.substring(der.indexOf("+")+1,der.length());
                                String exp2 = der.substring(0,der.indexOf("+"));
                                expre.add(new Nodo2(izq.trim(),exp2.trim(),"+",exp1.trim().replace(";", ""),7));

                            }
                            else if(der.contains("-"))
                            {
                                String exp1 = der.substring(der.indexOf("-")+1,der.length());
                                String exp2 = der.substring(0,der.indexOf("-"));
                                expre.add(new Nodo2(izq.trim(),exp2.trim(),"-",exp1.trim().replace(";", ""),7));
                            }
                            else if(der.contains("*"))
                            {
                                String exp1 = der.substring(der.indexOf("*")+1,der.length());
                                String exp2 = der.substring(0,der.indexOf("*"));
                                expre.add(new Nodo2(izq.trim(),exp2.trim(),"*",exp1.trim().replace(";", ""),7));
                            }
                            else if(der.contains("/"))
                            {
                                String exp1 = der.substring(der.indexOf("/")+1,der.length());
                                String exp2 = der.substring(0,der.indexOf("/"));
                                expre.add(new Nodo2(izq.trim(),exp2.trim(),"/",exp1.trim().replace(";", ""),7));
                            }
                            else if(der.contains("&&"))
                            {
                                String exp1 = der.substring(der.indexOf("&")+2,der.length());
                                String exp2 = der.substring(0,der.indexOf("&"));
                                expre.add(new Nodo2(izq.trim(),exp2.trim(),"&&",exp1.trim().replace(";", ""),7));
                            }
                             else if(der.contains("||"))
                            {
                                String exp1 = der.substring(der.indexOf("|")+2,der.length());
                                String exp2 = der.substring(0,der.indexOf("|"));
                                expre.add(new Nodo2(izq.trim(),exp2.trim(),"||",exp1.trim().replace(";", ""),7));
                            }
                             else if(der.contains("<="))
                            {
                                String exp1 = der.substring(der.indexOf("<")+2,der.length());
                                String exp2 = der.substring(0,der.indexOf("<"));
                                expre.add(new Nodo2(izq.trim(),exp2.trim(),"<=",exp1.trim().replace(";", ""),7));
                            }
                            else if(der.contains(">="))
                            {
                                String exp1 = der.substring(der.indexOf(">")+2,der.length());
                                String exp2 = der.substring(0,der.indexOf(">"));
                                expre.add(new Nodo2(izq.trim(),exp2.trim(),">=",exp1.trim().replace(";", ""),7));
                            }
                             else if(der.contains(">"))
                            {
                                String exp1 = der.substring(der.indexOf(">")+1,der.length());
                                String exp2 = der.substring(0,der.indexOf(">"));
                                expre.add(new Nodo2(izq.trim(),exp2.trim(),">",exp1.trim().replace(";", ""),7));
                            }
                            else if(der.contains("%"))
                            {
                                String exp1 = der.substring(der.indexOf("%")+1,der.length());
                                String exp2 = der.substring(0,der.indexOf("%"));
                                expre.add(new Nodo2(izq.trim(),exp2.trim(),"%",exp1.trim().replace(";", ""),7));
                            }
                             else if(der.contains("<"))
                            {
                                String exp1 = der.substring(der.indexOf("<")+2,der.length());
                                String exp2 = der.substring(0,der.indexOf("<"));
                                expre.add(new Nodo2(izq.trim(),exp2.trim(),"<",exp1.trim().replace(";", ""),7));
                            }
                            else if(der.contains("=="))
                            {
                                String exp1 = der.substring(der.indexOf("=",6)+2,der.length());
                                String exp2 = der.substring(0,der.indexOf("=",6));
                                expre.add(new Nodo2(izq.trim(),exp2.trim(),"==",exp1.trim().replace(";", ""),7));
                            }
                            else if(der.contains("!="))
                            {
                                String exp1 = der.substring(der.indexOf("!")+2,der.length());
                                String exp2 = der.substring(0,der.indexOf("!"));
                                expre.add(new Nodo2(izq.trim(),exp2.trim(),"!=",exp1.trim().replace(";", ""),7));
                            }
                            else
                            {
                                expre.add(new Nodo2(izq.trim(),der.trim().replace(";", ""),7));
                            }

                        }
                          else if(linea.contains("L")&&linea.contains(":"))
                        {
                              if(linea.contains(";"))
                              {
                                expre.add(new Nodo2(linea.trim().replace(";", ""),";",1));
                              }
                              else
                              {
                                expre.add(new Nodo2(linea.trim(),1));
                              }
                        }
                          else if(linea.contains("if"))
                        {
                                expre.add(new Nodo2(linea.trim().replace(";", ""),2));
                        }
                          else if(linea.contains("goto") && linea.contains("if")==false)
                        {
                                expre.add(new Nodo2(linea.trim().replace(";", ""),3));
                        }
                          else if(linea.contains("()")&&linea.contains(";"))
                        {
                                expre.add(new Nodo2(linea.trim().replace(";", ""),4));
                        }
                          else if(linea.contains("printf"))
                        {
                                expre.add(new Nodo2(linea.trim().replace(";", ""),5));
                        }
                          else if(linea.contains("scanf"))
                        {
                                expre.add(new Nodo2(linea.trim().replace(";", ""),6));
                        }
                          else if(linea.contains("return"))
                        {
                                expre.add(new Nodo2(linea.trim().replace(";", ""),8));
                        }
                          else if (linea.contains("}"))
                          {
                              optim();

                              for(int i = 0;i<expre.size();i++)
                              {
                                           if(expre.get(i).getLSide()!=null && expre.get(i).getType() != 7)
                                            {
                                               if(expre.get(i).getType() == 1)
                                               {
                                                   if(expre.get(i).getexp1()!=null)
                                                   {
                                                        salida.println(expre.get(i).getLSide()+expre.get(i).getexp1());
                                                   }
                                                   else
                                                   {
                                                        salida.println(expre.get(i).getLSide());
                                                   }

                                               }
                                               else
                                               {
                                                salida.println(expre.get(i).getLSide()+";");
                                               }
                                           }
                                            else
                                            {

                                                 if(expre.get(i).sign()!=null&&expre.get(i).getexp2()!=null && expre.get(i).getLSide() !=null)
                                                    {
                                                        salida.println(expre.get(i).getLSide()+ " = "+expre.get(i).getexp1()+
                                                               " "+expre.get(i).sign()+" "+expre.get(i).getexp2()+";");

                                                    }
                                                  if(expre.get(i).sign()==null&&expre.get(i).getexp2()==null && expre.get(i).getLSide() !=null)
                                                    {
                                                       salida.println(expre.get(i).getLSide()+ " = "+expre.get(i).getexp1()+";");
                                                    }
                                            }
                                }

                              expre.clear();
                              salida.println(linea);
                              salida.println("");

                          }
            }

             salida.close();

         }
              catch(java.io.IOException ioex)
        {
                System.out.println("error: "+ioex.toString());
        }
    }

    public void optim()
    {
          for(int i = 0;i<expre.size();i++)
          {
              if(expre.get(i).getType()==7 && expre.get(i).sign()!=null
                      &&expre.get(i).getexp2()!=null )
              {
                  if(expre.get(i).sign().equalsIgnoreCase("+") && expre.get(i).getLSide()!=null
                      && expre.get(i).getexp2().equalsIgnoreCase("0"))
                  {
                         String izq = expre.get(i).getLSide();
                         String exp1 = expre.get(i).getexp1();

                        expre.set(i, new Nodo2(izq,exp1,7));
                  }
                  if(expre.get(i).sign()!=null && expre.get(i).sign().equalsIgnoreCase("*")
                      &&expre.get(i).getexp2().equalsIgnoreCase("1")&& expre.get(i).getLSide()!=null)
                  {
                         String izq = expre.get(i).getLSide();
                         String exp1 = expre.get(i).getexp1();

                         expre.set(i, new Nodo2(izq,exp1,7));
                  }

              }
          }

         optimIf();

    }

    private void optimIf()
    {
        String etiqueta= "";
        String gotos = "";
        String ifs ="";
        String got ="";

        for(int i =0;i<expre.size();i++)
        {
            if(expre.get(i).getType()==2 && expre.get(i).getLSide()!=null)
            {
                etiqueta = expre.get(i).getLSide().substring(expre.get(i).getLSide().indexOf("L")).trim();
                ifs = expre.get(i).getLSide();
            }
            else if(expre.get(i).getType()==3 && expre.get(i).getLSide()!=null)
            {
                gotos = expre.get(i).getLSide().replace("goto", "").trim();
                got = expre.get(i).getLSide();
            }
            else if(expre.get(i).getType()==1 && etiqueta.equalsIgnoreCase("")==false && gotos.equalsIgnoreCase("")==false
                    && expre.get(i).getLSide()!=null)
            {
                if(expre.get(i).getLSide().replace(":", "").equalsIgnoreCase(etiqueta))
                {

                    if(ifs.contains(">="))
                    {
                            expre.get(i-2).setL(ifs.replace(etiqueta, gotos).replace(">=", "<"));
                            expre.get(i-1).setL(got.replace(gotos, etiqueta));
                    }
                    else if(ifs.contains("<="))
                    {
                            expre.get(i-2).setL(ifs.replace(etiqueta, gotos).replace("<=", ">"));
                            expre.get(i-1).setL(got.replace(gotos, etiqueta));
                    }
                    else if(ifs.contains("!="))
                    {
                            expre.get(i-2).setL(ifs.replace(etiqueta, gotos).replace("!=", "=="));
                            expre.get(i-1).setL(got.replace(gotos, etiqueta));
                    }
                    else if(ifs.contains("=="))
                    {
                            expre.get(i-2).setL(ifs.replace(etiqueta, gotos).replace("==", "!="));
                            expre.get(i-1).setL(got.replace(gotos, etiqueta));
                    }
                    else if(ifs.contains(">"))
                    {
                            expre.get(i-2).setL(ifs.replace(etiqueta, gotos).replace(">", "<="));
                            expre.get(i-1).setL(got.replace(gotos, etiqueta));
                    }
                    else if(ifs.contains("<"))
                    {
                            expre.get(i-2).setL(ifs.replace(etiqueta, gotos).replace("<", ">="));
                            expre.get(i-1).setL(got.replace(gotos, etiqueta));
                    }
                    else if(ifs.contains("||") || ifs.contains("&&"))
                    {

                    }



                    etiqueta = "";
                }
                else
                {
                    etiqueta = "";
                }
            }
            else
            {
                etiqueta ="";
            }

        }
        optimGoto();
    }

        public void optimGoto()
    {
        String etiqueta= "";

        for(int i =0;i<expre.size();i++)
        {
            if(expre.get(i).getType()==3 && expre.get(i).getLSide()!=null)
            {
                etiqueta = expre.get(i).getLSide().replace("goto", "").trim();
            }
            else if(expre.get(i).getType()==1 && etiqueta.equalsIgnoreCase("")==false && expre.get(i).getLSide()!=null)
            {
                if(expre.get(i).getLSide().replace(":", "").equalsIgnoreCase(etiqueta)
                        && cCalls(cGoto(),etiqueta)<2)
                {
                      expre.get(i-1).setL(null);
                      expre.get(i).setL(null);
                    etiqueta = "";
                }
                else  if(expre.get(i).getLSide()!=null && expre.get(i).getLSide().replace(":", "").equalsIgnoreCase(etiqueta)
                        && cCalls(cGoto(),etiqueta)>=2)
                {
                    expre.get(i-1).setL(null);
                    etiqueta = "";
                }
                else
                {
                    etiqueta = "";
                }
            }
            else
            {
                etiqueta ="";
            }

        }

           killRed();
    }

        public ArrayList<String> cGoto()
        {
            ArrayList<String> llamadas = new ArrayList();
            String eti = "";

            for(int i =0;i<expre.size();i++)
            {
                if(expre.get(i).getType()==3 && expre.get(i).getLSide() != null)
                {
                    eti = expre.get(i).getLSide().replace("goto", "").trim();
                    llamadas.add(eti);

                }
                if(expre.get(i).getType()==2&& expre.get(i).getLSide() != null)
                {
                     eti = expre.get(i).getLSide().substring(expre.get(i).getLSide().indexOf("L")).trim();
                     llamadas.add(eti);
                }

            }
            return llamadas;
        }

    public int cCalls(ArrayList<String> lista, String etiqueta)
    {
        int j = 0;
        for(int i =0;i<lista.size();i++)
        {
            if(lista.get(i).equalsIgnoreCase(etiqueta))
            {
               j = j+1;
            }
        }
        return j;
    }

    public void killRed()
    {
       String temporal = "";
       String exp1 = "";

       for(int i = 0;i<expre.size();i++)
       {
           for(int j =i+1;j<expre.size();j++)
           {
               if(expre.get(i).getType() == 7 && expre.get(j).getType()==7 && i!=j)
               {
                       if(expre.get(i).sign()==null && expre.get(j).sign()==null &&
                               expre.get(i).getexp2()==null && expre.get(j).getexp2()==null)
                       {
                           if(expre.get(i).getLSide()!= null && temporal.equalsIgnoreCase("") ==true
                                   && expre.get(i).getLSide().contains("[")==false && expre.get(i).getexp1().contains("[") ==false)
                           {
                                temporal = expre.get(i).getLSide();
                                exp1 = expre.get(i).getexp1();

                                if(expre.get(j).getexp1().contains("[")){
                                 String bloq = expre.get(j).getexp1();
                                String [] lineas = bloq.split("[\\[]");

                                String ex1 = lineas[1].replace("]", "");

                                   if(ex1.equalsIgnoreCase(temporal))
                                   {
                                       expre.set(j, new Nodo2(expre.get(j).getLSide(),expre.get(j).getexp1().replace(temporal, exp1),7 ));
                                       expre.get(i).setL(null);

                                   }

                                temporal = "";
                                exp1 = "";
                             }
                           }

                       }

               }

           }

       }

     killLabels();
    }

    public void killLabels()
    {
        for(int i = 0; i<expre.size();i++)
        {
            if(expre.get(i).getLSide()!=null && expre.get(i).getType()==1 &&
                    cCalls(cGoto(),expre.get(i).getLSide().replace(":", ""))==0)
                {
                        if(expre.get(i).getexp1()!=null)
                         {
                            if(i>0 && expre.get(i-1).getType()==1){
                            String exp = expre.get(i-1).getLSide();
                            expre.get(i-1).setL(exp+";");
                            }
                            expre.get(i).setL(null);
                         }
                         else
                         {
                            expre.get(i).setL(null);
                         }

                }
        }

        killLabelsRed();
    }


public void killLabelsRed()
{
    String etiqueta1 = "";
    String etiqueta2 = "";
    int m =0;

    for(int i = 0; i<expre.size();i++)
    {
        if(expre.get(i).getLSide()!=null && expre.get(i).getLSide().equalsIgnoreCase("") ==false)
        {

               if(expre.get(i).getType()==1 &&etiqueta1.equalsIgnoreCase("") && expre.get(i).getexp1()==null )
                {
                    etiqueta1 = expre.get(i).getLSide().replace(":", "");
                    m = i;

                }
                else if(expre.get(i).getType()==1 && etiqueta1.equalsIgnoreCase("") == false)
                {
                     etiqueta2 = expre.get(i).getLSide().replace(":", "");
                     expre.get(m).setL(null);


                    for(int j = 0;j<expre.size();j++)
                    {
                        String eti1 = "";

                        if(expre.get(j).getType()==3 && expre.get(j).getLSide() != null)
                        {
                            eti1 = expre.get(j).getLSide().replace("goto", "").trim();

                            if(eti1.equalsIgnoreCase(etiqueta1))
                            {

                                  expre.get(j).setL( expre.get(j).getLSide().replace(eti1, etiqueta2));
                            }

                        }
                        else if(expre.get(j).getType()==2&& expre.get(j).getLSide() != null)
                        {
                             eti1 = expre.get(j).getLSide().substring(expre.get(j).getLSide().indexOf("L")).trim();
                             if(eti1.equalsIgnoreCase(etiqueta1))
                            {
                                expre.get(j).setL( expre.get(j).getLSide().replace(eti1, etiqueta2));

                            }

                        }

                    }

                 etiqueta1 = expre.get(i).getLSide().replace(":", "");
                 m= i;
        }
        else
        {
            etiqueta1 = "";
            etiqueta2 = "";
        }

    }
    }

}
}
