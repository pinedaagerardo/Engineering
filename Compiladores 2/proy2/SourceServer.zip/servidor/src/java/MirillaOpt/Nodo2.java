/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package MirillaOpt;


public class Nodo2
{
    int type =0;
    String left;
    String sign;
    String exp1;
    String exp2;


    
    public Nodo2(String left, String exp1, String sign, String exp2, int type)
    {
        this.left = left;
        this.exp1 = exp1;
        this.exp2 = exp2;
        this.sign = sign;
        this.type = type;


    }

    public Nodo2(String left, String exp1, int type)
    {
        this.left = left;
        this.exp1 = exp1;
        this.type = type;

    }

     public Nodo2(String l, int t)
    {
        this.left = l;
        this.type = t;

    }


        public String getexp1()
     {
        return this.exp1;
     }

     public void setexp1(String exp1)
     {
         this.exp1 = exp1;

     }

     public void setL(String l)
     {
         this.left = l;

     }

     public void setType(int type)
     {
         this.type = type;

     }

        public String getexp2()
     {
        return this.exp2;
     }

        public String sign()
     {
        return this.sign;
     }

     public String getLSide ()
     {
        return this.left;
     }

      public int getType ()
     {
        return this.type;
     }

}
