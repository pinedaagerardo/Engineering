/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package MirillaOpt;



import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;

public class Escritor {

    FileWriter fw;
    BufferedWriter bw;
    PrintWriter exit;

    public Escritor(String name)
    {
         try
        {
            fw = new FileWriter(name);
            exit = new PrintWriter(fw);
         
        }

        catch(java.io.IOException ioex)
        {
            System.out.println("error: "+ioex.toString());
        }

    }


    public void println(String txt)
    {
        exit.println(txt);
    }

    public void close()
    {
       exit.close();
    }

    public void erase()
    {
        exit.write("");
    }

}
