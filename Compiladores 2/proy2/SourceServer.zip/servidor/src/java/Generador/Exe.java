/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Generador;

import Nodo.MiNodo;
import SymConst.SConstantes;
import SymConst.Papel;
import SymT.Manejador;
import SymT.Nodo_Clase;
import SymT.Nodo_Metodo_Variable;
import SymT.Nodo_Tipo;
import java.util.ArrayList;

public class Exe {

    public Exe() {
    }

public void error(String mensaje, int linea){

}
/**
 *
 * @param nom
 * @param args
 * @param Clase
 * @param Metodo
 * @param AmbitoActual
 * @return
 */
public MiNodo Creacion_Instancia_con_Arg(MiNodo nom, MiNodo args, String Clase,Nodo_Metodo_Variable Metodo, String AmbitoActual){

                MiNodo RESULT=new MiNodo();
                ArrayList<MiNodo> ltemp=(ArrayList<MiNodo>)args.getDato();
                String listaparam="";

                for(int i=0;i<ltemp.size();i++){
                    if(ltemp.get(i).isExplicita()){
                    if(i==0){
                        listaparam=ltemp.get(i).getTipo().getNombre();
                    }else{
                        listaparam=listaparam+"&"+ltemp.get(i).getTipo().getNombre();
                    }
                    }else{
                     Nodo_Metodo_Variable Aux =(Nodo_Metodo_Variable)Manejador.Tabla.ExisteVariableEnClase(Clase,(String)ltemp.get(i).getCadena(),AmbitoActual);
                     if(i==0){
                        listaparam=Aux.getTipo().getNombre();
                    }else{
                        listaparam=listaparam+"&"+Aux.getTipo().getNombre();
                    }
                    }

                }
                    listaparam=listaparam.replace("&","_");

                    Nodo_Clase Aux=Manejador.Tabla.getClase((String)nom.getDato());
                    if(!Aux.getNombre().equals("")){
                    String temp=Manejador.gen.generarTemporalInt();
                    int posicion=0;
                    if(AmbitoActual.equals("")){
                     Manejador.gen.constructordefault.append(temp+" = PTR_HEAP;\n");
                     Metodo=(Nodo_Metodo_Variable)Manejador.Tabla.getMetodo(Clase, "$"+Clase+"$", Papel.CONSTRUCTOR, "void");
                     posicion=Metodo.getTamañoPila();
                     Metodo.setTamañoPila(posicion+1);
                     Manejador.Tabla.AddVariableLocal(Aux.getNombre(), temp, Papel.VARLOCAL, Metodo.getAmbito(), posicion,(String)nom.getDato());

                    String temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp2+" = PTR_PILA + "+posicion+";\n");
                    Manejador.gen.constructordefault.append("PILA ["+temp2+"] = "+temp+";\n");

                    Manejador.gen.constructordefault.append("PTR_HEAP = PTR_HEAP + "+Aux.getTamañoHeap()+";\n");

                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp2+" = PTR_PILA + "+posicion+";\n");
                    String temp3=Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp3+" = PILA ["+temp2+"];\n");

                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp2+" = PTR_PILA + "+Metodo.getTamañoPila()+";\n");
                    String temp4=Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp4+" = "+temp2+" + 0;\n");
                    Manejador.gen.constructordefault.append("PILA ["+temp4+"] = "+temp3+";\n");

                    Manejador.gen.constructordefault.append("PTR_PILA = PTR_PILA + "+Metodo.getTamañoPila()+";\n");
                    Manejador.gen.constructordefault.append("$"+nom.getDato()+"$();\n");
                    Manejador.gen.constructordefault.append("PTR_PILA = PTR_PILA - "+Metodo.getTamañoPila()+";\n");

                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp2+" = PTR_PILA + "+posicion+";\n");
                    temp3=Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp3+" = PILA ["+temp2+"];\n");

                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp2+" = PTR_PILA + "+Metodo.getTamañoPila()+";\n");
                    temp4=Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp4+" = "+temp2+" + 0;\n");
                    Manejador.gen.constructordefault.append("PILA ["+temp4+"] = "+temp3+";\n");

                    }else{
                     Manejador.gen.implementaciones.append(temp+" = PTR_HEAP;\n");
                     posicion=Metodo.getTamañoPila();
                     Metodo.setTamañoPila(posicion+1);
                     Manejador.Tabla.AddVariableLocal(Clase, temp, Papel.VARLOCAL, AmbitoActual, posicion, (String)nom.getDato());

                    String temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp2+" = PTR_PILA + "+posicion+";\n");
                    Manejador.gen.implementaciones.append("PILA ["+temp2+"] = "+temp+";\n");

                    Manejador.gen.implementaciones.append("PTR_HEAP = PTR_HEAP + "+Aux.getTamañoHeap()+";\n");

                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp2+" = PTR_PILA + "+posicion+";\n");
                    String temp3=Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp3+" = PILA ["+temp2+"];\n");

                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp2+" = PTR_PILA + "+Metodo.getTamañoPila()+";\n");
                    String temp4=Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp4+" = "+temp2+" + 0;\n");
                    Manejador.gen.implementaciones.append("PILA ["+temp4+"] = "+temp3+";\n");

                    Manejador.gen.implementaciones.append("PTR_PILA = PTR_PILA + "+Metodo.getTamañoPila()+";\n");
                    Manejador.gen.implementaciones.append("$"+nom.getDato()+"$();\n");
                    Manejador.gen.implementaciones.append("PTR_PILA = PTR_PILA - "+Metodo.getTamañoPila()+";\n");

                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp2+" = PTR_PILA + "+posicion+";\n");
                    temp3=Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp3+" = PILA ["+temp2+"];\n");

                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp2+" = PTR_PILA + "+Metodo.getTamañoPila()+";\n");
                    temp4=Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp4+" = "+temp2+" + 0;\n");
                    Manejador.gen.implementaciones.append("PILA ["+temp4+"] = "+temp3+";\n");

                    }

                    String resultado="";
                    for(int j = 0; j<ltemp.size(); j++){
                        MiNodo der=ltemp.get(j);
                        String[] id = ((String)der.getCadena()).split("[.]");
                        String tmp = "";
                        String Ambito = AmbitoActual;
                        String NombreClase = Clase;

                        if(!der.isExplicita()){
                            if(!AmbitoActual.equals("")){
                                if(!id[0].equals("$a")){
                                    Nodo_Metodo_Variable Var=Manejador.Tabla.ExisteVariableEnClase(NombreClase, id[0], Ambito);
                                    if(Var.getAmbito().equals("")){
                                        if(!der.getCadena().toString().startsWith("$t")){
                                        der.setCadena("$a."+der.getCadena());
                                        }
                                    }
                                }
                            }else{
                                if(!id[0].equals("$a")){
                                    if(!der.getCadena().toString().startsWith("$t")){
                                        der.setCadena("$a."+der.getCadena());
                                    }
                                }
                            }
                        }
                        id = ((String)der.getCadena()).split("[.]");
                        for(int i = 0; i < id.length; i++){
                            if(!der.isExplicita()){
                                Nodo_Metodo_Variable actual;
                                if(!id[i].equals("$a")){
                                     if((!id[i].startsWith("$t"))){
                                        actual = Manejador.Tabla.ExisteVariableEnClase(NombreClase, id[i], Ambito);
                                     }else{
                                         if(!Ambito.equals("")){
                                         actual = Manejador.Tabla.ExisteVariableEnClase(NombreClase, id[i], Ambito);
                                         }else{
                                         actual = Manejador.Tabla.ExisteVariableEnClase(NombreClase, id[i], 1+"$"+NombreClase+"$");
                                         }
                                     }
                                    NombreClase= actual.getTipo().getNombre();
                                }else{
                                    actual = Manejador.Tabla.getVariable(NombreClase, id[i], "$"+NombreClase+"$");
                                }
                                Ambito = "";
                                if(actual.getAmbito().equals("")){
                                    if(AmbitoActual.equals("")){
                                         String temp1=Manejador.gen.generarTemporalInt();
                                         Manejador.gen.constructordefault.append(temp1+" = "+tmp+" + "+actual.getPosicion()+";\n");
                                         String temp2=Manejador.gen.generarTemporalInt();
                                         Manejador.gen.constructordefault.append(temp2+" = HEAP ["+temp1+"];\n");
                                         /*
                                          * INICIA VALIDACION PARA ARRAYS
                                          * */
                                         if(actual.getTipo().getDimensiones().size()!=0 && !der.getDesplazamiento().equals("") ){
                                            Nodo_Metodo_Variable dezTemp = null;
                                            if(AmbitoActual.equals("")){
                                                 dezTemp = Manejador.Tabla.getVariable(NombreClase, der.getDesplazamiento(), "$"+NombreClase+"$");
                                            }
                                            else{
                                                dezTemp = Manejador.Tabla.getVariable(NombreClase, der.getDesplazamiento(), AmbitoActual);
                                            }
                                            String dezTempPos = Manejador.gen.generarTemporalInt();
                                            Manejador.gen.constructordefault.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                                            String dezTempVal = Manejador.gen.generarTemporalInt();
                                            Manejador.gen.constructordefault.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                                            temp1 = Manejador.gen.generarTemporalInt();
                                            Manejador.gen.constructordefault.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                                            temp2=Manejador.gen.generarTemporalInt();
                                            Manejador.gen.constructordefault.append(temp2+" = HEAP ["+temp1+"];\n");
                                         }
                                         /*
                                          * TERMINA VALIDACION PARA ARRAYS
                                          * */
                                         if(i != (id.length - 1)){
                                         tmp=temp2;
                                         }else{
                                         resultado=temp2;
                                         }
                                    }else{
                                         String temp1=Manejador.gen.generarTemporalInt();
                                         Manejador.gen.implementaciones.append(temp1+" = "+tmp+" + "+actual.getPosicion()+";\n");
                                         String temp2=Manejador.gen.generarTemporalInt();
                                         Manejador.gen.implementaciones.append(temp2+" = HEAP ["+temp1+"];\n");
                                         /*
                                          * INICIA VALIDACION PARA ARRAYS
                                          * */
                                         if(actual.getTipo().getDimensiones().size()!=0 && !der.getDesplazamiento().equals("") ){
                                            Nodo_Metodo_Variable dezTemp = null;
                                            if(AmbitoActual.equals("")){
                                                 dezTemp = Manejador.Tabla.getVariable(NombreClase, der.getDesplazamiento(), "$"+NombreClase+"$");
                                            }
                                            else{
                                                dezTemp = Manejador.Tabla.getVariable(NombreClase, der.getDesplazamiento(), AmbitoActual);
                                            }
                                            String dezTempPos = Manejador.gen.generarTemporalInt();
                                            Manejador.gen.implementaciones.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                                            String dezTempVal = Manejador.gen.generarTemporalInt();
                                            Manejador.gen.implementaciones.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                                            temp1 = Manejador.gen.generarTemporalInt();
                                            Manejador.gen.implementaciones.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                                            temp2=Manejador.gen.generarTemporalInt();
                                            Manejador.gen.implementaciones.append(temp2+" = HEAP ["+temp1+"];\n");
                                         }
                                         /*
                                          * TERMINA VALIDACION PARA ARRAYS
                                          * */
                                         if(i != (id.length - 1)){
                                            tmp=temp2;
                                         }else{
                                            resultado=temp2;
                                         }
                                    }
                                }
                                else{
                                    if(AmbitoActual.equals("")){
                                         String temp1=Manejador.gen.generarTemporalInt();
                                         Manejador.gen.constructordefault.append(temp1+" = PTR_PILA + "+actual.getPosicion()+";\n");
                                         String temp2=Manejador.gen.generarTemporalInt();
                                         Manejador.gen.constructordefault.append(temp2+" = PILA ["+temp1+"];\n");
                                         /*
                                          * INICIA VALIDACION PARA ARRAYS
                                          * */
                                         if(actual.getTipo().getDimensiones().size()!=0 && !der.getDesplazamiento().equals("") ){
                                            Nodo_Metodo_Variable dezTemp = null;
                                            if(AmbitoActual.equals("")){
                                                 dezTemp = Manejador.Tabla.getVariable(NombreClase, der.getDesplazamiento(), "$"+NombreClase+"$");
                                            }
                                            else{
                                                dezTemp = Manejador.Tabla.getVariable(NombreClase, der.getDesplazamiento(), AmbitoActual);
                                            }
                                            String dezTempPos = Manejador.gen.generarTemporalInt();
                                            Manejador.gen.constructordefault.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                                            String dezTempVal = Manejador.gen.generarTemporalInt();
                                            Manejador.gen.constructordefault.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                                            temp1 = Manejador.gen.generarTemporalInt();
                                            Manejador.gen.constructordefault.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                                            temp2=Manejador.gen.generarTemporalInt();
                                            Manejador.gen.constructordefault.append(temp2+" = HEAP ["+temp1+"];\n");
                                         }
                                         /*
                                          * TERMINA VALIDACION PARA ARRAYS
                                          * */
                                         if(i != (id.length - 1)){
                                         tmp=temp2;
                                         }else{
                                         resultado=temp2;
                                         }
                                    }else{
                                         String temp1=Manejador.gen.generarTemporalInt();
                                         Manejador.gen.implementaciones.append(temp1+" = PTR_PILA + "+actual.getPosicion()+";\n");
                                         String temp2=Manejador.gen.generarTemporalInt();
                                         Manejador.gen.implementaciones.append(temp2+" = PILA ["+temp1+"];\n");
                                         /*
                                          * INICIA VALIDACION PARA ARRAYS
                                          * */
                                         if(actual.getTipo().getDimensiones().size()!=0 && !der.getDesplazamiento().equals("") ){
                                            Nodo_Metodo_Variable dezTemp = null;
                                            if(AmbitoActual.equals("")){
                                                 dezTemp = Manejador.Tabla.getVariable(NombreClase, der.getDesplazamiento(), "$"+NombreClase+"$");
                                            }
                                            else{
                                                dezTemp = Manejador.Tabla.getVariable(NombreClase, der.getDesplazamiento(), AmbitoActual);
                                            }
                                            String dezTempPos = Manejador.gen.generarTemporalInt();
                                            Manejador.gen.implementaciones.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                                            String dezTempVal = Manejador.gen.generarTemporalInt();
                                            Manejador.gen.implementaciones.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                                            temp1 = Manejador.gen.generarTemporalInt();
                                            Manejador.gen.implementaciones.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                                            temp2=Manejador.gen.generarTemporalInt();
                                            Manejador.gen.implementaciones.append(temp2+" = HEAP ["+temp1+"];\n");
                                         }
                                         /*
                                          * TERMINA VALIDACION PARA ARRAYS
                                          * */
                                         if(i != (id.length - 1)){
                                         tmp=temp2;
                                         }else{
                                         resultado=temp2;
                                         }
                                    }
                                }
                            }else{
                                    resultado = id[0];
                            }
                        }
                          if(AmbitoActual.equals("")){
                             Metodo = (Nodo_Metodo_Variable)Manejador.Tabla.getMetodo(NombreClase, "$"+NombreClase+"$", Papel.CONSTRUCTOR, "void");
                             String temp3=Manejador.gen.generarTemporalInt();
                             Manejador.gen.constructordefault.append(temp3+" = PTR_PILA + "+Metodo.getTamañoPila()+";\n");
                             String temp2=Manejador.gen.generarTemporalInt();
                             Manejador.gen.constructordefault.append(temp2+" = "+temp3+" + "+(j+1)+";\n");
                             Manejador.gen.constructordefault.append("PILA ["+temp2+"] = "+resultado+";\n");

                        }else{
                             String temp3=Manejador.gen.generarTemporalInt();
                             Manejador.gen.implementaciones.append(temp3+" = PTR_PILA + "+Metodo.getTamañoPila()+";\n");
                             String temp2=Manejador.gen.generarTemporalInt();
                             Manejador.gen.implementaciones.append(temp2+" = "+temp3+" + "+(j+1)+";\n");
                             Manejador.gen.implementaciones.append("PILA ["+temp2+"] = "+resultado+";\n");

                        }
                    }
                    if(AmbitoActual.equals("")){
                        Manejador.gen.constructordefault.append("PTR_PILA = PTR_PILA + "+Metodo.getTamañoPila()+";\n");
                        Manejador.gen.constructordefault.append(nom.getDato()+"();\n");
                        Manejador.gen.constructordefault.append("PTR_PILA = PTR_PILA - "+Metodo.getTamañoPila()+";\n\n");
                    }
                    else{
                        Manejador.gen.implementaciones.append("PTR_PILA = PTR_PILA + "+Metodo.getTamañoPila()+";\n");
                        Manejador.gen.implementaciones.append(nom.getDato()+"$"+listaparam+"();\n");
                        Manejador.gen.implementaciones.append("PTR_PILA = PTR_PILA - "+Metodo.getTamañoPila()+";\n\n");
                    }

                    RESULT=new MiNodo(temp, SConstantes.IMPLICITA, SConstantes.LOCAL, new Nodo_Tipo((String)nom.getDato()));

                    }else{
                        error("Error Semantico: Clase "+nom.getDato()+" No Definida",nom.getLinea());
                    }
                    return RESULT;
}

/**
 *
 * @param id
 * @param NombreClase
 * @param Metodo
 * @param AmbitoActual
 * @return
 */
public MiNodo Creacion_Instancia_sin_Arg(MiNodo id, String NombreClase,Nodo_Metodo_Variable Metodo, String AmbitoActual){

                    MiNodo RESULT=new MiNodo();
                    Nodo_Clase Aux=Manejador.Tabla.getClase((String)id.getDato());
                    if(!Aux.getNombre().equals("")){
                    String temp=Manejador.gen.generarTemporalInt();

                    int posicion=0;
                    if(AmbitoActual.equals("")){
                     Manejador.gen.constructordefault.append(temp+" = PTR_HEAP;\n");

                     Metodo=(Nodo_Metodo_Variable)Manejador.Tabla.getMetodo(NombreClase, "$"+NombreClase+"$", Papel.CONSTRUCTOR, "void");
                     posicion=Metodo.getTamañoPila();
                     Metodo.setTamañoPila(posicion+1);
                     Manejador.Tabla.AddVariableLocal(NombreClase, temp, Papel.VARLOCAL, "$"+NombreClase+"$", posicion,(String)id.getDato());

                    String temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp2+" = PTR_PILA + "+posicion+";\n");
                    Manejador.gen.constructordefault.append("PILA ["+temp2+"] = "+temp+";\n");

                    Manejador.gen.constructordefault.append("PTR_HEAP = PTR_HEAP + "+Aux.getTamañoHeap()+";\n");

                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp2+" = PTR_PILA + "+posicion+";\n");
                    String temp3=Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp3+" = PILA ["+temp2+"];\n");

                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp2+" = PTR_PILA + "+Metodo.getTamañoPila()+";\n");
                    String temp4=Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp4+" = "+temp2+" + 0;\n");
                    Manejador.gen.constructordefault.append("PILA ["+temp4+"] = "+temp3+";\n");

                    Manejador.gen.constructordefault.append("PTR_PILA = PTR_PILA + "+Metodo.getTamañoPila()+";\n");
                    Manejador.gen.constructordefault.append("$"+id.getDato()+"$();\n");
                    Manejador.gen.constructordefault.append("PTR_PILA = PTR_PILA - "+Metodo.getTamañoPila()+";\n");

                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp2+" = PTR_PILA + "+posicion+";\n");
                    temp3=Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp3+" = PILA ["+temp2+"];\n");

                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp2+" = PTR_PILA + "+Metodo.getTamañoPila()+";\n");
                    temp4=Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp4+" = "+temp2+" + 0;\n");
                    Manejador.gen.constructordefault.append("PILA ["+temp4+"] = "+temp3+";\n");

                    Manejador.gen.constructordefault.append("PTR_PILA = PTR_PILA + "+Metodo.getTamañoPila()+";\n");
                    Manejador.gen.constructordefault.append(id.getDato()+"$void();\n");
                    Manejador.gen.constructordefault.append("PTR_PILA = PTR_PILA - "+Metodo.getTamañoPila()+";\n");

                    }else{
                     Manejador.gen.implementaciones.append(temp+" = PTR_HEAP;\n");
                     posicion=Metodo.getTamañoPila();
                     Metodo.setTamañoPila(posicion+1);
                     Manejador.Tabla.AddVariableLocal(NombreClase, temp, Papel.VARLOCAL, AmbitoActual, posicion, (String)id.getDato());

                    String temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp2+" = PTR_PILA + "+posicion+";\n");
                    Manejador.gen.implementaciones.append("PILA ["+temp2+"] = "+temp+";\n");

                    Manejador.gen.implementaciones.append("PTR_HEAP = PTR_HEAP + "+Aux.getTamañoHeap()+";\n");

                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp2+" = PTR_PILA + "+posicion+";\n");
                    String temp3=Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp3+" = PILA ["+temp2+"];\n");

                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp2+" = PTR_PILA + "+Metodo.getTamañoPila()+";\n");
                    String temp4=Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp4+" = "+temp2+" + 0;\n");
                    Manejador.gen.implementaciones.append("PILA ["+temp4+"] = "+temp3+";\n");

                    Manejador.gen.implementaciones.append("PTR_PILA = PTR_PILA + "+Metodo.getTamañoPila()+";\n");
                    Manejador.gen.implementaciones.append("$"+id.getDato()+"$();\n");
                    Manejador.gen.implementaciones.append("PTR_PILA = PTR_PILA - "+Metodo.getTamañoPila()+";\n");

                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp2+" = PTR_PILA + "+posicion+";\n");
                    temp3=Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp3+" = PILA ["+temp2+"];\n");

                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp2+" = PTR_PILA + "+Metodo.getTamañoPila()+";\n");
                    temp4=Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp4+" = "+temp2+" + 0;\n");
                    Manejador.gen.implementaciones.append("PILA ["+temp4+"] = "+temp3+";\n");

                    Manejador.gen.implementaciones.append("PTR_PILA = PTR_PILA + "+Metodo.getTamañoPila()+";\n");
                    Manejador.gen.implementaciones.append(id.getDato()+"$void();\n");
                    Manejador.gen.implementaciones.append("PTR_PILA = PTR_PILA - "+Metodo.getTamañoPila()+";\n");
                    }

                   RESULT=new MiNodo(temp, SConstantes.IMPLICITA, SConstantes.LOCAL, new Nodo_Tipo((String)id.getDato()));
                    }else{
                        error("Error Semantico: Clase "+id.getDato()+" No Definida",id.getLinea());
                    }

                   return RESULT;
}

public void Asignacion(MiNodo der, MiNodo izq, String Clase, String AmbitoActual){
    Nodo_Metodo_Variable derVar = null;
    Nodo_Metodo_Variable izqVar = null;
String id[]= ((String)der.getCadena()).split("[.]");
String tmp="", resultado="", Ambito=AmbitoActual, NombreClase=Clase;
if(!der.isExplicita()){
if(!AmbitoActual.equals("")){
if(!id[0].equals("$a")){

    Nodo_Metodo_Variable Var=Manejador.Tabla.ExisteVariableEnClase(NombreClase, id[0], Ambito);
    if(Var.getAmbito().equals("")){
        if(!der.getCadena().toString().startsWith("$t")){
        der.setCadena("$a."+der.getCadena());
        }
    }
}
}else{
    if(!id[0].equals("$a")){
        if(!der.getCadena().toString().startsWith("$t")){
            der.setCadena("$a."+der.getCadena());
        }
    }
}
}
id= ((String)der.getCadena()).split("[.]");
for(int i = 0; i < id.length; i++){
    if(!der.isExplicita()){
        Nodo_Metodo_Variable actual;
        if(!id[i].equals("$a")){
         if((!id[i].startsWith("$t"))){
            actual = Manejador.Tabla.ExisteVariableEnClase(NombreClase, id[i], Ambito);
         }else{
             if(!Ambito.equals("")){
             actual = Manejador.Tabla.ExisteVariableEnClase(NombreClase, id[i], Ambito);
             }else{
             actual = Manejador.Tabla.ExisteVariableEnClase(Clase, id[i], "$"+Clase+"$");
             }
         }
        NombreClase= actual.getTipo().getNombre();
        }else{
        actual = Manejador.Tabla.getVariable(NombreClase, id[i], "$"+NombreClase+"$");
        }
        Ambito = "";
        if(actual.getAmbito().equals("")){
            if(AmbitoActual.equals("")){
                 String temp1=Manejador.gen.generarTemporalInt();
                 Manejador.gen.constructordefault.append(temp1+" = "+tmp+" + "+actual.getPosicion()+";\n");
                 String temp2=Manejador.gen.generarTemporalInt();
                 Manejador.gen.constructordefault.append(temp2+" = HEAP ["+temp1+"];\n");
                 /*
                  * INICIA VALIDACION PARA ARRAYS
                  * */
                 if(actual.getTipo().getDimensiones().size()!=0 && !der.getDesplazamiento().equals("") ){
                    Nodo_Metodo_Variable dezTemp = null;
                    if(AmbitoActual.equals("")){
                         dezTemp = Manejador.Tabla.getVariable(Clase, der.getDesplazamiento(), "$"+Clase+"$");
                    }
                    else{
                        dezTemp = Manejador.Tabla.getVariable(Clase, der.getDesplazamiento(), AmbitoActual);
                    }
                    String dezTempPos = Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                    String dezTempVal = Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                    temp1 = Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp2+" = HEAP ["+temp1+"];\n");
                 }
                 /*
                  * TERMINA VALIDACION PARA ARRAYS
                  * */
                 if(i != (id.length - 1)){
                 tmp=temp2;
                 }else{
                 resultado=temp2;
                 }
            }else{
                 String temp1=Manejador.gen.generarTemporalInt();
                 Manejador.gen.implementaciones.append(temp1+" = "+tmp+" + "+actual.getPosicion()+";\n");
                 String temp2=Manejador.gen.generarTemporalInt();
                 Manejador.gen.implementaciones.append(temp2+" = HEAP ["+temp1+"];\n");
                 /*
                  * INICIA VALIDACION PARA ARRAYS
                  * */
                 if(actual.getTipo().getDimensiones().size()!=0 && !der.getDesplazamiento().equals("") ){
                    Nodo_Metodo_Variable dezTemp = null;
                    if(AmbitoActual.equals("")){
                         dezTemp = Manejador.Tabla.getVariable(Clase, der.getDesplazamiento(), "$"+Clase+"$");
                    }
                    else{
                        dezTemp = Manejador.Tabla.getVariable(Clase, der.getDesplazamiento(), AmbitoActual);
                    }
                    String dezTempPos = Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                    String dezTempVal = Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                    temp1 = Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp2+" = HEAP ["+temp1+"];\n");
                 }
                 /*
                  * TERMINA VALIDACION PARA ARRAYS
                  * */
                 if(i != (id.length - 1)){
                    tmp=temp2;
                 }else{
                    resultado=temp2;
                 }
            }
        }
        else{
            if(AmbitoActual.equals("")){
                 String temp1=Manejador.gen.generarTemporalInt();
                 Manejador.gen.constructordefault.append(temp1+" = PTR_PILA + "+actual.getPosicion()+";\n");
                 String temp2=Manejador.gen.generarTemporalInt();
                 Manejador.gen.constructordefault.append(temp2+" = PILA ["+temp1+"];\n");
                 /*
                  * INICIA VALIDACION PARA ARRAYS
                  * */
                 if(actual.getTipo().getDimensiones().size()!=0 && !der.getDesplazamiento().equals("") ){
                    Nodo_Metodo_Variable dezTemp = null;
                    if(AmbitoActual.equals("")){
                         dezTemp = Manejador.Tabla.getVariable(Clase, der.getDesplazamiento(), "$"+Clase+"$");
                    }
                    else{
                        dezTemp = Manejador.Tabla.getVariable(Clase, der.getDesplazamiento(), AmbitoActual);
                    }
                    String dezTempPos = Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                    String dezTempVal = Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                    temp1 = Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp2+" = HEAP ["+temp1+"];\n");
                 }
                 /*
                  * TERMINA VALIDACION PARA ARRAYS
                  * */
                 if(i != (id.length - 1)){
                 tmp=temp2;
                 }else{
                 resultado=temp2;
                 }
            }else{
                 String temp1=Manejador.gen.generarTemporalInt();
                 Manejador.gen.implementaciones.append(temp1+" = PTR_PILA + "+actual.getPosicion()+";\n");
                 String temp2=Manejador.gen.generarTemporalInt();
                 Manejador.gen.implementaciones.append(temp2+" = PILA ["+temp1+"];\n");
                 /*
                  * INICIA VALIDACION PARA ARRAYS
                  * */
                 if(actual.getTipo().getDimensiones().size()!=0 && !der.getDesplazamiento().equals("") ){
                    Nodo_Metodo_Variable dezTemp = null;
                    if(AmbitoActual.equals("")){
                         dezTemp = Manejador.Tabla.getVariable(Clase, der.getDesplazamiento(), "$"+Clase+"$");
                    }
                    else{
                        dezTemp = Manejador.Tabla.getVariable(Clase, der.getDesplazamiento(), AmbitoActual);
                    }
                    String dezTempPos = Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                    String dezTempVal = Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                    temp1 = Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp2+" = HEAP ["+temp1+"];\n");
                 }
                 /*
                  * TERMINA VALIDACION PARA ARRAYS
                  * */
                 if(i != (id.length - 1)){
                 tmp=temp2;
                 }else{
                 resultado=temp2;
                 }
            }
        }
        derVar = actual;
    }else{
            resultado = id[0];
    }
}


/**********************************************************************************************************
 *                                              IZQUIERDA                                                 *
 **********************************************************************************************************/
tmp="";
Ambito=AmbitoActual;
NombreClase=Clase;
id = ((String)izq.getCadena()).split("[.]");
ArrayList<Nodo_Clase> a=Manejador.Tabla.getTabla();
if(!AmbitoActual.equals("")){
if(!id[0].equals("$a")){
    Nodo_Metodo_Variable Var=Manejador.Tabla.ExisteVariableEnClase(NombreClase, id[0], AmbitoActual);
    if(Var.getAmbito().equals("")){
        izq.setCadena("$a."+izq.getCadena());
    }
}
}else{
    if(!id[0].equals("$a")){
        izq.setCadena("$a."+izq.getCadena());
    }
}
id = ((String)izq.getCadena()).split("[.]");
for(int i = 0; i < id.length; i++){
    if(!izq.isExplicita()){
        Nodo_Metodo_Variable actual;
        if(!id[i].equals("$a")){
        actual = Manejador.Tabla.ExisteVariableEnClase(NombreClase, id[i], Ambito);
        NombreClase= actual.getTipo().getNombre();
        }else{
        actual = Manejador.Tabla.ExisteVariableEnClase(NombreClase, id[i], "$"+NombreClase+"$");
        }
        Ambito = "";
        if(actual.getAmbito().equals("")){
            if(AmbitoActual.equals("")){
                 String temp1=Manejador.gen.generarTemporalInt();
                 Manejador.gen.constructordefault.append(temp1+" = "+tmp+" + "+actual.getPosicion()+";\n");
                 /*
                  * INICIA VALIDACION PARA ARRAYS
                  * */
                 if(actual.getTipo().getDimensiones().size()!=0 && !izq.getDesplazamiento().equals("") ){
                    String arrayRefTemp = Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(arrayRefTemp+" = HEAP ["+temp1+"];\n");

                    Nodo_Metodo_Variable dezTemp = null;
                    if(AmbitoActual.equals("")){
                         dezTemp = Manejador.Tabla.getVariable(Clase, izq.getDesplazamiento(), "$"+Clase+"$");
                    }
                    else{
                        dezTemp = Manejador.Tabla.getVariable(Clase, izq.getDesplazamiento(), AmbitoActual);
                    }
                    String dezTempPos = Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                    String dezTempVal = Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                    temp1 = Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp1+" = "+arrayRefTemp+" + "+dezTempVal+";\n");
                 }
                 /*
                  * TERMINA VALIDACION PARA ARRAYS
                  * */
                 if(i != (id.length - 1)){
                     String temp2=Manejador.gen.generarTemporalInt();
                     Manejador.gen.constructordefault.append(temp2+" = HEAP ["+temp1+"];\n");
                     tmp=temp2;
                 }else{
                     Manejador.gen.constructordefault.append("HEAP ["+temp1+"] = "+resultado+";\n\n");
                 }
            }else{
                 String temp1=Manejador.gen.generarTemporalInt();
                 Manejador.gen.implementaciones.append(temp1+" = "+tmp+" + "+actual.getPosicion()+";\n");
                 /*
                  * INICIA VALIDACION PARA ARRAYS
                  * */
                 if(actual.getTipo().getDimensiones().size()!=0 && !izq.getDesplazamiento().equals("") ){
                    String arrayRefTemp = Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(arrayRefTemp+" = HEAP ["+temp1+"];\n");

                    Nodo_Metodo_Variable dezTemp = null;
                    if(AmbitoActual.equals("")){
                         dezTemp = Manejador.Tabla.getVariable(Clase, izq.getDesplazamiento(), "$"+Clase+"$");
                    }
                    else{
                        dezTemp = Manejador.Tabla.getVariable(Clase, izq.getDesplazamiento(), AmbitoActual);
                    }
                    String dezTempPos = Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                    String dezTempVal = Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                    temp1 = Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp1+" = "+arrayRefTemp+" + "+dezTempVal+";\n");
                 }
                 /*
                  * TERMINA VALIDACION PARA ARRAYS
                  * */
                 if(i != (id.length - 1)){
                 String temp2=Manejador.gen.generarTemporalInt();
                 Manejador.gen.implementaciones.append(temp2+" = HEAP ["+temp1+"];\n");
                 tmp=temp2;
                 }else{
                 Manejador.gen.implementaciones.append("HEAP ["+temp1+"] = "+resultado+";\n\n");
                 }
            }
        }
        else{
            if(AmbitoActual.equals("")){
                 String temp1=Manejador.gen.generarTemporalInt();
                 Manejador.gen.constructordefault.append(temp1+" = PTR_PILA + "+actual.getPosicion()+";\n");
                 /*
                  * INICIA VALIDACION PARA ARRAYS
                  * */
                 if(actual.getTipo().getDimensiones().size()!=0 && !izq.getDesplazamiento().equals("") ){
                    String arrayRefTemp = Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(arrayRefTemp+" = PILA ["+temp1+"];\n");

                    Nodo_Metodo_Variable dezTemp = null;
                    if(AmbitoActual.equals("")){
                         dezTemp = Manejador.Tabla.getVariable(Clase, izq.getDesplazamiento(), "$"+Clase+"$");
                    }
                    else{
                        dezTemp = Manejador.Tabla.getVariable(Clase, izq.getDesplazamiento(), AmbitoActual);
                    }
                    String dezTempPos = Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                    String dezTempVal = Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                    temp1 = Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp1+" = "+arrayRefTemp+" + "+dezTempVal+";\n");
                    if(i != (id.length - 1)){
                        String temp2=Manejador.gen.generarTemporalInt();
                        Manejador.gen.constructordefault.append(temp2+" = HEAP ["+temp1+"];\n");
                        tmp=temp2;
                    }else{
                        Manejador.gen.constructordefault.append("HEAP ["+temp1+"] = "+resultado+";\n\n");
                    }
                 }
                 /*
                  * TERMINA VALIDACION PARA ARRAYS
                  * */
                 else{
                     if(i != (id.length - 1)){
                     String temp2=Manejador.gen.generarTemporalInt();
                     Manejador.gen.constructordefault.append(temp2+" = PILA ["+temp1+"];\n");
                     tmp=temp2;
                     }else{
                     Manejador.gen.constructordefault.append("PILA ["+temp1+"] = "+resultado+";\n\n");
                     }
                 }
            }else{
                 String temp1=Manejador.gen.generarTemporalInt();
                 Manejador.gen.implementaciones.append(temp1+" = PTR_PILA + "+actual.getPosicion()+";\n");
                 /*
                  * INICIA VALIDACION PARA ARRAYS
                  * */
                 if(actual.getTipo().getDimensiones().size()!=0 && !izq.getDesplazamiento().equals("") ){
                    String arrayRefTemp = Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(arrayRefTemp+" = PILA ["+temp1+"];\n");

                    Nodo_Metodo_Variable dezTemp = null;
                    if(AmbitoActual.equals("")){
                         dezTemp = Manejador.Tabla.getVariable(Clase, izq.getDesplazamiento(), "$"+Clase+"$");
                    }
                    else{
                        dezTemp = Manejador.Tabla.getVariable(Clase, izq.getDesplazamiento(), AmbitoActual);
                    }
                    String dezTempPos = Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                    String dezTempVal = Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                    temp1 = Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp1+" = "+arrayRefTemp+" + "+dezTempVal+";\n");
                    if(i != (id.length - 1)){
                        String temp2=Manejador.gen.generarTemporalInt();
                        Manejador.gen.implementaciones.append(temp2+" = HEAP ["+temp1+"];\n");
                        tmp=temp2;
                    }else{
                        Manejador.gen.implementaciones.append("HEAP ["+temp1+"] = "+resultado+";\n\n");
                    }
                 }
                 /*
                  * TERMINA VALIDACION PARA ARRAYS
                  * */
                 else{
                     if(i != (id.length - 1)){
                     String temp2=Manejador.gen.generarTemporalInt();
                     Manejador.gen.implementaciones.append(temp2+" = PILA ["+temp1+"];\n");
                     tmp=temp2;
                     }else{
                     Manejador.gen.implementaciones.append("PILA ["+temp1+"] = "+resultado+";\n\n");
                     }
                 }
            }

        }
        izqVar = actual;
    }else{
            error("Error Semantico: NO es Posible Valor Explicito de Lado Izquierdo", izq.getLinea());
    }
}
if((derVar != null && izqVar != null) && (derVar.getTipo().getNombre().equals("String") && izqVar.getTipo().getNombre().equals("String"))){
    izqVar.getTipo().setDimensiones(derVar.getTipo().getDimensiones());
}
}


/**
 *
 * @param nom
 * @param ClaseActual
 * @param MetodoActual
 * @param AmbitoActual
 * @return
 */
public MiNodo Invocacion_Metodo_sin_Arg(MiNodo nom, String ClaseActual,Nodo_Metodo_Variable MetodoActual, String AmbitoActual){
    MiNodo RESULT=new MiNodo();
    String invocacion = (String)nom.getCadena();
    if(invocacion.equals("readInt")){
        String temp=Manejador.gen.generarTemporalInt();
        Manejador.gen.implementaciones.append("scanf(\"%i\" , &"+temp+");\n");
        int posicion=MetodoActual.getTamañoPila();
        MetodoActual.setTamañoPila(posicion+1);
        Manejador.Tabla.AddVariableLocal(ClaseActual, temp, Papel.VARLOCAL, AmbitoActual, posicion, "int");

        String temp2=Manejador.gen.generarTemporalInt();
        Manejador.gen.implementaciones.append(temp2+" = PTR_PILA + "+posicion+";\n");
        Manejador.gen.implementaciones.append("PILA ["+temp2+"] = "+temp+";\n");

        RESULT=new MiNodo(temp, SConstantes.IMPLICITA, SConstantes.LOCAL, new Nodo_Tipo("int"));
    }
    else if(invocacion.equals("readFloat")){
        String temp=Manejador.gen.generarTemporalInt();
        Manejador.gen.implementaciones.append("scanf(\"%i\" , &"+temp+");\n");
        int posicion=MetodoActual.getTamañoPila();
        MetodoActual.setTamañoPila(posicion+1);
        Manejador.Tabla.AddVariableLocal(ClaseActual, temp, Papel.VARLOCAL, AmbitoActual, posicion, "int");

        String temp2=Manejador.gen.generarTemporalInt();
        Manejador.gen.implementaciones.append(temp2+" = PTR_PILA + "+posicion+";\n");
        Manejador.gen.implementaciones.append("PILA ["+temp2+"] = "+temp+";\n");

        RESULT=new MiNodo(temp, SConstantes.IMPLICITA, SConstantes.LOCAL, new Nodo_Tipo("int"));
    }
    else if(invocacion.equals("readChar")){
        String temp=Manejador.gen.generarTemporalInt();
        Manejador.gen.implementaciones.append("scanf(\"%c\" , &"+temp+");\n");
        int posicion=MetodoActual.getTamañoPila();
        MetodoActual.setTamañoPila(posicion+1);
        Manejador.Tabla.AddVariableLocal(ClaseActual, temp, Papel.VARLOCAL, AmbitoActual, posicion, "char");

        String temp2=Manejador.gen.generarTemporalInt();
        Manejador.gen.implementaciones.append(temp2+" = PTR_PILA + "+posicion+";\n");
        Manejador.gen.implementaciones.append("PILA ["+temp2+"] = "+temp+";\n");

        RESULT=new MiNodo(temp, SConstantes.IMPLICITA, SConstantes.LOCAL, new Nodo_Tipo("char"));
    }
    else if(invocacion.equals("readLong")){
        String temp=Manejador.gen.generarTemporalInt();
        Manejador.gen.implementaciones.append("scanf(\"%i\" , &"+temp+");\n");
        int posicion=MetodoActual.getTamañoPila();
        MetodoActual.setTamañoPila(posicion+1);
        Manejador.Tabla.AddVariableLocal(ClaseActual, temp, Papel.VARLOCAL, AmbitoActual, posicion, "int");

        String temp2=Manejador.gen.generarTemporalInt();
        Manejador.gen.implementaciones.append(temp2+" = PTR_PILA + "+posicion+";\n");
        Manejador.gen.implementaciones.append("PILA ["+temp2+"] = "+temp+";\n");

        RESULT=new MiNodo(temp, SConstantes.IMPLICITA, SConstantes.LOCAL, new Nodo_Tipo("int"));
    }
    else if(invocacion.equals("readDouble")){
        String temp=Manejador.gen.generarTemporalInt();
        Manejador.gen.implementaciones.append("scanf(\"%i\" , &"+temp+");\n");
        int posicion=MetodoActual.getTamañoPila();
        MetodoActual.setTamañoPila(posicion+1);
        Manejador.Tabla.AddVariableLocal(ClaseActual, temp, Papel.VARLOCAL, AmbitoActual, posicion, "int");

        String temp2=Manejador.gen.generarTemporalInt();
        Manejador.gen.implementaciones.append(temp2+" = PTR_PILA + "+posicion+";\n");
        Manejador.gen.implementaciones.append("PILA ["+temp2+"] = "+temp+";\n");

        RESULT=new MiNodo(temp, SConstantes.IMPLICITA, SConstantes.LOCAL, new Nodo_Tipo("int"));
    }
    else if(invocacion.equals("readString")){

    }
    else if(invocacion.equals("getch")){
        Manejador.gen.implementaciones.append("getch();\n");
    }
    else{
    String[] id = ((String)nom.getCadena()).split("[.]");
    String tmp="", resultado="", NombreClase=ClaseActual, Ambito = AmbitoActual;
    String listaParams="void";
    Nodo_Metodo_Variable Metodo;

    if(id.length == 1){
        nom.setCadena("$a."+nom.getCadena());
    }else{
        if(!AmbitoActual.equals("")){
            if(!id[0].equals("$a")){
                Nodo_Metodo_Variable Var=Manejador.Tabla.ExisteVariableEnClase(NombreClase, id[0], Ambito);
                if(Var.getAmbito().equals("")){
                    nom.setCadena("$a."+nom.getCadena());
                }
            }
        }else{
            if(!id[0].equals("$a")){
                nom.setCadena("$a."+nom.getCadena());
            }
        }
    }

    id = ((String)nom.getCadena()).split("[.]");
    for(int i = 0; i < id.length; i++){
        if(!nom.isExplicita()){
            if(i == (id.length - 1)){
                String nombreMetodo = id[i];
                Metodo = Manejador.Tabla.getMetodo(NombreClase, nombreMetodo, Papel.METODO, listaParams);
                if(AmbitoActual.equals("")){
                     MetodoActual=(Nodo_Metodo_Variable)Manejador.Tabla.getMetodo(ClaseActual, "$"+ClaseActual+"$", Papel.CONSTRUCTOR, "void");
                     String temp=Manejador.gen.generarTemporalInt();
                     Manejador.gen.constructordefault.append(temp+" = PTR_PILA + "+MetodoActual.getTamañoPila()+";\n");
                     String temp2=Manejador.gen.generarTemporalInt();
                     Manejador.gen.constructordefault.append(temp2+" = "+temp+" + 0;\n");
                     Manejador.gen.constructordefault.append("PILA ["+temp2+"] = "+resultado+";\n");

                     Manejador.gen.constructordefault.append("PTR_PILA = PTR_PILA + "+MetodoActual.getTamañoPila()+";\n");
                     Manejador.gen.constructordefault.append(NombreClase+"$"+nombreMetodo+"$void();\n");
                     temp=Manejador.gen.generarTemporalInt();
                     Nodo_Metodo_Variable $return=null;
                     if(Metodo.getListaArgumentos().equalsIgnoreCase("void")){
                     $return=((Nodo_Metodo_Variable)Manejador.Tabla.getVariable(NombreClase, "$return", Metodo.getRol()+Metodo.getNombre()));
                     }else{
                     $return=((Nodo_Metodo_Variable)Manejador.Tabla.getVariable(NombreClase, "$return", Metodo.getRol()+Metodo.getNombre()+"&"+Metodo.getListaArgumentos()));
                     }
                     Manejador.gen.constructordefault.append(temp+" = PTR_PILA + "+$return.getPosicion()+";\n");
                     temp2=Manejador.gen.generarTemporalInt();
                     Manejador.gen.constructordefault.append(temp2+" = PILA ["+temp+"];\n");
                     Manejador.gen.constructordefault.append("PTR_PILA = PTR_PILA - "+MetodoActual.getTamañoPila()+";\n");

                     int posicion=MetodoActual.getTamañoPila();
                     MetodoActual.setTamañoPila(posicion+1);
                     Manejador.Tabla.AddVariableLocal(ClaseActual, temp2, Papel.VARLOCAL, "$"+ClaseActual+"$", posicion, "int");

                     temp=Manejador.gen.generarTemporalInt();
                     Manejador.gen.constructordefault.append(temp+" = PTR_PILA + "+posicion+";\n");
                     Manejador.gen.constructordefault.append("PILA ["+temp+"] = "+temp2+";\n");

                     RESULT=new MiNodo(temp2, SConstantes.IMPLICITA, SConstantes.LOCAL, Metodo.getTipo());
                }else{
                     String temp=Manejador.gen.generarTemporalInt();
                     Manejador.gen.implementaciones.append(temp+" = PTR_PILA + "+MetodoActual.getTamañoPila()+";\n");
                     String temp2=Manejador.gen.generarTemporalInt();
                     Manejador.gen.implementaciones.append(temp2+" = "+temp+" + 0;\n");
                     Manejador.gen.implementaciones.append("PILA ["+temp2+"] = "+resultado+";\n");

                     Manejador.gen.implementaciones.append("PTR_PILA = PTR_PILA + "+MetodoActual.getTamañoPila()+";\n");
                     Manejador.gen.implementaciones.append(NombreClase+"$"+nombreMetodo+"$void();\n");
                     temp=Manejador.gen.generarTemporalInt();
                     Nodo_Metodo_Variable $return=null;
                     if(Metodo.getListaArgumentos().equalsIgnoreCase("void")){
                     $return=((Nodo_Metodo_Variable)Manejador.Tabla.getVariable(NombreClase, "$return", Metodo.getRol()+Metodo.getNombre()));
                     }else{
                     $return=((Nodo_Metodo_Variable)Manejador.Tabla.getVariable(NombreClase, "$return", Metodo.getRol()+Metodo.getNombre()+"&"+Metodo.getListaArgumentos()));
                     }
                     Manejador.gen.implementaciones.append(temp+" = PTR_PILA + "+$return.getPosicion()+";\n");
                     temp2=Manejador.gen.generarTemporalInt();
                     Manejador.gen.implementaciones.append(temp2+" = PILA ["+temp+"];\n");
                     Manejador.gen.implementaciones.append("PTR_PILA = PTR_PILA - "+MetodoActual.getTamañoPila()+";\n");

                     int posicion=MetodoActual.getTamañoPila();
                     MetodoActual.setTamañoPila(posicion+1);
                     Manejador.Tabla.AddVariableLocal(ClaseActual, temp2, Papel.VARLOCAL, AmbitoActual, posicion, "int");

                     temp=Manejador.gen.generarTemporalInt();
                     Manejador.gen.implementaciones.append(temp+" = PTR_PILA + "+posicion+";\n");
                     Manejador.gen.implementaciones.append("PILA ["+temp+"] = "+temp2+";\n");

                     RESULT=new MiNodo(temp2, SConstantes.IMPLICITA, SConstantes.LOCAL, Metodo.getTipo());
                }

            }else{
                Nodo_Metodo_Variable actual;
                if(!id[i].equals("$a")){
                    actual = Manejador.Tabla.getVariable(NombreClase, id[i], Ambito);
                }else{
                    actual = Manejador.Tabla.getVariable(NombreClase, id[i], "$"+NombreClase+"$");
                }

                NombreClase= actual.getTipo().getNombre();
                Ambito = "";
                if(actual.getAmbito().equals("")){
                    if(AmbitoActual.equals("")){
                         String temp1=Manejador.gen.generarTemporalInt();
                         Manejador.gen.constructordefault.append(temp1+" = "+tmp+" + "+actual.getPosicion()+";\n");
                         String temp2=Manejador.gen.generarTemporalInt();
                         Manejador.gen.constructordefault.append(temp2+" = HEAP ["+temp1+"];\n");
                         /*
                          * INICIA VALIDACION PARA ARRAYS
                          * */
                         if(actual.getTipo().getDimensiones().size()!=0 && !nom.getDesplazamiento().equals("") ){
                            Nodo_Metodo_Variable dezTemp = null;
                            if(AmbitoActual.equals("")){
                                 dezTemp = Manejador.Tabla.getVariable(ClaseActual, nom.getDesplazamiento(), "$"+ClaseActual+"$");
                            }
                            else{
                                dezTemp = Manejador.Tabla.getVariable(ClaseActual, nom.getDesplazamiento(), AmbitoActual);
                            }
                            String dezTempPos = Manejador.gen.generarTemporalInt();
                            Manejador.gen.constructordefault.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                            String dezTempVal = Manejador.gen.generarTemporalInt();
                            Manejador.gen.constructordefault.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                            temp1 = Manejador.gen.generarTemporalInt();
                            Manejador.gen.constructordefault.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                            temp2=Manejador.gen.generarTemporalInt();
                            Manejador.gen.constructordefault.append(temp2+" = HEAP ["+temp1+"];\n");
                         }
                         /*
                          * TERMINA VALIDACION PARA ARRAYS
                          * */
                         if(i != (id.length - 2)){
                            tmp=temp2;
                         }else{
                            resultado=temp2;
                         }
                    }else{
                         String temp1=Manejador.gen.generarTemporalInt();
                         Manejador.gen.implementaciones.append(temp1+" = "+tmp+" + "+actual.getPosicion()+";\n");
                         String temp2=Manejador.gen.generarTemporalInt();
                         Manejador.gen.implementaciones.append(temp2+" = HEAP ["+temp1+"];\n");
                         /*
                          * INICIA VALIDACION PARA ARRAYS
                          * */
                         if(actual.getTipo().getDimensiones().size()!=0 && !nom.getDesplazamiento().equals("") ){
                            Nodo_Metodo_Variable dezTemp = null;
                            if(AmbitoActual.equals("")){
                                 dezTemp = Manejador.Tabla.getVariable(ClaseActual, nom.getDesplazamiento(), "$"+ClaseActual+"$");
                            }
                            else{
                                dezTemp = Manejador.Tabla.getVariable(ClaseActual, nom.getDesplazamiento(), AmbitoActual);
                            }
                            String dezTempPos = Manejador.gen.generarTemporalInt();
                            Manejador.gen.implementaciones.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                            String dezTempVal = Manejador.gen.generarTemporalInt();
                            Manejador.gen.implementaciones.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                            temp1 = Manejador.gen.generarTemporalInt();
                            Manejador.gen.implementaciones.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                            temp2=Manejador.gen.generarTemporalInt();
                            Manejador.gen.implementaciones.append(temp2+" = HEAP ["+temp1+"];\n");
                         }
                         /*
                          * TERMINA VALIDACION PARA ARRAYS
                          * */
                         if(i != (id.length - 2)){
                            tmp=temp2;
                         }else{
                            resultado=temp2;
                         }
                    }
                }
                else{
                    if(AmbitoActual.equals("")){
                         String temp1=Manejador.gen.generarTemporalInt();
                         Manejador.gen.constructordefault.append(temp1+" = PTR_PILA + "+actual.getPosicion()+";\n");
                         String temp2=Manejador.gen.generarTemporalInt();
                         Manejador.gen.constructordefault.append(temp2+" = PILA ["+temp1+"];\n");
                         /*
                          * INICIA VALIDACION PARA ARRAYS
                          * */
                         if(actual.getTipo().getDimensiones().size()!=0 && !nom.getDesplazamiento().equals("") ){
                            Nodo_Metodo_Variable dezTemp = null;
                            if(AmbitoActual.equals("")){
                                 dezTemp = Manejador.Tabla.getVariable(ClaseActual, nom.getDesplazamiento(), "$"+ClaseActual+"$");
                            }
                            else{
                                dezTemp = Manejador.Tabla.getVariable(ClaseActual, nom.getDesplazamiento(), AmbitoActual);
                            }
                            String dezTempPos = Manejador.gen.generarTemporalInt();
                            Manejador.gen.constructordefault.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                            String dezTempVal = Manejador.gen.generarTemporalInt();
                            Manejador.gen.constructordefault.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                            temp1 = Manejador.gen.generarTemporalInt();
                            Manejador.gen.constructordefault.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                            temp2=Manejador.gen.generarTemporalInt();
                            Manejador.gen.constructordefault.append(temp2+" = HEAP ["+temp1+"];\n");
                         }
                         /*
                          * TERMINA VALIDACION PARA ARRAYS
                          * */
                         if(i != (id.length - 2)){
                            tmp=temp2;
                         }else{
                            resultado=temp2;
                         }
                    }else{
                         String temp1=Manejador.gen.generarTemporalInt();
                         Manejador.gen.implementaciones.append(temp1+" = PTR_PILA + "+actual.getPosicion()+";\n");
                         String temp2=Manejador.gen.generarTemporalInt();
                         Manejador.gen.implementaciones.append(temp2+" = PILA ["+temp1+"];\n");
                         /*
                          * INICIA VALIDACION PARA ARRAYS
                          * */
                         if(actual.getTipo().getDimensiones().size()!=0 && !nom.getDesplazamiento().equals("") ){
                            Nodo_Metodo_Variable dezTemp = null;
                            if(AmbitoActual.equals("")){
                                 dezTemp = Manejador.Tabla.getVariable(ClaseActual, nom.getDesplazamiento(), "$"+ClaseActual+"$");
                            }
                            else{
                                dezTemp = Manejador.Tabla.getVariable(ClaseActual, nom.getDesplazamiento(), AmbitoActual);
                            }
                            String dezTempPos = Manejador.gen.generarTemporalInt();
                            Manejador.gen.implementaciones.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                            String dezTempVal = Manejador.gen.generarTemporalInt();
                            Manejador.gen.implementaciones.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                            temp1 = Manejador.gen.generarTemporalInt();
                            Manejador.gen.implementaciones.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                            temp2=Manejador.gen.generarTemporalInt();
                            Manejador.gen.implementaciones.append(temp2+" = HEAP ["+temp1+"];\n");
                         }
                         /*
                          * TERMINA VALIDACION PARA ARRAYS
                          * */
                         if(i != (id.length - 2)){
                            tmp=temp2;
                         }else{
                            resultado=temp2;
                         }
                    }
                }
            }
        }else{
         error("Error Semantico: ...", nom.getLinea());
        }
    }
    }
    return RESULT;
}

public MiNodo Invocacion_Metodo_con_Arg(MiNodo nom, MiNodo lista, String ClaseActual,Nodo_Metodo_Variable MetodoActual, String AmbitoActual){
    MiNodo RESULT=new MiNodo();

    String invocacion = (String)nom.getCadena();
    String[] id = ((String)nom.getCadena()).split("[.]");
    String tmp="", resultado="", NombreClase=ClaseActual, Ambito = AmbitoActual;
    ArrayList<MiNodo> listaparam=(ArrayList<MiNodo>)lista.getDato();
    Nodo_Metodo_Variable Metodo=null;
    String nombreMetodo="";
    String listaParams="void";
    if(invocacion.equals("print")||invocacion.equals("println")){
        try{
            MiNodo paramCad = listaparam.get(0);
            resultado = this.ExpresionDerecho(paramCad, NombreClase, AmbitoActual);
            if(!paramCad.isExplicita()){
                String cadena = (String)paramCad.getCadena();
                id = cadena.split("[.]");
                Nodo_Metodo_Variable variable = null;
                if(!AmbitoActual.equals("")){
                    if(!id[0].equals("$a")){
                        Nodo_Metodo_Variable Var=Manejador.Tabla.ExisteVariableEnClase(NombreClase, id[0], Ambito);
                        if(Var.getAmbito().equals("")){
                            cadena = "$a."+cadena;
                        }
                    }
                }else{
                    if(!id[0].equals("$a")){
                        cadena = "$a."+cadena;
                    }
                }
                id = cadena.split("[.]");
                for(int i = 0; i < id.length; i++){
                    if(!paramCad.isExplicita()){
                        if(!id[i].equals("$a")){
                            variable = Manejador.Tabla.ExisteVariableEnClase(NombreClase, id[i], Ambito);
                            NombreClase = variable.getTipo().getNombre();
                        }else{
                            variable = Manejador.Tabla.getVariable(NombreClase, id[i], "$"+NombreClase+"$");
                        }
                        Ambito = "";
                    }
                    else{
                        //error
                    }
                }
                if(variable.getTipo().getNombre().equals("String")){
                    for(int i = 0; i < variable.getTipo().getDimensiones().get(0); i++){
                        String temp2=Manejador.gen.generarTemporalInt();
                        Manejador.gen.implementaciones.append(temp2+" = "+resultado+" + "+i+";\n");
                        String temp3=Manejador.gen.generarTemporalInt();
                        Manejador.gen.implementaciones.append(""+temp3+" = HEAP ["+temp2+"];\n");
                        Manejador.gen.implementaciones.append("printf(\"%c\" , "+temp3+");\n");
                    }
                }
                else if(variable.getTipo().getNombre().equals("int")){
                    Manejador.gen.implementaciones.append("printf(\"%i\" , "+resultado+");\n");
                }
                else if(variable.getTipo().getNombre().equals("char")){
                    Manejador.gen.implementaciones.append("printf(\"%c\" , "+resultado+");\n");
                }
                else if(variable.getTipo().getNombre().equals("boolean")){
                    Manejador.gen.implementaciones.append("printf(\"%i\" , "+resultado+");\n");
                }
                else{
                    //error, no exite poliformismo para ese tipo de datos
                }
                RESULT=new MiNodo(resultado, SConstantes.IMPLICITA, SConstantes.LOCAL, new Nodo_Tipo("void"));
            }
            else{
                if(paramCad.getTipo().getNombre().equals("int")){
                    Manejador.gen.implementaciones.append("printf(\"%i\" , "+resultado+");\n");
                }
                else if(paramCad.getTipo().getNombre().equals("char")){
                     Manejador.gen.implementaciones.append("printf(\"%c\" , "+resultado+");\n");
                }
                else if(paramCad.getTipo().getNombre().equals("boolean")){
                     Manejador.gen.implementaciones.append("printf(\"%i\" , "+resultado+");\n");
                }
                else{
                    //error, no exite poliformismo para ese tipo de datos
                }
                RESULT=new MiNodo(resultado, SConstantes.EXPLICITA, SConstantes.LOCAL, new Nodo_Tipo("void"));
            }
            if(invocacion.endsWith("ln")){
                Manejador.gen.implementaciones.append("printf(\"%c\" , 10);\n");
                Manejador.gen.implementaciones.append("printf(\"%c\" , 13);\n");
            }

        }
        catch(Exception e){
            //error.
        }
    }
    else{
    for(int i=0;i<listaparam.size();i++){
        if(listaparam.get(i).isExplicita()){
            if(i==0){
                listaParams=listaparam.get(i).getTipo().getNombre();
            }else{
                listaParams=listaParams+"&"+listaparam.get(i).getTipo().getNombre();
            }
        }else{
             Nodo_Metodo_Variable Aux =(Nodo_Metodo_Variable)Manejador.Tabla.ExisteVariableEnClase(NombreClase,(String)listaparam.get(i).getCadena(),AmbitoActual);
            if(i==0){
                listaParams=Aux.getTipo().getNombre();
            }else{
                listaParams=listaParams+"&"+Aux.getTipo().getNombre();
            }
        }

    }

    if(id.length == 1){
        nom.setCadena("$a."+nom.getCadena());
    }else{
    if(!AmbitoActual.equals("")){
        if(!id[0].equals("$a")){
            Nodo_Metodo_Variable Var=Manejador.Tabla.ExisteVariableEnClase(NombreClase, id[0], Ambito);
            if(Var.getAmbito().equals("")){
                nom.setCadena("$a."+nom.getCadena());
            }
        }
            }else{
            if(!id[0].equals("$a")){
            nom.setCadena("$a."+nom.getCadena());
            }
        }
    }
    id = ((String)nom.getCadena()).split("[.]");
    for(int i = 0; i < id.length; i++){
        if(!nom.isExplicita()){
            if(i == (id.length - 1)){
                nombreMetodo = id[i];
                Metodo = Manejador.Tabla.getMetodo(NombreClase, nombreMetodo, Papel.METODO, listaParams);
                if(AmbitoActual.equals("")){
                     MetodoActual=(Nodo_Metodo_Variable)Manejador.Tabla.getMetodo(ClaseActual, "$"+ClaseActual+"$", Papel.CONSTRUCTOR, "void");
                     String temp=Manejador.gen.generarTemporalInt();
                     Manejador.gen.constructordefault.append(temp+" = PTR_PILA + "+MetodoActual.getTamañoPila()+";\n");
                     String temp2=Manejador.gen.generarTemporalInt();
                     Manejador.gen.constructordefault.append(temp2+" = "+temp+" + 0;\n");
                     Manejador.gen.constructordefault.append("PILA ["+temp2+"] = "+resultado+";\n");
                }else{
                     String temp=Manejador.gen.generarTemporalInt();
                     Manejador.gen.implementaciones.append(temp+" = PTR_PILA + "+MetodoActual.getTamañoPila()+";\n");
                     String temp2=Manejador.gen.generarTemporalInt();
                     Manejador.gen.implementaciones.append(temp2+" = "+temp+" + 0;\n");
                     Manejador.gen.implementaciones.append("PILA ["+temp2+"] = "+resultado+";\n");
                }
            }else{
                Nodo_Metodo_Variable actual;
                if(!id[i].equals("$a")){
                    actual = Manejador.Tabla.getVariable(NombreClase, id[i], Ambito);
                }else{
                    actual = Manejador.Tabla.getVariable(NombreClase, id[i], "$"+NombreClase+"$");
                }
                NombreClase= actual.getTipo().getNombre();
                Ambito = "";
                if(actual.getAmbito().equals("")){
                    if(AmbitoActual.equals("")){
                         String temp1=Manejador.gen.generarTemporalInt();
                         Manejador.gen.constructordefault.append(temp1+" = "+tmp+" + "+actual.getPosicion()+";\n");
                         String temp2=Manejador.gen.generarTemporalInt();
                         Manejador.gen.constructordefault.append(temp2+" = HEAP ["+temp1+"];\n");
                         /*
                          * INICIA VALIDACION PARA ARRAYS
                          * */
                         if(actual.getTipo().getDimensiones().size()!=0 && !nom.getDesplazamiento().equals("") ){
                            Nodo_Metodo_Variable dezTemp = null;
                            if(AmbitoActual.equals("")){
                                 dezTemp = Manejador.Tabla.getVariable(ClaseActual, nom.getDesplazamiento(), "$"+ClaseActual+"$");
                            }
                            else{
                                dezTemp = Manejador.Tabla.getVariable(ClaseActual, nom.getDesplazamiento(), AmbitoActual);
                            }
                            String dezTempPos = Manejador.gen.generarTemporalInt();
                            Manejador.gen.constructordefault.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                            String dezTempVal = Manejador.gen.generarTemporalInt();
                            Manejador.gen.constructordefault.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                            temp1 = Manejador.gen.generarTemporalInt();
                            Manejador.gen.constructordefault.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                            temp2=Manejador.gen.generarTemporalInt();
                            Manejador.gen.constructordefault.append(temp2+" = HEAP ["+temp1+"];\n");
                         }
                         /*
                          * TERMINA VALIDACION PARA ARRAYS
                          * */
                         if(i != (id.length - 2)){
                         tmp=temp2;
                         }else{
                         resultado=temp2;
                         }
                    }else{
                         String temp1=Manejador.gen.generarTemporalInt();
                         Manejador.gen.implementaciones.append(temp1+" = "+tmp+" + "+actual.getPosicion()+";\n");
                         String temp2=Manejador.gen.generarTemporalInt();
                         Manejador.gen.implementaciones.append(temp2+" = HEAP ["+temp1+"];\n");
                         /*
                          * INICIA VALIDACION PARA ARRAYS
                          * */
                         if(actual.getTipo().getDimensiones().size()!=0 && !nom.getDesplazamiento().equals("") ){
                            Nodo_Metodo_Variable dezTemp = null;
                            if(AmbitoActual.equals("")){
                                 dezTemp = Manejador.Tabla.getVariable(ClaseActual, nom.getDesplazamiento(), "$"+ClaseActual+"$");
                            }
                            else{
                                dezTemp = Manejador.Tabla.getVariable(ClaseActual, nom.getDesplazamiento(), AmbitoActual);
                            }
                            String dezTempPos = Manejador.gen.generarTemporalInt();
                            Manejador.gen.implementaciones.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                            String dezTempVal = Manejador.gen.generarTemporalInt();
                            Manejador.gen.implementaciones.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                            temp1 = Manejador.gen.generarTemporalInt();
                            Manejador.gen.implementaciones.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                            temp2=Manejador.gen.generarTemporalInt();
                            Manejador.gen.implementaciones.append(temp2+" = HEAP ["+temp1+"];\n");
                         }
                         /*
                          * TERMINA VALIDACION PARA ARRAYS
                          * */
                         if(i != (id.length - 2)){
                            tmp=temp2;
                         }else{
                            resultado=temp2;
                         }
                    }
				}
                else{
                    if(AmbitoActual.equals("")){
                         String temp1=Manejador.gen.generarTemporalInt();
                         Manejador.gen.constructordefault.append(temp1+" = PTR_PILA + "+actual.getPosicion()+";\n");
                         String temp2=Manejador.gen.generarTemporalInt();
                         Manejador.gen.constructordefault.append(temp2+" = PILA ["+temp1+"];\n");
                         /*
                          * INICIA VALIDACION PARA ARRAYS
                          * */
                         if(actual.getTipo().getDimensiones().size()!=0 && !nom.getDesplazamiento().equals("") ){
                            Nodo_Metodo_Variable dezTemp = null;
                            if(AmbitoActual.equals("")){
                                 dezTemp = Manejador.Tabla.getVariable(ClaseActual, nom.getDesplazamiento(), "$"+ClaseActual+"$");
                            }
                            else{
                                dezTemp = Manejador.Tabla.getVariable(ClaseActual, nom.getDesplazamiento(), AmbitoActual);
                            }
                            String dezTempPos = Manejador.gen.generarTemporalInt();
                            Manejador.gen.constructordefault.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                            String dezTempVal = Manejador.gen.generarTemporalInt();
                            Manejador.gen.constructordefault.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                            temp1 = Manejador.gen.generarTemporalInt();
                            Manejador.gen.constructordefault.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                            temp2=Manejador.gen.generarTemporalInt();
                            Manejador.gen.constructordefault.append(temp2+" = HEAP ["+temp1+"];\n");
                         }
                         /*
                          * TERMINA VALIDACION PARA ARRAYS
                          * */
                         if(i != (id.length - 2)){
                         tmp=temp2;
                         }else{
                         resultado=temp2;
                         }
                    }else{
                         String temp1=Manejador.gen.generarTemporalInt();
                         Manejador.gen.implementaciones.append(temp1+" = PTR_PILA + "+actual.getPosicion()+";\n");
                         String temp2=Manejador.gen.generarTemporalInt();
                         Manejador.gen.implementaciones.append(temp2+" = PILA ["+temp1+"];\n");
                         /*
                          * INICIA VALIDACION PARA ARRAYS
                          * */
                         if(actual.getTipo().getDimensiones().size()!=0 && !nom.getDesplazamiento().equals("") ){
                            Nodo_Metodo_Variable dezTemp = null;
                            if(AmbitoActual.equals("")){
                                 dezTemp = Manejador.Tabla.getVariable(ClaseActual, nom.getDesplazamiento(), "$"+ClaseActual+"$");
                            }
                            else{
                                dezTemp = Manejador.Tabla.getVariable(ClaseActual, nom.getDesplazamiento(), AmbitoActual);
                            }
                            String dezTempPos = Manejador.gen.generarTemporalInt();
                            Manejador.gen.implementaciones.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                            String dezTempVal = Manejador.gen.generarTemporalInt();
                            Manejador.gen.implementaciones.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                            temp1 = Manejador.gen.generarTemporalInt();
                            Manejador.gen.implementaciones.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                            temp2=Manejador.gen.generarTemporalInt();
                            Manejador.gen.implementaciones.append(temp2+" = HEAP ["+temp1+"];\n");
                         }
                         /*
                          * TERMINA VALIDACION PARA ARRAYS
                          * */
                         if(i != (id.length - 2)){
                         tmp=temp2;
                         }else{
                         resultado=temp2;
                         }
                    }
                }
            }
        }else{
         error("Error Semantico: ...", nom.getLinea());
        }
    }

    String Clase=NombreClase;
    for(int j = 0; j<listaparam.size(); j++){
            MiNodo der=listaparam.get(j);
        id = ((String)der.getCadena()).split("[.]");
        tmp="";
            resultado="";
            Ambito=AmbitoActual;
            NombreClase=ClaseActual;

    if(!der.isExplicita()){
    if(!AmbitoActual.equals("")){
    if(!id[0].equals("$a")){
        Nodo_Metodo_Variable Var=Manejador.Tabla.ExisteVariableEnClase(NombreClase, id[0], Ambito);
        if(Var.getAmbito().equals("")){
            if(!der.getCadena().toString().startsWith("$t")){
            der.setCadena("$a."+der.getCadena());
            }
        }
    }
    }else{
        if(!id[0].equals("$a")){
            if(!der.getCadena().toString().startsWith("$t")){
                der.setCadena("$a."+der.getCadena());
            }
        }
    }
    }
    id= ((String)der.getCadena()).split("[.]");
    for(int i = 0; i < id.length; i++){
        if(!der.isExplicita()){
            Nodo_Metodo_Variable actual;
            if(!id[i].equals("$a")){
             if((!id[i].startsWith("$t"))){
                actual = Manejador.Tabla.ExisteVariableEnClase(NombreClase, id[i], Ambito);
             }else{
                 if(!Ambito.equals("")){
                 actual = Manejador.Tabla.ExisteVariableEnClase(NombreClase, id[i], Ambito);
                 }else{
                 actual = Manejador.Tabla.ExisteVariableEnClase(NombreClase, id[i], 1+"$"+ClaseActual+"$");
                 }
             }
            NombreClase= actual.getTipo().getNombre();
            }else{
            actual = Manejador.Tabla.getVariable(NombreClase, id[i], "$"+NombreClase+"$");
            }
            Ambito = "";
            if(actual.getAmbito().equals("")){
                if(AmbitoActual.equals("")){
                     String temp1=Manejador.gen.generarTemporalInt();
                     Manejador.gen.constructordefault.append(temp1+" = "+tmp+" + "+actual.getPosicion()+";\n");
                     String temp2=Manejador.gen.generarTemporalInt();
                     Manejador.gen.constructordefault.append(temp2+" = HEAP ["+temp1+"];\n");
                     /*
                      * INICIA VALIDACION PARA ARRAYS
                      * */
                     if(actual.getTipo().getDimensiones().size()!=0 && !der.getDesplazamiento().equals("") ){
                        Nodo_Metodo_Variable dezTemp = null;
                        if(AmbitoActual.equals("")){
                             dezTemp = Manejador.Tabla.getVariable(ClaseActual, der.getDesplazamiento(), "$"+ClaseActual+"$");
                        }
                        else{
                            dezTemp = Manejador.Tabla.getVariable(ClaseActual, der.getDesplazamiento(), AmbitoActual);
                        }
                        String dezTempPos = Manejador.gen.generarTemporalInt();
                        Manejador.gen.constructordefault.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                        String dezTempVal = Manejador.gen.generarTemporalInt();
                        Manejador.gen.constructordefault.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                        temp1 = Manejador.gen.generarTemporalInt();
                        Manejador.gen.constructordefault.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                        temp2=Manejador.gen.generarTemporalInt();
                        Manejador.gen.constructordefault.append(temp2+" = HEAP ["+temp1+"];\n");
                     }
                     /*
                      * TERMINA VALIDACION PARA ARRAYS
                      * */
                     if(i != (id.length - 1)){
                     tmp=temp2;
                     }else{
                     resultado=temp2;
                     }
                }else{
                     String temp1=Manejador.gen.generarTemporalInt();
                     Manejador.gen.implementaciones.append(temp1+" = "+tmp+" + "+actual.getPosicion()+";\n");
                     String temp2=Manejador.gen.generarTemporalInt();
                     Manejador.gen.implementaciones.append(temp2+" = HEAP ["+temp1+"];\n");
                     /*
                      * INICIA VALIDACION PARA ARRAYS
                      * */
                     if(actual.getTipo().getDimensiones().size()!=0 && !der.getDesplazamiento().equals("") ){
                        Nodo_Metodo_Variable dezTemp = null;
                        if(AmbitoActual.equals("")){
                             dezTemp = Manejador.Tabla.getVariable(ClaseActual, der.getDesplazamiento(), "$"+ClaseActual+"$");
                        }
                        else{
                            dezTemp = Manejador.Tabla.getVariable(ClaseActual, der.getDesplazamiento(), AmbitoActual);
                        }
                        String dezTempPos = Manejador.gen.generarTemporalInt();
                        Manejador.gen.implementaciones.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                        String dezTempVal = Manejador.gen.generarTemporalInt();
                        Manejador.gen.implementaciones.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                        temp1 = Manejador.gen.generarTemporalInt();
                        Manejador.gen.implementaciones.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                        temp2=Manejador.gen.generarTemporalInt();
                        Manejador.gen.implementaciones.append(temp2+" = HEAP ["+temp1+"];\n");
                     }
                     /*
                      * TERMINA VALIDACION PARA ARRAYS
                      * */
                     if(i != (id.length - 1)){
                        tmp=temp2;
                     }else{
                        resultado=temp2;
                     }
                }
            }
            else{
                if(AmbitoActual.equals("")){
                     String temp1=Manejador.gen.generarTemporalInt();
                     Manejador.gen.constructordefault.append(temp1+" = PTR_PILA + "+actual.getPosicion()+";\n");
                     String temp2=Manejador.gen.generarTemporalInt();
                     Manejador.gen.constructordefault.append(temp2+" = PILA ["+temp1+"];\n");
                     /*
                      * INICIA VALIDACION PARA ARRAYS
                      * */
                     if(actual.getTipo().getDimensiones().size()!=0 && !der.getDesplazamiento().equals("") ){
                        Nodo_Metodo_Variable dezTemp = null;
                        if(AmbitoActual.equals("")){
                             dezTemp = Manejador.Tabla.getVariable(ClaseActual, der.getDesplazamiento(), "$"+ClaseActual+"$");
                        }
                        else{
                            dezTemp = Manejador.Tabla.getVariable(ClaseActual, der.getDesplazamiento(), AmbitoActual);
                        }
                        String dezTempPos = Manejador.gen.generarTemporalInt();
                        Manejador.gen.constructordefault.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                        String dezTempVal = Manejador.gen.generarTemporalInt();
                        Manejador.gen.constructordefault.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                        temp1 = Manejador.gen.generarTemporalInt();
                        Manejador.gen.constructordefault.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                        temp2=Manejador.gen.generarTemporalInt();
                        Manejador.gen.constructordefault.append(temp2+" = HEAP ["+temp1+"];\n");
                     }
                     /*
                      * TERMINA VALIDACION PARA ARRAYS
                      * */
                     if(i != (id.length - 1)){
                     tmp=temp2;
                     }else{
                     resultado=temp2;
                     }
                }else{
                     String temp1=Manejador.gen.generarTemporalInt();
                     Manejador.gen.implementaciones.append(temp1+" = PTR_PILA + "+actual.getPosicion()+";\n");
                     String temp2=Manejador.gen.generarTemporalInt();
                     Manejador.gen.implementaciones.append(temp2+" = PILA ["+temp1+"];\n");
                     /*
                      * INICIA VALIDACION PARA ARRAYS
                      * */
                     if(actual.getTipo().getDimensiones().size()!=0 && !der.getDesplazamiento().equals("") ){
                        Nodo_Metodo_Variable dezTemp = null;
                        if(AmbitoActual.equals("")){
                             dezTemp = Manejador.Tabla.getVariable(ClaseActual, der.getDesplazamiento(), "$"+ClaseActual+"$");
                        }
                        else{
                            dezTemp = Manejador.Tabla.getVariable(ClaseActual, der.getDesplazamiento(), AmbitoActual);
                        }
                        String dezTempPos = Manejador.gen.generarTemporalInt();
                        Manejador.gen.implementaciones.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                        String dezTempVal = Manejador.gen.generarTemporalInt();
                        Manejador.gen.implementaciones.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                        temp1 = Manejador.gen.generarTemporalInt();
                        Manejador.gen.implementaciones.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                        temp2=Manejador.gen.generarTemporalInt();
                        Manejador.gen.implementaciones.append(temp2+" = HEAP ["+temp1+"];\n");
                     }
                     /*
                      * TERMINA VALIDACION PARA ARRAYS
                      * */
                     if(i != (id.length - 1)){
                     tmp=temp2;
                     }else{
                     resultado=temp2;
                     }
                }
            }
        }else{
                resultado = id[0];
        }
        }
                              if(AmbitoActual.equals("")){
                                 MetodoActual=(Nodo_Metodo_Variable)Manejador.Tabla.getMetodo(ClaseActual, "$"+ClaseActual+"$", Papel.CONSTRUCTOR, "void");
                                 String temp=Manejador.gen.generarTemporalInt();
                                 Manejador.gen.constructordefault.append(temp+" = PTR_PILA + "+MetodoActual.getTamañoPila()+";\n");
                                 String temp2=Manejador.gen.generarTemporalInt();
                                 Manejador.gen.constructordefault.append(temp2+" = "+temp+" + "+(j+1)+";\n");
                                 Manejador.gen.constructordefault.append("PILA ["+temp2+"] = "+resultado+";\n");

                            }else{
                                 String temp=Manejador.gen.generarTemporalInt();
                                 Manejador.gen.implementaciones.append(temp+" = PTR_PILA + "+MetodoActual.getTamañoPila()+";\n");
                                 String temp2=Manejador.gen.generarTemporalInt();
                                 Manejador.gen.implementaciones.append(temp2+" = "+temp+" + "+(j+1)+";\n");
                                 Manejador.gen.implementaciones.append("PILA ["+temp2+"] = "+resultado+";\n");

                            }
    }
                  listaParams=listaParams.replace("&","_");
                  if(AmbitoActual.equals("")){
                             MetodoActual=(Nodo_Metodo_Variable)Manejador.Tabla.getMetodo(ClaseActual, "$"+ClaseActual+"$", Papel.CONSTRUCTOR, "void");
                             Manejador.gen.constructordefault.append("PTR_PILA = PTR_PILA + "+MetodoActual.getTamañoPila()+";\n");
                             Manejador.gen.constructordefault.append(Clase+"$"+nombreMetodo+"$"+listaParams+"();\n");
                             String temp=Manejador.gen.generarTemporalInt();
                             Nodo_Metodo_Variable $return=null;
                             if(Metodo.getListaArgumentos().equalsIgnoreCase("void")){
                             $return=((Nodo_Metodo_Variable)Manejador.Tabla.getVariable(Clase, "$return", Metodo.getRol()+Metodo.getNombre()));
                             }else{
                             $return=((Nodo_Metodo_Variable)Manejador.Tabla.getVariable(Clase, "$return", Metodo.getRol()+Metodo.getNombre()+"&"+Metodo.getListaArgumentos()));
                             }
                             Manejador.gen.implementaciones.append(temp+" = PTR_PILA + "+$return.getPosicion()+";\n");
                             String temp2=Manejador.gen.generarTemporalInt();
                             Manejador.gen.constructordefault.append(temp2+" = PILA ["+temp+"];\n");
                             Manejador.gen.constructordefault.append("PTR_PILA = PTR_PILA - "+MetodoActual.getTamañoPila()+";\n");

                             int posicion=MetodoActual.getTamañoPila();
                             MetodoActual.setTamañoPila(posicion+1);
                             Manejador.Tabla.AddVariableLocal(ClaseActual, temp2, Papel.VARLOCAL, AmbitoActual, posicion, "int");

                             temp=Manejador.gen.generarTemporalInt();
                             Manejador.gen.constructordefault.append(temp+" = PTR_PILA + "+posicion+";\n");
                             Manejador.gen.constructordefault.append("PILA ["+temp+"] = "+temp2+";\n");

                             RESULT=new MiNodo(temp2, SConstantes.IMPLICITA, SConstantes.LOCAL, Metodo.getTipo());
                        }else{
                             Manejador.gen.implementaciones.append("PTR_PILA = PTR_PILA + "+MetodoActual.getTamañoPila()+";\n");
                             Manejador.gen.implementaciones.append(Clase+"$"+nombreMetodo+"$"+listaParams+"();\n");
                             String temp=Manejador.gen.generarTemporalInt();
                             Nodo_Metodo_Variable $return=null;
                             if(Metodo.getListaArgumentos().equalsIgnoreCase("void")){
                             $return=((Nodo_Metodo_Variable)Manejador.Tabla.getVariable(Clase, "$return", Metodo.getRol()+Metodo.getNombre()));
                             }else{
                             $return=((Nodo_Metodo_Variable)Manejador.Tabla.getVariable(Clase, "$return", Metodo.getRol()+Metodo.getNombre()+"&"+Metodo.getListaArgumentos()));
                             }
                             Manejador.gen.implementaciones.append(temp+" = PTR_PILA + "+$return.getPosicion()+";\n");
                             String temp2=Manejador.gen.generarTemporalInt();
                             Manejador.gen.implementaciones.append(temp2+" = PILA ["+temp+"];\n");
                             Manejador.gen.implementaciones.append("PTR_PILA = PTR_PILA - "+MetodoActual.getTamañoPila()+";\n");

                             int posicion=MetodoActual.getTamañoPila();
                             MetodoActual.setTamañoPila(posicion+1);
                             Manejador.Tabla.AddVariableLocal(ClaseActual, temp2, Papel.VARLOCAL, AmbitoActual, posicion, "int");

                             temp=Manejador.gen.generarTemporalInt();
                             Manejador.gen.implementaciones.append(temp+" = PTR_PILA + "+posicion+";\n");
                             Manejador.gen.implementaciones.append("PILA ["+temp+"] = "+temp2+";\n");

                             RESULT=new MiNodo(temp2, SConstantes.IMPLICITA, SConstantes.LOCAL, Metodo.getTipo());
                        }
    }
	return RESULT;
}

/**
 *
 * @param der
 * @param Clase
 * @param AmbitoActual
 * @return
 */
public String ExpresionDerecho(MiNodo der, String Clase, String AmbitoActual){
    
    String id[]= ((String)der.getCadena()).split("[.]");
    String tmp="", resultado="", Ambito=AmbitoActual, NombreClase=Clase;

if(!der.isExplicita()){
if(!AmbitoActual.equals("")){
if(!id[0].equals("$a")){
    Nodo_Metodo_Variable Var=Manejador.Tabla.ExisteVariableEnClase(NombreClase, id[0], Ambito);
    if(Var.getAmbito().equals("")){
        if(!der.getCadena().toString().startsWith("$t")){
        der.setCadena("$a."+der.getCadena());
        }
    }
}
}else{
    if(!id[0].equals("$a")){
        if(!der.getCadena().toString().startsWith("$t")){
            der.setCadena("$a."+der.getCadena());
        }
    }
}
}
id= ((String)der.getCadena()).split("[.]");
for(int i = 0; i < id.length; i++){
    if(!der.isExplicita()){
        Nodo_Metodo_Variable actual;
        if(!id[i].equals("$a")){
         if((!id[i].startsWith("$t"))){
            actual = Manejador.Tabla.ExisteVariableEnClase(NombreClase, id[i], Ambito);
         }else{
             if(!Ambito.equals("")){
             actual = Manejador.Tabla.ExisteVariableEnClase(NombreClase, id[i], Ambito);
             }else{
             actual = Manejador.Tabla.ExisteVariableEnClase(Clase, id[i], "$"+Clase+"$");
             }
         }
        NombreClase= actual.getTipo().getNombre();
        }else{
        actual = Manejador.Tabla.getVariable(NombreClase, id[i], "$"+NombreClase+"$");
        }
        Ambito = "";
        if(actual.getAmbito().equals("")){
            if(AmbitoActual.equals("")){
                 String temp1=Manejador.gen.generarTemporalInt();
                 Manejador.gen.constructordefault.append(temp1+" = "+tmp+" + "+actual.getPosicion()+";\n");
                 String temp2=Manejador.gen.generarTemporalInt();
                 Manejador.gen.constructordefault.append(temp2+" = HEAP ["+temp1+"];\n");
                 /*
                  * INICIA VALIDACION PARA ARRAYS
                  * */
                 if(actual.getTipo().getDimensiones().size()!=0 && !der.getDesplazamiento().equals("") ){
                    Nodo_Metodo_Variable dezTemp = null;
                    if(AmbitoActual.equals("")){
                         dezTemp = Manejador.Tabla.getVariable(Clase, der.getDesplazamiento(), "$"+Clase+"$");
                    }
                    else{
                        dezTemp = Manejador.Tabla.getVariable(Clase, der.getDesplazamiento(), AmbitoActual);
                    }
                    String dezTempPos = Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                    String dezTempVal = Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                    temp1 = Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp2+" = HEAP ["+temp1+"];\n");
                 }
                 /*
                  * TERMINA VALIDACION PARA ARRAYS
                  * */
                 if(i != (id.length - 1)){
                 tmp=temp2;
                 }else{
                 resultado=temp2;
                 }
            }else{
                 String temp1=Manejador.gen.generarTemporalInt();
                 Manejador.gen.implementaciones.append(temp1+" = "+tmp+" + "+actual.getPosicion()+";\n");
                 String temp2=Manejador.gen.generarTemporalInt();
                 Manejador.gen.implementaciones.append(temp2+" = HEAP ["+temp1+"];\n");
                 /*
                  * INICIA VALIDACION PARA ARRAYS
                  * */
                 if(actual.getTipo().getDimensiones().size()!=0 && !der.getDesplazamiento().equals("") ){
                    Nodo_Metodo_Variable dezTemp = null;
                    if(AmbitoActual.equals("")){
                         dezTemp = Manejador.Tabla.getVariable(Clase, der.getDesplazamiento(), "$"+Clase+"$");
                    }
                    else{
                        dezTemp = Manejador.Tabla.getVariable(Clase, der.getDesplazamiento(), AmbitoActual);
                    }
                    String dezTempPos = Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                    String dezTempVal = Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                    temp1 = Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp2+" = HEAP ["+temp1+"];\n");
                 }
                 /*
                  * TERMINA VALIDACION PARA ARRAYS
                  * */
                 if(i != (id.length - 1)){
                    tmp=temp2;
                 }else{
                    resultado=temp2;
                 }
            }
        }
        else{
            if(AmbitoActual.equals("")){
                 String temp1=Manejador.gen.generarTemporalInt();
                 Manejador.gen.constructordefault.append(temp1+" = PTR_PILA + "+actual.getPosicion()+";\n");
                 String temp2=Manejador.gen.generarTemporalInt();
                 Manejador.gen.constructordefault.append(temp2+" = PILA ["+temp1+"];\n");
                 /*
                  * INICIA VALIDACION PARA ARRAYS
                  * */
                 if(actual.getTipo().getDimensiones().size()!=0 && !der.getDesplazamiento().equals("") ){
                    Nodo_Metodo_Variable dezTemp = null;
                    if(AmbitoActual.equals("")){
                         dezTemp = Manejador.Tabla.getVariable(Clase, der.getDesplazamiento(), "$"+Clase+"$");
                    }
                    else{
                        dezTemp = Manejador.Tabla.getVariable(Clase, der.getDesplazamiento(), AmbitoActual);
                    }
                    String dezTempPos = Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                    String dezTempVal = Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                    temp1 = Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.constructordefault.append(temp2+" = HEAP ["+temp1+"];\n");
                 }
                 /*
                  * TERMINA VALIDACION PARA ARRAYS
                  * */
                 if(i != (id.length - 1)){
                 tmp=temp2;
                 }else{
                 resultado=temp2;
                 }
            }else{
                 String temp1=Manejador.gen.generarTemporalInt();
                 Manejador.gen.implementaciones.append(temp1+" = PTR_PILA + "+actual.getPosicion()+";\n");
                 String temp2=Manejador.gen.generarTemporalInt();
                 Manejador.gen.implementaciones.append(temp2+" = PILA ["+temp1+"];\n");
                 /*
                  * INICIA VALIDACION PARA ARRAYS
                  * */
                 if(actual.getTipo().getDimensiones().size()!=0 && !der.getDesplazamiento().equals("") ){
                    Nodo_Metodo_Variable dezTemp = null;
                    if(AmbitoActual.equals("")){
                         dezTemp = Manejador.Tabla.getVariable(Clase, der.getDesplazamiento(), "$"+Clase+"$");
                    }
                    else{
                        dezTemp = Manejador.Tabla.getVariable(Clase, der.getDesplazamiento(), AmbitoActual);
                    }
                    String dezTempPos = Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(dezTempPos+" = PTR_PILA + "+dezTemp.getPosicion()+";\n");
                    String dezTempVal = Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(dezTempVal+" = PILA ["+dezTempPos+"];\n");
                    temp1 = Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp1+" = "+temp2+" + "+dezTempVal+";\n");
                    temp2=Manejador.gen.generarTemporalInt();
                    Manejador.gen.implementaciones.append(temp2+" = HEAP ["+temp1+"];\n");
                 }
                 /*
                  * TERMINA VALIDACION PARA ARRAYS
                  * */
                 if(i != (id.length - 1)){
                 tmp=temp2;
                 }else{
                 resultado=temp2;
                 }
            }
        }
    }else{
            resultado = id[0];
    }
}
    return resultado;
}

/**
 *
 * @param codigo
 * @param actualETQfalsa
 * @param nuevaETQfalsa
 * @return
 */
public String modificar_ETQfalsa(String codigo, String actualETQfalsa, String nuevaETQfalsa){
        return codigo.replace(actualETQfalsa, nuevaETQfalsa);
}

/**
 *
 * @param codigo
 * @param actualETQverdadera
 * @param nuevaETQverdadera
 * @return
 */
public String modificar_ETQverdadera(String codigo, String actualETQverdadera, String nuevaETQverdadera){
        return codigo.replace(actualETQverdadera, nuevaETQverdadera);
}

/**
 * 
 * @param codigo
 * @param actualETQverdadera
 * @param actualETQfalsa
 * @return
 */
public String modificar_ETQFalasPorVerdaderas(String codigo, String actualETQverdadera, String actualETQfalsa){
        codigo = codigo.replace(actualETQfalsa, "<"+actualETQfalsa+">");
        codigo = codigo.replace(actualETQverdadera, actualETQfalsa);
        codigo = codigo.replace("<"+actualETQfalsa+">", actualETQverdadera);
        return codigo;
    }

}