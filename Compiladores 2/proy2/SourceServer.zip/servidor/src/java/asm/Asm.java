/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package asm;

import java.io.FileReader;

public class Asm {

    Yylex miScanner=null;
    parser miParser=null;

    public Asm(String archivo){
        try{
            miScanner=new Yylex(new FileReader(archivo));
            miParser=new parser(miScanner);
            miParser.parse();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}
