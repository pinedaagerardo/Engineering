package Nodo;

import SymT.Nodo_Tipo;



public class MiNodo {
private int lineaInicio;
private int columnaInicio;
private Object Dato;
public MiNodo() {
}

    public MiNodo(Object Dato, int lineaInicio, int columnaInicio) {
        this.lineaInicio = lineaInicio;
        this.columnaInicio = columnaInicio;
        this.Dato = Dato;
    }

    public Object getDato( ){
        return Dato;

    }
    public int getLinea(){
        return lineaInicio+1;
    }
    public int getColumna(){
        return columnaInicio;
    }
    public void setColumna(int columnaInicio) {
        this.columnaInicio = columnaInicio;
    }

    public void setDato(String dato) {
        this.Dato = dato;
    }

    public void setLinea(int lineaInicio) {
        this.lineaInicio = lineaInicio;
    }

    private Object Cadena;
    private Nodo_Tipo Tipo;
    private boolean Explicita, Global;
    private String Desplazamiento = "", Codigo="";
    private int contador=0;

    public String getCodigo() {
        return Codigo;
    }

    public void setCodigo(String Codigo) {
        this.Codigo = Codigo;
    }

    public int getContador() {
        return contador;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }

    public Nodo_Tipo getTipo() {
        return Tipo;
    }

    public void setTipo(Nodo_Tipo Tipo) {
        this.Tipo = Tipo;
    }

    public MiNodo(Object Cadena, boolean Explicita, boolean Global, Nodo_Tipo Tipo,String Desplazamiento) {
        this.Cadena = Cadena;
        this.Explicita = Explicita;
        this.Global = Global;
        this.Desplazamiento = Desplazamiento;
        this.Tipo=Tipo;
    }

     public MiNodo(Object Cadena, boolean Explicita, boolean Global, Nodo_Tipo Tipo) {
        this.Cadena = Cadena;
        this.Explicita = Explicita;
        this.Global = Global;
        this.Tipo=Tipo;
    }

    public String getDesplazamiento() {
        return Desplazamiento;
    }

    public void setDesplazamiento(String Desplazamiento) {
        this.Desplazamiento = Desplazamiento;
    }

    public Object getCadena() {
        return Cadena;
    }

    public void setCadena(Object Cadena) {
        this.Cadena = Cadena;
    }

    public boolean isExplicita() {
        return Explicita;
    }

    public void setExplicita(boolean Explicita) {
        this.Explicita = Explicita;
    }

    public boolean isGlobal() {
        return Global;
    }

    public void setGlobal(boolean Global) {
        this.Global = Global;
    }
}