public class operacion{
    int a,b;
    public operacion(){
        a=0;
        b=0;
    }

    public int suma(int n1,int n2){
        int x=0;
        x=n1+n2;
        return x;
    }

    public int multiplicacion(int n1, int n2){
        int x=0;
        x=n1*n2;
        return x;
    }

    public void recursivo(){
        println("salir? 1=si, 0=no");
        a=readInt();

        if(a==1) return;
        recursivo();
    }

    public void instancia(int p){
        nodo n=new nodo(p);
        n.setN(n.getN()-2);
        int r=suma(n.getN,b+5);
        print("suma: ");
        println(r);
    }
}