public class nodo{
    int n=0;
    public nodo(int num){
        n=num;
    }

    public void setN(int num){
        n=num;
    }

    public int getN(){
        return n;
    }
}