public class prueba{

    public static void main(String arg[]){
        operacion op=new operacion();
        int s=op.suma(4,7);
        print("(main) suma: ");
        println(s);
        int m=op.multiplicacion(s,9);
        print("(main) multiplicacion: ");
        println(m);
        println("-------------------");
        op.instancia(3);
        println("-------------------");
        op.recursivo();
        println("-------------------");
        println("presione enter:");
        int salida=readInt();
    }
}