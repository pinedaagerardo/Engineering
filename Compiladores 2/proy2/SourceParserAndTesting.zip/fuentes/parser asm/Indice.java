/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package maquinavirtual;

/**
 *
 * @author g
 */
public interface Indice {

    public final int cantidadRegistros=34;
    /*registros*/
    public final int AL=0;
    public final int AH=1;
    public final int AX=2;

    public final int BL=3;
    public final int BH=4;
    public final int BX=5;

    public final int CL=6;
    public final int CH=7;
    public final int CX=8;

    public final int DL=9;
    public final int DH=10;
    public final int DX=11;

    public final int SI=12;
    public final int DI=13;
    public final int BP=14;
    public final int SP=15;
    public final int IP=16;

    public final int CS=17;
    public final int DS=18;
    public final int ES=19;
    public final int SS=20;

    public final int CF=21;
    public final int PF=22;
    public final int AF=23;
    public final int ZF=24;
    public final int SF=25;
    public final int TF=26;
    public final int IF=27;
    public final int DF=28;
    public final int OF=29;
    public final int IOPL=30;
    public final int NT=31;
    public final int RF=32;
    public final int VM=33;

    /*metodos*/
    public final int MOV=34;
    public final int ADD=35;
    public final int SUB=36;
    public final int IMUL=37;
    public final int IDIV=38;
    public final int PUSH=39;
    public final int POP=40;
    public final int CALL=41;
    public final int JMP=42;
    public final int CMP=43;
    public final int JL=44;
    public final int JG=45;
    public final int JLE=46;
    public final int JGE=47;
    public final int JE=48;
    public final int JNE=49;
    public final int PUTC=50;
}
