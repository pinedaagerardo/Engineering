/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * Consola.java
 *
 * Created on 10/11/2009, 02:41:52 PM
 */

package maquinavirtual;

import java.awt.FileDialog;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.util.Vector;

/**
 *
 * @author g
 */
public class Consola extends javax.swing.JFrame {

    public static Object registro[]=new Object[Indice.cantidadRegistros];//almacena los registros usados en asm
    public static Vector stack=new Vector();//pila de la maquina virtual
    public static Vector tabla=new Vector();//tabla de simbolos
    public static String archivo="";//nombre del archivo a interpretar
    public static boolean continuar=true;//bandera que se usa para terminar la compilacion de un archivo
    /** Creates new form Consola */
    public Consola() {
        initComponents();
        /**System.out.println(Integer.parseInt("a", 16));//toDec
        System.out.println(Integer.toHexString(10));//toHex
        BufferedReader b=new BufferedReader(new InputStreamReader(System.in));
        try {
            String s = ""+b.read();
            System.out.println(s);
        } catch (Exception ex) {
            System.out.println("Error leer");
        }
        System.exit(0);//*/

        registro[Indice.AL]=registro[Indice.BL]=registro[Indice.CL]=registro[Indice.DL]="00";
        registro[Indice.AH]=registro[Indice.BH]=registro[Indice.CH]=registro[Indice.DH]="00";
        registro[Indice.SI]=registro[Indice.DI]=registro[Indice.BP]=registro[Indice.SP]=registro[Indice.IP]="0000";
        registro[Indice.CS]=registro[Indice.DS]=registro[Indice.ES]=registro[Indice.SS]="0000";
        registro[Indice.CF]=registro[Indice.PF]=registro[Indice.AF]=registro[Indice.ZF]=registro[Indice.SF]=
                registro[Indice.TF]=registro[Indice.IF]=registro[Indice.DF]=registro[Indice.OF]=registro[Indice.IOPL]=
                registro[Indice.NT]=registro[Indice.RF]=registro[Indice.VM]="0";
        refrescar();
    }

    /**
     * lee el texto linea por linea y manda cada una por separado al parser.
     * si la bandera es true, el metodo busca en el archivo la etiqueta recibida
     * como parametro y comienza a interpretar desde ese punto
     * @param archivo nombre del archivo a compilar
     * @param etiqueta etiqueta a buscar si esta activada la bandera jmp
     * @param jmp bandera que dice si se debe buscar una etiqueta (true) o no (false)
     */
    public static void parsear(String archivo,String etiqueta,Boolean jmp){
        String linea="";
        continuar=true;
        try {
            BufferedReader input = new BufferedReader(new FileReader(archivo));
            while(jmp && (linea=input.readLine())!=null){
                if(linea.equals(etiqueta+":") || linea.equals("proc "+etiqueta))//buscando etiqueta/proc
                    jmp=false;
            }
            while(continuar && !(linea=input.readLine()).equals("ret")){
                //mandar linea al parser para que se llame una instruccion en las acciones semanticas (parser de asm)
            }
        } catch (Exception ex) {
            System.out.println("ASM: Error de lectura");
        }
    }

    /**
     * solo usar en constructor, las variables se van a usar como dw por el momento
     * o sea, ax,bx, etc
     */
    protected void refrescar(){
        registro[Indice.AX]=registro[Indice.AH].toString()+registro[Indice.AL].toString();
        registro[Indice.BX]=registro[Indice.BH].toString()+registro[Indice.BL].toString();
        registro[Indice.CX]=registro[Indice.CH].toString()+registro[Indice.CL].toString();
        registro[Indice.DX]=registro[Indice.DH].toString()+registro[Indice.DL].toString();
    }

    /**
     * copia
     * @param p1
     * @param p2
     */
    public static void MOV(String p1,String p2){
        int a=convertir(p1);//p1 puede ser variable o registro
        int b=convertir(p2);//p2 puede ser variable, registro o numero
        if(b==-1){//p2 no es registro, es variable o numero
            int ip2=getIndice(p2);
            if(ip2==-1){//p2 no es variable, es un numero
                if(a==-1){//p1 es variable
                    int ip1=getIndice(p1);
                    setValor(ip1, p2);
                }else{//p1 es registro
                    registro[a]=p2;
                }
            }else{ //p2 es variable
                Object o=getValor(ip2);
                if(a==-1){//p1 es variable
                    int ip1=getIndice(p1);
                    setValor(ip1, o);
                }else{//p1 es registro
                    registro[a]=o;
                }
            }
        }else{//p2 es registro
            if(a==-1){//p1 es variable
                int ip1=getIndice(p1);
                setValor(ip1, registro[b]);
            }else{//p1 es registro
                registro[a]=registro[b];
            }
        }
    }

    /**
     * suma
     * @param p1
     * @param p2
     */
    public static void ADD(String p1,String p2){
        //solo puede venir add ax,num o add ax,var
        int a=convertir(p1);
        int b=convertir(p2);
        if(b==-1){//p2 es numero o variable
            int ip2=getIndice(p2);
            if(ip2==-1){//p2 no es variable, es un numero
                int tmp=Integer.valueOf(registro[a].toString());
                tmp=tmp+Integer.valueOf(p2);
                registro[a]=tmp;
            }else{ //p2 es variable
                Object o=getValor(ip2);
                int tmp=Integer.valueOf(registro[a].toString());
                tmp=tmp+Integer.valueOf(o.toString());
                registro[a]=tmp;
            }
        }
    }

    /**
     * resta
     * @param p1
     * @param p2
     */
    public static void SUB(String p1,String p2){
        //solo puede venir add ax,num o add ax,var
        int a=convertir(p1);
        int b=convertir(p2);
        if(b==-1){//p2 es numero o variable
            int ip2=getIndice(p2);
            if(ip2==-1){//p2 no es variable, es un numero
                int tmp=Integer.valueOf(registro[a].toString());
                tmp=tmp-Integer.valueOf(p2);
                registro[a]=tmp;
            }else{ //p2 es variable
                Object o=getValor(ip2);
                int tmp=Integer.valueOf(registro[a].toString());
                tmp=tmp-Integer.valueOf(o.toString());
                registro[a]=tmp;
            }
        }
    }

    /**
     * multiplica
     * @param p1
     * @param p2
     */
    public static void IMUL(String p1){
        //solo puede ser imul registro o imul temporal
        int a=convertir(p1);
        if(a==-1){//es temporal
            int ip1=getIndice(p1);
            Object o=getValor(ip1);
            int tmp=Integer.valueOf(registro[Indice.AX].toString());
            tmp=tmp*Integer.valueOf(o.toString());
            registro[Indice.AX]=tmp;
        }else{//es registro
            int tmp=Integer.valueOf(registro[Indice.AX].toString());
            tmp=tmp*Integer.valueOf(registro[a].toString());
            registro[Indice.AX]=tmp;
        }
    }

    /**
     * divide
     * @param p1
     */
    public static void IDIV(String p1){
        //solo puede ser idiv registro o idiv temporal
        int a=convertir(p1);
        if(a==-1){//es temporal
            int ip1=getIndice(p1);
            Object o=getValor(ip1);
            int tmp=Integer.valueOf(registro[Indice.AX].toString());
            tmp=tmp/Integer.valueOf(o.toString());
            registro[Indice.AX]=tmp;
        }else{//es registro
            int tmp=Integer.valueOf(registro[Indice.AX].toString());
            tmp=tmp/Integer.valueOf(registro[a].toString());
            registro[Indice.AX]=tmp;
        }
    }

    /**
     * meter en pila
     * @param p1
     */
    public static void PUSH(String p1){
        //solo puede ser push registro
        int a=convertir(p1);
        stack.add(registro[a]);
    }

    /**
     * saca de la pila y copia
     * @param p1
     */
    public static void POP(String p1){
        //solo puede ser pop registro
        int a=convertir(p1);
        int tmp=stack.size()-1;
        registro[a]=stack.remove(tmp);
    }

    /**
     * llama funcion
     * @param p1
     */
    public static void CALL(String p1){
        parsear(archivo, p1, true);
    }

    /**
     * salto de linea
     * @param p1
     */
    public static void JMP(String p1){
        parsear(archivo, p1, true);
        continuar=false;
    }

    /**
     * compara y asigna valores a banderas
     * @param p1
     * @param p2
     */
    public static void CMP(String p1,String p2){
        //solo puede ser cmp dx,temporal o cmp dx,numero
        //ej: cmp 0,1 -> flags: zf=0, cf=0;
        //ej2: cmp 1,0 -> flags: zf=0, cf=1;
        //ej3: cmp 1,1 -> flags: zf=1, cf=0;
        int ip2=getIndice(p2);
        int res=0;
        if(ip2==-1){//p2 no es variable, es un numero
            int tmp_p1=Integer.valueOf(registro[Indice.DX].toString());
            int tmp_p2=Integer.valueOf(p2);
            res=tmp_p1-tmp_p2;
        }else{ //p2 es variable
            Object o=getValor(ip2);
            int tmp_p1=Integer.valueOf(registro[Indice.DX].toString());
            int tmp_p2=Integer.valueOf(o.toString());
            res=tmp_p1-tmp_p2;
        }
        if(res==0){
            registro[Indice.ZF]=1;
            registro[Indice.CF]=0;
        }else{
            if(res<0){
                registro[Indice.ZF]=0;
                registro[Indice.CF]=0;
            }else{
                registro[Indice.ZF]=0;
                registro[Indice.CF]=1;
            }
        }
    }

    /**
     * jump if lower
     * @param p1
     */
    public static void JL(String p1){
        int zf=Integer.valueOf(registro[Indice.ZF].toString());
        int cf=Integer.valueOf(registro[Indice.CF].toString());
        if(zf==0 && cf==0)
            JMP(p1);
    }

    /**
     * jump if greater
     * @param p1
     */
    public static void JG(String p1){
        int zf=Integer.valueOf(registro[Indice.ZF].toString());
        int cf=Integer.valueOf(registro[Indice.CF].toString());
        if(zf==0 && cf==1)
            JMP(p1);
    }

    /**
     * jump if lower or equal
     * @param p1
     */
    public static void JLE(String p1){
        int zf=Integer.valueOf(registro[Indice.ZF].toString());
        int cf=Integer.valueOf(registro[Indice.CF].toString());
        if(cf==0)
            JMP(p1);
    }

    /**
     * jump if greater or equal
     * @param p1
     */
    public static void JGE(String p1){
        int zf=Integer.valueOf(registro[Indice.ZF].toString());
        int cf=Integer.valueOf(registro[Indice.CF].toString());
        if(zf==1 || cf==1)
            JMP(p1);
    }

    /**
     * jump if equal
     * @param p1
     */
    public static void JE(String p1){
        int zf=Integer.valueOf(registro[Indice.ZF].toString());
        int cf=Integer.valueOf(registro[Indice.CF].toString());
        if(zf==1)
            JMP(p1);
    }

    /**
     * jump if not equal
     * @param p1
     */
    public static void JNE(String p1){
        int zf=Integer.valueOf(registro[Indice.ZF].toString());
        int cf=Integer.valueOf(registro[Indice.CF].toString());
        if(zf==0)
            JMP(p1);
    }

    /**
     * imprime en la consola del interprete el valor correspondiente al codigo
     * ascii recibido como parametro
     * @param p1
     */
    public static void PUTC(String p1){
        int i=Integer.valueOf(p1);
        char letra=(char)i;
        System.out.println(letra);
    }

    /**
     * imprime el numero contenido en ax
     */
    public static void print_num(){
        System.out.println(""+registro[Indice.AX]);
    }

    /**
     * pide un numero y lo mete en cx
     */
    public static void scan_num(){
        BufferedReader input=new BufferedReader(new InputStreamReader(System.in));
        String s="";
        try{
            s=input.readLine();
        }catch(Exception e){
            System.out.println("ASM: error con System.in");
        }
        registro[Indice.CX]=s;
    }

    /**
     * espera que se presione la tecla enter para continuar
     */
    public static void waitEnterKey(){
        BufferedReader input=new BufferedReader(new InputStreamReader(System.in));
        try{
            input.readLine();
        }catch(Exception e){
            System.out.println("ASM: error con System.in");
        }
    }

    /**
     * complementa a 4 digitos el string recibido si lo necesita (no se usa por ahora)
     * @param s
     * @return
     */
    public String rellenar(String s){
        int len=s.length();
        for(int i=len;i<4;i++)
            s="0"+s;
        return s;
    }

    /**
     * ejecuta un metodo de acuerdo a los parametros recibidos. si no necesita de algun parametro
     * se debe enviar como un string vacio
     * @param metodo nombre del metodo a llamar
     * @param p1 parametro 1 del metodo
     * @param p2 parametro 2 del metodo
     */
    public static void ejecutar(String metodo,String param1,String param2){
        int m=convertir(metodo);
        if(param1.endsWith("[di]")){
            String di=registro[Indice.DI].toString();
            param1=param1.substring(0, 4)+"["+di+"]";
        }
        if(param2.equals("[di]")){
            String di=registro[Indice.DI].toString();
            param2=param2.substring(0, 4)+"["+di+"]";
        }
        switch(m){
            case 34:
                MOV(param1,param2);
                break;
            case 35:
                ADD(param1,param2);
                break;
            case 36:
                SUB(param1,param2);
                break;
            case 37:
                IMUL(param1);
                break;
            case 38:
                IDIV(param1);
                break;
            case 39:
                PUSH(param1);
                break;
            case 40:
                POP(param1);
                break;
            case 41:
                CALL(param1);
                break;
            case 42:
                JMP(param1);
                break;
            case 43:
                CMP(param1,param2);
                break;
            case 44:
                JL(param1);
                break;
            case 45:
                JG(param1);
                break;
            case 46:
                JLE(param1);
                break;
            case 47:
                JGE(param1);
                break;
            case 48:
                JE(param1);
                break;
            case 49:
                JNE(param1);
                break;
            case 50:
                PUTC(param1);
                break;
        }
    }

    /**
     * retorna el integer correspondiente al string recibido
     * @param s string a identificar
     * @return un numero que simboliza el parametro recibido
     */
    protected  static int convertir(String s){
        if(s.equalsIgnoreCase("al")) return Indice.AL;
        else if(s.equalsIgnoreCase("ah")) return Indice.AH;
        else if(s.equalsIgnoreCase("ax")) return Indice.AX;
        else if(s.equalsIgnoreCase("bl")) return Indice.BL;
        else if(s.equalsIgnoreCase("bh")) return Indice.BH;
        else if(s.equalsIgnoreCase("bx")) return Indice.BX;
        else if(s.equalsIgnoreCase("cl")) return Indice.CL;
        else if(s.equalsIgnoreCase("ch")) return Indice.CH;
        else if(s.equalsIgnoreCase("cx")) return Indice.CX;
        else if(s.equalsIgnoreCase("dl")) return Indice.DL;
        else if(s.equalsIgnoreCase("dh")) return Indice.DH;
        else if(s.equalsIgnoreCase("dx")) return Indice.DX;
        else if(s.equalsIgnoreCase("si")) return Indice.SI;
        else if(s.equalsIgnoreCase("di")) return Indice.DI;
        else if(s.equalsIgnoreCase("bp")) return Indice.BP;
        else if(s.equalsIgnoreCase("sp")) return Indice.SP;
        else if(s.equalsIgnoreCase("ip")) return Indice.IP;
        else if(s.equalsIgnoreCase("cs")) return Indice.CS;
        else if(s.equalsIgnoreCase("ds")) return Indice.DS;
        else if(s.equalsIgnoreCase("es")) return Indice.ES;
        else if(s.equalsIgnoreCase("ss")) return Indice.SS;
        else if(s.equalsIgnoreCase("cf")) return Indice.CF;
        else if(s.equalsIgnoreCase("pf")) return Indice.PF;
        else if(s.equalsIgnoreCase("af")) return Indice.AF;
        else if(s.equalsIgnoreCase("zf")) return Indice.ZF;
        else if(s.equalsIgnoreCase("sf")) return Indice.SF;
        else if(s.equalsIgnoreCase("tf")) return Indice.TF;
        else if(s.equalsIgnoreCase("if")) return Indice.IF;
        else if(s.equalsIgnoreCase("df")) return Indice.DF;
        else if(s.equalsIgnoreCase("of")) return Indice.OF;
        else if(s.equalsIgnoreCase("iopl")) return Indice.IOPL;
        else if(s.equalsIgnoreCase("nt")) return Indice.NT;
        else if(s.equalsIgnoreCase("rf")) return Indice.RF;
        else if(s.equalsIgnoreCase("vm")) return Indice.VM;

        else if(s.equalsIgnoreCase("mov")) return Indice.MOV;
        else if(s.equalsIgnoreCase("add")) return Indice.ADD;
        else if(s.equalsIgnoreCase("sub")) return Indice.SUB;
        else if(s.equalsIgnoreCase("imul")) return Indice.IMUL;
        else if(s.equalsIgnoreCase("idiv")) return Indice.IDIV;
        else if(s.equalsIgnoreCase("push")) return Indice.PUSH;
        else if(s.equalsIgnoreCase("pop")) return Indice.POP;
        else if(s.equalsIgnoreCase("call")) return Indice.CALL;
        else if(s.equalsIgnoreCase("cmp")) return Indice.CMP;
        else if(s.equalsIgnoreCase("jmp")) return Indice.JMP;
        else if(s.equalsIgnoreCase("jl")) return Indice.JL;
        else if(s.equalsIgnoreCase("jg")) return Indice.JG;
        else if(s.equalsIgnoreCase("jle")) return Indice.JLE;
        else if(s.equalsIgnoreCase("jge")) return Indice.JGE;
        else if(s.equalsIgnoreCase("je")) return Indice.JE;
        else if(s.equalsIgnoreCase("jne")) return Indice.JNE;
        else if(s.equalsIgnoreCase("putc")) return Indice.PUTC;
        else return -1;
    }

    /**
     * agrega una variable a la tabla de simbolos. si no tiene valor se debe mandar
     * un string vacio en el parametro
     * @param nombre nombre de variable
     * @param valor valor de variable
     */
    public static void agregarVar(Object nombre,Object valor){
         Object o[]=new Object[2];
         o[0]=nombre;
         o[1]=valor;
         tabla.add(o);
    }

    /**
     * retorna el indice de una variable en la tabla de simbolos
     * @param var nombre de var
     * @return el indice de la variable si existe, si no existe -1
     */
    public static int getIndice(String var){
        for(int i=0;i<tabla.size();i++){
            Object o[]=(Object[])tabla.elementAt(i);
            if(o[0].equals(var))
                return i;
        }
        return -1;
    }

    /**
     * retorna el valor de una variable
     * @param indice posicion de la variable en la tabla de simbolos
     * @return el valor de la variable
     */
    public static Object getValor(int indice){
        Object o[]=(Object[])tabla.elementAt(indice);
        return o[1];
    }

    /**
     * modifica el valor de una variable
     * @param indice indice de la variable en la tabla de simbolos
     * @param valor nuevo valor
     */
    public static void setValor(int indice,Object valor){
        Object o[]=(Object[])tabla.elementAt(indice);
        o[1]=new String(valor.toString());
        tabla.setElementAt(o, indice);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        texto = new javax.swing.JTextArea();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        texto.setColumns(20);
        texto.setRows(5);
        jScrollPane1.setViewportView(texto);

        jMenu1.setText("File");

        jMenuItem1.setText("Abrir");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 571, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 283, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        try{
            FileDialog dlg=new FileDialog(this,"Abrir",FileDialog.LOAD);
            dlg.setVisible(true);
            String archivotmp=dlg.getFile();
            if(archivotmp==null) return;
            if(archivotmp.toLowerCase().endsWith(".asm")){
                archivo=archivotmp;
                this.parsear(archivotmp,"",false);
            }
        }catch(Exception e){
            System.out.println("ASM: Error al abrir el archivo");
        }
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    /**
    * @param args the command line arguments
    */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Consola().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea texto;
    // End of variables declaration//GEN-END:variables

}
