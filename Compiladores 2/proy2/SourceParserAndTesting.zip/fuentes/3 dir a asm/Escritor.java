/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package asm;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;

/**
 * realiza todas las acciones relacionadas con los archivos
 * @author g
 */
public class Escritor {

    PrintWriter escritor;

    /**
     * constructor. si el archivo a crear ya existe, es reemplazado por uno nuevo, vacio.
     * @param archivo ruta absoluta del archivo que se va a escribir
     */
    public Escritor(String archivo){
        File f=new File(archivo);
        if(f.exists()) f.delete();

        try {
            escritor = new PrintWriter(new FileWriter(archivo));
            escribirLinea("name \"asm\"");
            escribirLinea("include \"emu8086.inc\"");
            escribirLinea("org 100h");
            escribirLinea("jmp start");
            escribirLinea("define_scan_num");
            escribirLinea("define_print_string");
            escribirLinea("define_print_num");
            escribirLinea("define_print_num_uns");
        } catch (Exception ex) {
            System.out.println("Error al abrir el archivo "+archivo);
        }
    }

    /**
     * imprime el contenido del StringBuffer
     * @param sb
     */
    public void escribir(StringBuffer sb){
        String linea=sb.toString();
        String s[]=linea.split("\n");
        for(int i=0;i<s.length;i++)
            escritor.println(s[i]);
    }

    /**
     * escribe un texto al archivo en la posicion actual
     * @param texto texto a escribir
     */
    public void escribir(String texto){
        escritor.print(texto);
    }

    /**
     * escribe una linea en la posicion actual del archivo seguido de '\n'
     * @param linea linea a escribir
     */
    public void escribirLinea(String linea){
        escritor.println(linea);
    }

    /**
     * cierra el flujo. Es nesecario hacer esto para que se guarden los cambios al archivo
     */
    public void cerrar(){
        escritor.close();
    }
}
