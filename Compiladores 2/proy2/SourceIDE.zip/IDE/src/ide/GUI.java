
package ide;


/**
 *  <p style="margin-top: 0">
 *          realiza las funciones necesarias para el funcionamiento de la interfaz 
 *          grafica
 *        </p>
 */
// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.5CEAABC9-C399-23B6-6600-1152FEF7A833]
// </editor-fold> 
public class GUI {

    /**
     *  <p style="margin-top: 0">
     *              tabla de simbolos de las clases compiladas
     *            </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.3BC350B9-EF79-2182-129A-0F7FEFDA8757]
    // </editor-fold> 
    public static TablaSimbolos tabla;

    /**
     *  <p style="margin-top: 0">
     *              nombre del proyecto
     *            </p>
     */
    public String proyecto;

    /**
     *  <p style="margin-top: 0">
     *              constructor
     *            </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.ED501845-88CC-C26F-130F-EBCCB9FDC663]
    // </editor-fold> 
    public GUI () {
    }

    /**
     *  <p style="margin-top: 0">
     *              crea un nuevo proyecto
     *            </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.5283118C-2FE2-C6CE-32DE-BFFCB86CD191]
    // </editor-fold> 
    public void nuevo () {
    }

    /**
     *  <p style="margin-top: 0">
     *              abre un proyecto existente
     *            </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.4275EF1D-6C63-591B-F5DD-054CFC01E807]
    // </editor-fold> 
    public void abrir () {
    }

    /**
     *  <p style="margin-top: 0">
     *              guarda un proyecto
     *            </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.1D092D04-0941-69F9-98D6-D8D1F18F78AB]
    // </editor-fold> 
    public void guardar () {
    }

    /**
     *  <p style="margin-top: 0">
     *              crea una nueva clase
     *            </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.F476C526-777E-D4CA-E66E-12693C8D17FB]
    // </editor-fold> 
    public void nuevoArchivo () {
    }

    /**
     *  <p style="margin-top: 0">
     *              cierra el archivo actual
     *            </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.0B82A173-2CEE-F137-0248-D2F24304A34E]
    // </editor-fold> 
    public void cerrarArchivo () {
    }

    /**
     *  <p style="margin-top: 0">
     *              cierra un proyecto
     *            </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.590F10D1-C947-CDFE-20B5-2DC9B8B6CDAA]
    // </editor-fold> 
    public void cerrar () {
    }

    /**
     *  <p style="margin-top: 0">
     *              resalta los errores en el editor
     *            </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.B1FF3AB2-4F86-5B1E-D66C-56CE311D7555]
    // </editor-fold> 
    public void mostrarErrores () {
    }

    /**
     *  <p style="margin-top: 0">
     *              compila un proyecto
     *            </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.B6FC5A43-C676-46CE-7B44-28F9C3D5E896]
    // </editor-fold> 
    public void compilar () {
    }

    /**
     *  <p style="margin-top: 0">
     *              abre un archivo existente
     *            </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.1F06D9E6-666D-5F0A-2FA5-150C56F81161]
    // </editor-fold> 
    public void abrirArchivo () {
    }

    /**
     *  <p style="margin-top: 0">
     *              guarda el archivo actual
     *            </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.4299719D-9DA0-BD95-1BFF-C148970F486A]
    // </editor-fold> 
    public void guardarArchivo () {
    }

}

