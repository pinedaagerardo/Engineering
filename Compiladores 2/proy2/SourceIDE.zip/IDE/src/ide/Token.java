
package ide;


/**
 *  <p style="margin-top: 0">
 *          contiene la informacion de un token del compilador
 *        </p>
 */
// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.DE67F5F6-92A6-A9B4-C928-807EC97E4CA3]
// </editor-fold> 
public class Token {

    /**
     *  <p style="margin-top: 0">
     *              columna del token en el documento fuente
     *            </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.DCC2D128-E5C0-489F-D222-2DAB8DA3DB2C]
    // </editor-fold> 
    private int columna;

    /**
     *  <p style="margin-top: 0">
     *              linea del token en el documento fuente
     *            </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.A93FB8DF-B1ED-A9AB-C684-2232481D7FCA]
    // </editor-fold> 
    private int linea;

    /**
     *  <p style="margin-top: 0">
     *              valor del token en el documento fuente
     *            </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.D4411F5D-EDCA-EDCA-68F0-6F1401A6C504]
    // </editor-fold> 
    private String dato;

    /**
     *  <p style="margin-top: 0">
     *              constructor
     *            </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.415ECBDC-6973-D825-45F7-C08769F3D050]
    // </editor-fold> 
    public Token (int col, int line, String data) {
        columna=col;
        linea=line;
        dato=data;
    }

    /**
     *  <p style="margin-top: 0">
     *              devuelve la columna del token en el documento fuente
     *            </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.097A129C-992D-2D6F-B98E-312356969DBC]
    // </editor-fold> 
    public int getColumna () {
        return columna;
    }

    /**
     *  <p style="margin-top: 0">
     *              establece la columna del token en el documento fuente
     *            </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.8E7F6952-E6DC-565D-57FE-3BF0C38252E6]
    // </editor-fold> 
    public void setColumna (int val) {
        columna=val;
    }

    /**
     *  <p style="margin-top: 0">
     *              devuelve el valor del token en el documento fuente
     *            </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.C0AF1D8B-8D11-D889-DA7C-3114D0B63E11]
    // </editor-fold> 
    public String getDato () {
        return dato;
    }

    /**
     *  <p style="margin-top: 0">
     *              asigna el valor del token en el documento fuente
     *            </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.F7EE1072-713A-13D1-BB09-892672FD9970]
    // </editor-fold> 
    public void setDato (String val) {
        dato=val;
    }

    /**
     *  <p style="margin-top: 0">
     *              devuelve la linea del token en el documento fuente
     *            </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.30CA6B57-7F25-5911-E3DD-E462EA135CC7]
    // </editor-fold> 
    public int getLinea () {
        return linea;
    }

    /**
     *  <p style="margin-top: 0">
     *        establece la linea del token en el documento fuente
     *      </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.459C264A-BDAB-C8A4-999B-DF737D23D128]
    // </editor-fold> 
    public void setLinea (int val) {
        linea=val;
    }

}

