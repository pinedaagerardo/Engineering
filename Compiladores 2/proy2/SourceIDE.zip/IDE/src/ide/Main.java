/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ide;

/**
 *
 * @author g
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GUI_frame ventana=new GUI_frame();
        ventana.setVisible(true);
    }

}
