
package ide;

import java.util.Vector;


/**
 *  <p style="margin-top: 0">
 *        compila una clase en lenguaje java
 *      </p>
 */
// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.0444E31D-0C83-8A92-7259-831199A49B57]
// </editor-fold> 
public class ParserJava {

    /**
     *  <p style="margin-top: 0">
     *        contiene los errores semanticos ocurridos durante la compilacion
     *      </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.32D4E5F5-877B-6702-0BA3-0FE5201492B9]
    // </editor-fold> 
    private Vector errores;

    /**
     *  <p style="margin-top: 0">
     *        constructor
     *      </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.D77882F6-775F-96B8-978C-63869F843EA3]
    // </editor-fold> 
    public ParserJava () {
    }

    /**
     *  <p style="margin-top: 0">
     *        devuelve un Vector con los errores
     *      </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.18A6782C-614A-BF83-9C00-3C0A74BC0535]
    // </editor-fold> 
    public Vector getErrores () {
        return errores;
    }

}

