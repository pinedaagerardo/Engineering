package ide;


/**
 *  <p style="margin-top: 0">
 *          posee atributos que representan una posicion de un tipo o atributo en la 
 *          tabla de simbolos
 *        </p>
 */
// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.A6A6B1C4-2B96-C37C-8AF9-EC2B2E481B78]
// </editor-fold> 
public interface Posiciones {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.E3AF3DE4-C276-D6EA-622B-3FB1DB73FB76]
    // </editor-fold> 
    public static final int INT = 0;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.6ADC77C1-C297-CB90-FCAD-A877C7509AB4]
    // </editor-fold> 
    public static final int LONG = 1;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.C5B00DC7-FEB1-5503-9720-DB8E80126E5E]
    // </editor-fold> 
    public static final int STRING = 2;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.01826108-5933-150F-0953-5038F319FE03]
    // </editor-fold> 
    public static final int CHAR = 3;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.0CB03D1D-EBAE-E21C-01E0-B022EB7B73C2]
    // </editor-fold> 
    public static final int FLOAT = 4;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.11AA05AE-D001-38C9-1DA2-8A8C1CAC61E5]
    // </editor-fold> 
    public static final int DOUBLE = 5;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.F869C4B9-EBE4-5D47-EAFB-CAED58502467]
    // </editor-fold> 
    public static final int VOID = 6;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.33E5FF75-92C9-D1D1-751D-8085CAB0FB09]
    // </editor-fold> 
    public static final int VB = 7;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.C7ABB925-BDDD-21B1-8BA4-EAF28078C799]
    // </editor-fold> 
    public static final int JAVA = 8;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.2484F7F2-C872-1CA0-0333-98DF46163082]
    // </editor-fold> 
    public static final int CPP = 9;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.AC8D628C-0F0C-F932-3B26-BAEBF5599034]
    // </editor-fold> 
    public static final int PYTHON = 10;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.6FC040B9-65D9-E1E2-DF8C-71AE6CF7B4EC]
    // </editor-fold> 
    public static final int OBJECT = 11;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.D58C4D56-5883-58A7-8C78-41904DB6B705]
    // </editor-fold> 
    public static final int EXISTE = 0;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.845E86A0-1093-EDAF-CFAA-A8F87C494A98]
    // </editor-fold> 
    public static final int NOMBRE = 1;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.684D2603-C8C3-1BA4-6374-A01EA0A8D22E]
    // </editor-fold> 
    public static final int VISIBILIDAD = 2;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.926D0BFA-384C-1A49-D46A-9D2F83D2667D]
    // </editor-fold> 
    public static final int ESGLOBAL = 3;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.912590D2-F514-90DD-9DB1-5D030F42E59E]
    // </editor-fold> 
    public static final int CLASE = 4;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.CB6AABD9-CBC7-E4DE-5510-40211394360B]
    // </editor-fold> 
    public static final int AMBITO = 5;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.987FDF43-DFAF-BB09-A2AF-8E2A6702C484]
    // </editor-fold> 
    public static final int POSICION = 6;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.744746D5-EA88-5AF8-F442-BBE12A86CFF1]
    // </editor-fold> 
    public static final int IMPORTS = 7;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker ">
    // #[regen=yes,id=DCE.D4487279-C4D4-74F0-9A08-75B7EAEFB5C3]
    // </editor-fold>
    public static final int PARAMS = 8;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker ">
    // #[regen=yes,id=DCE.8F4E5E57-0815-6905-7D57-0DDD9DE8136C]
    // </editor-fold>
    public static final int VALOR = 9;

}

