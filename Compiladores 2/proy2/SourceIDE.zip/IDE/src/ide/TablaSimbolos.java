
package ide;

import java.util.Vector;


/**
 *  <p style="margin-top: 0" align="left">
 *                tabla de simbolos usada por los compiladores
 *              </p>
 */
// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.850A86BB-0CDB-CFA9-E944-BA2194E44DE9]
// </editor-fold> 
public class TablaSimbolos {

    /**
     *  <p align="left" style="margin-top: 0">
     *                          ultima posicion actualmente en el Vector de tipos de datos
     *                        </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.76F7E08D-D444-BE51-3BB1-D8718D7F9AA3]
    // </editor-fold> 
    private int tipoFin = 11;

    /**
     *  <p align="left" style="margin-top: 0">
     *                          posicion final del array de los atributos
     *                        </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.E9C7C31C-0A94-74BD-C6C5-2975092A9DAD]
    // </editor-fold> 
    private final int atribFin = 9;

    /**
     *  <p style="margin-top: 0">
     *                      nombre de la clase a la que pertenece la informacion que contiene
     *                        </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.7F6E925E-5DC2-DE09-216D-3BCEEFCC50C9]
    // </editor-fold> 
    public String clase;

    /**
     *  <p align="left" style="margin-top: 0">
     *                          tipo de la clase a la que pertenece la informacion que contiene 
     *                          (extension)
     *                        </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.A3AE20F1-B70C-179E-FFA6-B585CDCCAF97]
    // </editor-fold> 
    public String tipo;

    /**
     *  <p style="margin-top: 0">
     *                atributo que guarda la informacion de cada clase compilada. en cada 
     *                posicion del Vector existe otro Vector, y en cada posicion de ese otro Vector
     *                existe un array tipo Object; en las posiciones de este array se 
     *                encuentra la informacion de cada atributo guardado
     *                  </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.5EBAA928-E2E2-984A-1858-126FE613A8D3]
    // </editor-fold> 
    public Vector tabla = new Vector();

    /**
     *  <p style="margin-top: 0">
     *                                constructor
     *                              </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.EC617E0C-2973-0829-3523-BD5ECFD5EA5B]
    // </editor-fold> 
    public TablaSimbolos () {
        for(int i=0;i<=tipoFin;i++){
            Vector v=new Vector();
            Object[] o=new Object[atribFin+1];
            for(int j=0;j<=atribFin;j++) o[j]="";
            o[Posiciones.EXISTE]="t¡po pr¡m¡t¡vo";
            v.add(o);
            tabla.add(v);
        }
    }

    /**
     *  <p style="margin-top: 0">
     *                                devuelve un valor de la tabla de simbolos
     *                              </p>
     *                              <p style="margin-top: 0">
     *                         @param tipo posicion en el array que determina el tipo de dato del atributo a modificar<br>
     *                         @param nombre nombre del atributo a modificar<br>
     *                         @param posDato posicion en el array de donde se toma el dato
     *                              </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.BBA9BD84-6B2A-127D-337B-CCFC4AB7AA61]
    // </editor-fold> 
    public Object getFromTabla (int tipo, String nombre, int posDato) {
        return null;
    }

    /**
     *  <p style="margin-top: 0">
     *                                agrega un valor a la tabla de simbolos
     *                              </p>
     *                              <p style="margin-top: 0">
     *                                @param tipo posicion en el array que determina el tipo de dato del 
     *                                atributo a modificar<br>@param nombre nombre del atributo a modificar
     *                          <br>@param posDato posicion en el array en el que se agrega el nuevo dato<br>@param 
     *                                valor valor a agregar en el atributo
     *                              </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.EB5DD5D4-EA64-A70F-00CE-E46D397471CF]
    // </editor-fold> 
    public void setAtTabla (int tipo, String nombre, int posDato, Object valor) {
    }

    /**
     *  <p style="margin-top: 0">
     *                                instancia un atributo o crea un atributo nuevo en la tabla de simbolos
     *                              </p>
     *                         <p style="margin-top: 0">
     *                         @param tipo posicion en el array que define el tipo de dato del nuevo atributo<br>
     *                         @param nombre nombre del nuevo atributo
     *                         </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.CE7C528D-52E1-E65A-B4AC-B2B5E1EAFAA6]
    // </editor-fold> 
    public void instanciar (int tipo, String nombre) {
        //instanciar la posicion en el vector con un array tipo object que tenga "" en todas sus posiciones
        //existe=0
    }

    /**
     *  <p style="margin-top: 0">
     *        retorna un indice (que representa el String recibido) que se puede usar 
     *        como posicion en la tabla de simbolos para encontrar un tipo o atributo
     * </p>
     * <p style="margin-top: 0">
     * @param s String a convertir
     * </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.E0BE1514-00C9-4EAC-323A-9B458748B6C7]
    // </editor-fold> 
    public int convertPos (String s) {
        int tmp=s.indexOf('[');
        if(tmp!=-1) s=s.substring(0, tmp);
        tmp=s.lastIndexOf('.');
        if(tmp!=-1)s=s.substring(tmp+1);

        if (s.equals("int")) return Posiciones.INT;
        if (s.equals("long")) return Posiciones.LONG;
        if (s.equals("String")) return Posiciones.STRING;
        if (s.equals("char")) return Posiciones.CHAR;
        if (s.equals("float")) return Posiciones.FLOAT;
        if (s.equals("double")) return Posiciones.DOUBLE;
        if (s.equals("void")) return Posiciones.VOID;
        if (s.equals("Object")) return Posiciones.OBJECT;

        for(int i=0;i<=this.tipoFin;i++){
            Vector v=(Vector)tabla.elementAt(i);
            Object o[]=(Object[])v.elementAt(0);
            if(o[Posiciones.EXISTE].toString().equals(s)){
                return i;//retornar el indice de un tipo de dato creado por el usuario
            }
        }

        return -1;//si no existe
    }

    /**
     *  <p style="margin-top: 0">
     *        devuelve la posicion en el array de tipos donde se encuentra el
     *        parametro 'var'. primero busca una variable que coincida con ambitos
     *        y si no la encuentra busca en las globales, si aun no la encuentra
     *        retorna -1
     * </p>
     * <p style="margin-top: 0">
     *  @param var nombre de la variable a buscar<br>
     *  @param ambito dice el ambito actual del compilador (metodo o procedimiento en compilacion)<br>
     *  @param clase clase a la que pertenece la variable
     * </p>
     * <p style="margin-top: 0">
     *  @return retorna la posicion en el array de tipos donde se encuentra el
     *        parametro 'var'
     * </p>
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.34C953D0-0796-8E77-9295-CC8AE22FDF10]
    // </editor-fold> 
    public int getTipoIndex (String var, String ambito, String clase) {
        //buscando por ambito
        for(int i=0;i<=this.tipoFin;i++){
            Vector v=(Vector)tabla.elementAt(i);
            for(int j=0;j<v.size();j++){
                Object o[]=(Object[])v.elementAt(j);
                if(o[Posiciones.NOMBRE].toString().equals(var)&&o[Posiciones.AMBITO].toString().equals(ambito)&&o[Posiciones.CLASE].toString().equals(clase)){
                    return i;
                }
            }
        }
        //buscando por global
        for(int i=0;i<=this.tipoFin;i++){
            Vector v=(Vector)tabla.elementAt(i);
            for(int j=0;j<v.size();j++){
                Object o[]=(Object[])v.elementAt(j);
                if(o[Posiciones.NOMBRE].toString().equals(var)&&o[Posiciones.ESGLOBAL].toString().equals("1")&&o[Posiciones.CLASE].toString().equals(clase)){
                    return i;
                }
            }
        }
        return -1;//si no existe
    }

    /**
     *  <p style="margin-top: 0">
     *        agrega una nueva columna en el vector de la tabla de simbolos el
     *        cual representa un nuevo tipo de dato, o una clase nueva en otras palabras.
     * </p>
     * <p style="margin-top: 0">
     *  @param nombre nombre del nuevo tipo de dato
     * </p>
     */
    public void addNewType(String nombre){
        Vector v=new Vector();
        Object[] o=new Object[atribFin+1];
        for(int i=0;i<=atribFin;i++) o[i]="";//inicializando posiciones del array
        o[Posiciones.EXISTE]=nombre;
        v.add(o);
        tabla.add(v);//agregando nuevo tipo a la tabla
        tipoFin++;//incrementando el contador de numero de tipos en la tabla
    }

}

