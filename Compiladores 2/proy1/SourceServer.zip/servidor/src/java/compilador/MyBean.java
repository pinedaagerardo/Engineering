/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package compilador;

import java.io.Serializable;

/**
 *
 * @author g
 */
public class MyBean implements Serializable{

    public MyBean(){}

}
