/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package compilador;

/**
 *
 * @author g
 */
public interface Posiciones {

    //propiedades
    public int ID = 0;
    public int EXISTE = 1;
    public int FORECOLOR = 2;
    public int FORESIZE = 3;
    public int TEXT = 4;
    public int IMAGEPATH = 5;
    public int ALIGNMENT = 6;
    public int TYPETITLE = 7; //titulo o normal
    public int BACKCOLOR = 8;
    public int CHECK = 9;
    public int TYPEBUTTON = 10; //jcheck o jradio
    public int WIDTH = 11;
    public int HEIGHT = 12;
    public int TOP = 13;
    public int LEFT = 14;
    public int COLS = 15;
    public int ROWS = 16;
    public int PARENT = 17;
    public int EVENTO_CLIC = 18;
    public int EVENTO_CHANGE = 19;
    public int ADD = 20;

    //tipos de datos
    public int TABLASIMBOLOS = 0; //aqui se almacenan otras tablas que estan adentro de la principal
    public int JLABEL = 1;
    public int JBUTTON = 2;
    public int JCHECKBOX = 3;
    public int JRADIOBUTTON = 4;
    public int BUTTONGROUP = 5;
    public int JCOMBOBOX = 6;
    public int JTEXTFIELD = 7;
    public int JTEXTAREA = 8;
    public int JPASSWORDFIELD = 9;
    public int JTREE = 10;
    public int JTABLE = 11;
    public int JPANEL = 12;
    public int JFILECHOOSER = 13;
    public int IMAGEICON = 14;
    public int DEFAULTMUTABLETREENODE = 15;
    public int DEFAULTTREEMODEL = 16;
}
