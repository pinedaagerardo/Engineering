
package compilador;

import TablaSim.*;
import goldengine.java.*;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Vector;

/*
 * Licensed Material - Property of Matthew Hawkins (hawkini@4email.net) 
 */
 
public class parser implements GPMessageConstants
{
 
    private interface SymbolConstants 
    {
       final int SYMBOL_EOF                          =   0;  // (EOF)
       final int SYMBOL_ERROR                        =   1;  // (Error)
       final int SYMBOL_WHITESPACE                   =   2;  // (Whitespace)
       final int SYMBOL_COMMENTEND                   =   3;  // (Comment End)
       final int SYMBOL_COMMENTLINE                  =   4;  // (Comment Line)
       final int SYMBOL_COMMENTSTART                 =   5;  // (Comment Start)
       final int SYMBOL_MINUS                        =   6;  // '-'
       final int SYMBOL_MINUSMINUS                   =   7;  // --
       final int SYMBOL_EXCLAMEQ                     =   8;  // '!='
       final int SYMBOL_PERCENT                      =   9;  // '%'
       final int SYMBOL_PERCENTEQ                    =  10;  // '%='
       final int SYMBOL_AMPAMP                       =  11;  // '&&'
       final int SYMBOL_LPARAN                       =  12;  // '('
       final int SYMBOL_RPARAN                       =  13;  // ')'
       final int SYMBOL_TIMES                        =  14;  // '*'
       final int SYMBOL_TIMESEQ                      =  15;  // '*='
       final int SYMBOL_COMMA                        =  16;  // ','
       final int SYMBOL_DOT                          =  17;  // '.'
       final int SYMBOL_DIV                          =  18;  // '/'
       final int SYMBOL_DIVEQ                        =  19;  // '/='
       final int SYMBOL_COLON                        =  20;  // ':'
       final int SYMBOL_SEMI                         =  21;  // ';'
       final int SYMBOL_QUESTION                     =  22;  // '?'
       final int SYMBOL_LBRACKET                     =  23;  // '['
       final int SYMBOL_RBRACKET                     =  24;  // ']'
       final int SYMBOL_LBRACE                       =  25;  // '{'
       final int SYMBOL_PIPEPIPE                     =  26;  // '||'
       final int SYMBOL_RBRACE                       =  27;  // '}'
       final int SYMBOL_PLUS                         =  28;  // '+'
       final int SYMBOL_PLUSPLUS                     =  29;  // '++'
       final int SYMBOL_PLUSEQ                       =  30;  // '+='
       final int SYMBOL_LT                           =  31;  // '<'
       final int SYMBOL_LTEQ                         =  32;  // '<='
       final int SYMBOL_EQ                           =  33;  // '='
       final int SYMBOL_MINUSEQ                      =  34;  // '-='
       final int SYMBOL_EQEQ                         =  35;  // '=='
       final int SYMBOL_GT                           =  36;  // '>'
       final int SYMBOL_GTEQ                         =  37;  // '>='
       final int SYMBOL_ABSTRACT                     =  38;  // abstract
       final int SYMBOL_BOOL                         =  39;  // Bool
       final int SYMBOL_BOOLEAN                      =  40;  // boolean
       final int SYMBOL_BREAK                        =  41;  // break
       final int SYMBOL_BYTE                         =  42;  // byte
       final int SYMBOL_CASE                         =  43;  // case
       final int SYMBOL_CATCH                        =  44;  // catch
       final int SYMBOL_CHAR                         =  45;  // char
       final int SYMBOL_CHARINDIRECTO                =  46;  // CharIndirecto
       final int SYMBOL_CLASS                        =  47;  // class
       final int SYMBOL_CONTINUE                     =  48;  // continue
       final int SYMBOL_DEFAULT                      =  49;  // default
       final int SYMBOL_DO                           =  50;  // do
       final int SYMBOL_DOUBLE                       =  51;  // double
       final int SYMBOL_ELSE                         =  52;  // else
       final int SYMBOL_EXPRNULL                     =  53;  // ExprNull
       final int SYMBOL_EXTENDS                      =  54;  // extends
       final int SYMBOL_FINAL                        =  55;  // final
       final int SYMBOL_FINALLY                      =  56;  // finally
       final int SYMBOL_FLOAT                        =  57;  // float
       final int SYMBOL_FOR                          =  58;  // for
       final int SYMBOL_HEXESCAPECHAR                =  59;  // HexEscapeChar
       final int SYMBOL_ID                           =  60;  // Id
       final int SYMBOL_IF                           =  61;  // if
       final int SYMBOL_IMPLEMENTS                   =  62;  // implements
       final int SYMBOL_IMPORT                       =  63;  // import
       final int SYMBOL_INSTANCEOF                   =  64;  // instanceof
       final int SYMBOL_INT                          =  65;  // int
       final int SYMBOL_INTERFACE                    =  66;  // interface
       final int SYMBOL_LONG                         =  67;  // long
       final int SYMBOL_NEW                          =  68;  // new
       final int SYMBOL_NUM                          =  69;  // Num
       final int SYMBOL_NUMCERO                      =  70;  // NumCero
       final int SYMBOL_NUMFLOAT                     =  71;  // NumFloat
       final int SYMBOL_NUMFLOATEXP                  =  72;  // NumFloatExp
       final int SYMBOL_NUMHEX                       =  73;  // NumHex
       final int SYMBOL_NUMOCTAL                     =  74;  // NumOctal
       final int SYMBOL_OCTALESCAPECHAR              =  75;  // OctalEscapeChar
       final int SYMBOL_PACKAGE                      =  76;  // package
       final int SYMBOL_PRIVATE                      =  77;  // private
       final int SYMBOL_PROTECTED                    =  78;  // protected
       final int SYMBOL_PUBLIC                       =  79;  // public
       final int SYMBOL_RETURN                       =  80;  // return
       final int SYMBOL_SHORT                        =  81;  // short
       final int SYMBOL_STATIC                       =  82;  // static
       final int SYMBOL_STESCAPECHAR                 =  83;  // StEscapeChar
       final int SYMBOL_STRING                       =  84;  // String
       final int SYMBOL_SUPER                        =  85;  // super
       final int SYMBOL_SWITCH                       =  86;  // switch
       final int SYMBOL_SYNCHRONIZED                 =  87;  // synchronized
       final int SYMBOL_THIS                         =  88;  // this
       final int SYMBOL_THROW                        =  89;  // throw
       final int SYMBOL_THROWS                       =  90;  // throws
       final int SYMBOL_TRY                          =  91;  // try
       final int SYMBOL_UNSTRING                     =  92;  // unString
       final int SYMBOL_VECTOR                       =  93;  // Vector
       final int SYMBOL_VOID                         =  94;  // void
       final int SYMBOL_WHILE                        =  95;  // while
       final int SYMBOL_ACCESOARRAY                  =  96;  // <AccesoArray>
       final int SYMBOL_ACCESOCAMPO                  =  97;  // <AccesoCampo>
       final int SYMBOL_ADDEXPRESION                 =  98;  // <AddExpresion>
       final int SYMBOL_ANDCONDICIONALEXPRESION      =  99;  // <AndCondicionalExpresion>
       final int SYMBOL_ARRAYINI                     = 100;  // <ArrayIni>
       final int SYMBOL_BLOCK                        = 101;  // <Block>
       final int SYMBOL_BLOCKSENTENCIA               = 102;  // <BlockSentencia>
       final int SYMBOL_BLOCKSENTENCIAS              = 103;  // <BlockSentencias>
       final int SYMBOL_BREAKSENTENCIA               = 104;  // <BreakSentencia>
       final int SYMBOL_CABECERAMETODO               = 105;  // <CabeceraMetodo>
       final int SYMBOL_CARACTER                     = 106;  // <Caracter>
       final int SYMBOL_CASTEXPRESION                = 107;  // <CastExpresion>
       final int SYMBOL_CATCHES                      = 108;  // <Catches>
       final int SYMBOL_CONSTRUCTORDECLARATOR        = 109;  // <ConstructorDeclarator>
       final int SYMBOL_CONTINUESENTENCIA            = 110;  // <ContinueSentencia>
       final int SYMBOL_CORCHETES                    = 111;  // <Corchetes>
       final int SYMBOL_CREACIONARRAY                = 112;  // <CreacionArray>
       final int SYMBOL_CREACIONINSTANCIA            = 113;  // <CreacionInstancia>
       final int SYMBOL_CUERPOCLASE                  = 114;  // <CuerpoClase>
       final int SYMBOL_CUERPOCONSTRUCTOR            = 115;  // <CuerpoConstructor>
       final int SYMBOL_CUERPOINTERFAZ               = 116;  // <CuerpoInterfaz>
       final int SYMBOL_CUERPOMETODO                 = 117;  // <CuerpoMetodo>
       final int SYMBOL_DECLARACIONCAMPO             = 118;  // <DeclaracionCampo>
       final int SYMBOL_DECLARACIONCLASE             = 119;  // <DeclaracionClase>
       final int SYMBOL_DECLARACIONCONSTRUCTOR       = 120;  // <DeclaracionConstructor>
       final int SYMBOL_DECLARACIONCUERPOCLASE       = 121;  // <DeclaracionCuerpoClase>
       final int SYMBOL_DECLARACIONESCUERPOCLASE     = 122;  // <DeclaracionesCuerpoClase>
       final int SYMBOL_DECLARACIONESIMPORT          = 123;  // <DeclaracionesImport>
       final int SYMBOL_DECLARACIONESMIEMBROINTERFAZ = 124;  // <DeclaracionesMiembroInterfaz>
       final int SYMBOL_DECLARACIONESTIPO            = 125;  // <DeclaracionesTipo>
       final int SYMBOL_DECLARACIONIMPORT            = 126;  // <DeclaracionImport>
       final int SYMBOL_DECLARACIONINTERFAZ          = 127;  // <DeclaracionInterfaz>
       final int SYMBOL_DECLARACIONMETODOABSTRACTO   = 128;  // <DeclaracionMetodoAbstracto>
       final int SYMBOL_DECLARACIONMIEMBROCLASE      = 129;  // <DeclaracionMiembroClase>
       final int SYMBOL_DECLARACIONMIEMBROINTERFAZ   = 130;  // <DeclaracionMiembroInterfaz>
       final int SYMBOL_DECLARACIONTIPO              = 131;  // <DeclaracionTipo>
       final int SYMBOL_DECLARADORESVARIABLE         = 132;  // <DeclaradoresVariable>
       final int SYMBOL_DECLARADORMETODO             = 133;  // <DeclaradorMetodo>
       final int SYMBOL_DECLARADORVARIABLE           = 134;  // <DeclaradorVariable>
       final int SYMBOL_DECLARADORVARIABLEID         = 135;  // <DeclaradorVariableId>
       final int SYMBOL_EXPRCORCHETES                = 136;  // <ExprCorchetes>
       final int SYMBOL_EXPRESIONASIGNA              = 137;  // <ExpresionAsigna>
       final int SYMBOL_EXPRESIONCOMPARAR            = 138;  // <ExpresionComparar>
       final int SYMBOL_EXPRESIONCONDICIONAL         = 139;  // <ExpresionCondicional>
       final int SYMBOL_EXPRESIONIGUAL               = 140;  // <ExpresionIgual>
       final int SYMBOL_EXPRSCORCHETES               = 141;  // <ExprsCorchetes>
       final int SYMBOL_EXTENDSINTERFACES            = 142;  // <ExtendsInterfaces>
       final int SYMBOL_FLOAT2                       = 143;  // <float>
       final int SYMBOL_FORACTUALIZAR                = 144;  // <ForActualizar>
       final int SYMBOL_FORSENTENCIA                 = 145;  // <ForSentencia>
       final int SYMBOL_FORSENTENCIAIFEXTENDIDO      = 146;  // <ForSentenciaIfExtendido>
       final int SYMBOL_GRUPOSSWITCH                 = 147;  // <GruposSwitch>
       final int SYMBOL_INICIALIZARFOR               = 148;  // <InicializarFor>
       final int SYMBOL_INT2                         = 149;  // <Int>
       final int SYMBOL_INVOCACIONMETODO             = 150;  // <InvocacionMetodo>
       final int SYMBOL_INVOEXPLICITACONSTRUCTOR     = 151;  // <InvoExplicitaConstructor>
       final int SYMBOL_LEFTSIDE                     = 152;  // <LeftSide>
       final int SYMBOL_LISTAARGUMENTO               = 153;  // <ListaArgumento>
       final int SYMBOL_LISTADOSENTENCIAEXPRESION    = 154;  // <ListadoSentenciaExpresion>
       final int SYMBOL_LISTAINTERFACES              = 155;  // <ListaInterfaces>
       final int SYMBOL_LISTATIPOCLASE               = 156;  // <ListaTipoClase>
       final int SYMBOL_LITERAL                      = 157;  // <Literal>
       final int SYMBOL_MODIFICADOR                  = 158;  // <Modificador>
       final int SYMBOL_MODIFICADOR2                 = 159;  // <Modificador2>
       final int SYMBOL_MULTEXPRESION                = 160;  // <MultExpresion>
       final int SYMBOL_NOMBRE                       = 161;  // <Nombre>
       final int SYMBOL_NOMBRECLASIFICADO            = 162;  // <NombreClasificado>
       final int SYMBOL_NOMBRESIMPLE                 = 163;  // <NombreSimple>
       final int SYMBOL_NUMDECIMAL                   = 164;  // <numdecimal>
       final int SYMBOL_OPERADORASIGNACION           = 165;  // <OperadorAsignacion>
       final int SYMBOL_ORCONDICIONALEXPRESION       = 166;  // <OrCondicionalExpresion>
       final int SYMBOL_PARAMLIST                    = 167;  // <ParamList>
       final int SYMBOL_POSFIJOEXPRESION             = 168;  // <PosfijoExpresion>
       final int SYMBOL_PRIMARY                      = 169;  // <Primary>
       final int SYMBOL_PRIMARYNONEWARRAY            = 170;  // <PrimaryNoNewArray>
       final int SYMBOL_PROGRAM                      = 171;  // <Program>
       final int SYMBOL_RETURNSENTENCIA              = 172;  // <ReturnSentencia>
       final int SYMBOL_SENTENCIA                    = 173;  // <Sentencia>
       final int SYMBOL_SENTENCIAEXPRESION           = 174;  // <SentenciaExpresion>
       final int SYMBOL_SENTENCIAIFEXTENDIDO         = 175;  // <SentenciaIfExtendido>
       final int SYMBOL_SENTENCIASINSUBSENTENCIA     = 176;  // <SentenciaSinSubsentencia>
       final int SYMBOL_SWITCHBLOCK                  = 177;  // <SwitchBlock>
       final int SYMBOL_SWITCHLABEL                  = 178;  // <SwitchLabel>
       final int SYMBOL_SWITCHLABELS                 = 179;  // <SwitchLabels>
       final int SYMBOL_THROWS2                      = 180;  // <Throws>
       final int SYMBOL_TIPO                         = 181;  // <Tipo>
       final int SYMBOL_TIPOARRAY                    = 182;  // <TipoArray>
       final int SYMBOL_TIPOFLOTANTE                 = 183;  // <TipoFlotante>
       final int SYMBOL_TIPOINT                      = 184;  // <TipoInt>
       final int SYMBOL_TIPONUMERICO                 = 185;  // <TipoNumerico>
       final int SYMBOL_TIPOPRIMITIVO                = 186;  // <TipoPrimitivo>
       final int SYMBOL_TIPOREFERENCIA               = 187;  // <TipoReferencia>
       final int SYMBOL_TRYSENTENCIA                 = 188;  // <TrySentencia>
       final int SYMBOL_UNARIOEXPRESION              = 189;  // <UnarioExpresion>
       final int SYMBOL_UNARIOEXPRESIONOTRA          = 190;  // <UnarioExpresionOtra>
       final int SYMBOL_VARIABLEINI                  = 191;  // <VariableIni>
       final int SYMBOL_VARIABLEINIS                 = 192;  // <VariableInis>
    };

    private interface RuleConstants
    {
       final int RULE_PROGRAM_PACKAGE_SEMI                                 =   0;  // <Program> ::= package <Nombre> ';' <DeclaracionesImport> <DeclaracionesTipo>
       final int RULE_PROGRAM_PACKAGE_SEMI2                                =   1;  // <Program> ::= package <Nombre> ';' <DeclaracionesImport>
       final int RULE_PROGRAM_PACKAGE_SEMI3                                =   2;  // <Program> ::= package <Nombre> ';' <DeclaracionesTipo>
       final int RULE_PROGRAM_PACKAGE_SEMI4                                =   3;  // <Program> ::= package <Nombre> ';'
       final int RULE_PROGRAM                                              =   4;  // <Program> ::= <DeclaracionesImport> <DeclaracionesTipo>
       final int RULE_PROGRAM2                                             =   5;  // <Program> ::= <DeclaracionesImport>
       final int RULE_PROGRAM3                                             =   6;  // <Program> ::= <DeclaracionesTipo>
       final int RULE_PROGRAM4                                             =   7;  // <Program> ::= 
       final int RULE_DECLARACIONESIMPORT                                  =   8;  // <DeclaracionesImport> ::= <DeclaracionImport>
       final int RULE_DECLARACIONESIMPORT2                                 =   9;  // <DeclaracionesImport> ::= <DeclaracionesImport> <DeclaracionImport>
       final int RULE_DECLARACIONESTIPO                                    =  10;  // <DeclaracionesTipo> ::= <DeclaracionTipo>
       final int RULE_DECLARACIONESTIPO2                                   =  11;  // <DeclaracionesTipo> ::= <DeclaracionesTipo> <DeclaracionTipo>
       final int RULE_DECLARACIONIMPORT_IMPORT_SEMI                        =  12;  // <DeclaracionImport> ::= import <Nombre> ';'
       final int RULE_DECLARACIONIMPORT_IMPORT_DOT_TIMES_SEMI              =  13;  // <DeclaracionImport> ::= import <Nombre> '.' '*' ';'
       final int RULE_DECLARACIONTIPO                                      =  14;  // <DeclaracionTipo> ::= <DeclaracionClase>
       final int RULE_DECLARACIONTIPO2                                     =  15;  // <DeclaracionTipo> ::= <DeclaracionInterfaz>
       final int RULE_MODIFICADOR2_STATIC                                  =  16;  // <Modificador2> ::= static
       final int RULE_MODIFICADOR2_ABSTRACT                                =  17;  // <Modificador2> ::= abstract
       final int RULE_MODIFICADOR2_FINAL                                   =  18;  // <Modificador2> ::= final
       final int RULE_MODIFICADOR2                                         =  19;  // <Modificador2> ::= <Modificador>
       final int RULE_MODIFICADOR2_STATIC2                                 =  20;  // <Modificador2> ::= <Modificador> static
       final int RULE_MODIFICADOR2_ABSTRACT2                               =  21;  // <Modificador2> ::= <Modificador> abstract
       final int RULE_MODIFICADOR2_FINAL2                                  =  22;  // <Modificador2> ::= <Modificador> final
       final int RULE_MODIFICADOR_PUBLIC                                   =  23;  // <Modificador> ::= public
       final int RULE_MODIFICADOR_PROTECTED                                =  24;  // <Modificador> ::= protected
       final int RULE_MODIFICADOR_PRIVATE                                  =  25;  // <Modificador> ::= private
       final int RULE_DECLARACIONCLASE_CLASS_ID_EXTENDS_IMPLEMENTS         =  26;  // <DeclaracionClase> ::= <Modificador2> class Id extends <Nombre> implements <ListaInterfaces> <CuerpoClase>
       final int RULE_DECLARACIONCLASE_CLASS_ID_EXTENDS                    =  27;  // <DeclaracionClase> ::= <Modificador2> class Id extends <Nombre> <CuerpoClase>
       final int RULE_DECLARACIONCLASE_CLASS_ID_IMPLEMENTS                 =  28;  // <DeclaracionClase> ::= <Modificador2> class Id implements <ListaInterfaces> <CuerpoClase>
       final int RULE_DECLARACIONCLASE_CLASS_ID                            =  29;  // <DeclaracionClase> ::= <Modificador2> class Id <CuerpoClase>
       final int RULE_DECLARACIONCLASE_CLASS_ID_EXTENDS_IMPLEMENTS2        =  30;  // <DeclaracionClase> ::= class Id extends <Nombre> implements <ListaInterfaces> <CuerpoClase>
       final int RULE_DECLARACIONCLASE_CLASS_ID_EXTENDS2                   =  31;  // <DeclaracionClase> ::= class Id extends <Nombre> <CuerpoClase>
       final int RULE_DECLARACIONCLASE_CLASS_ID_IMPLEMENTS2                =  32;  // <DeclaracionClase> ::= class Id implements <ListaInterfaces> <CuerpoClase>
       final int RULE_DECLARACIONCLASE_CLASS_ID2                           =  33;  // <DeclaracionClase> ::= class Id <CuerpoClase>
       final int RULE_LISTAINTERFACES                                      =  34;  // <ListaInterfaces> ::= <Nombre>
       final int RULE_LISTAINTERFACES_COMMA                                =  35;  // <ListaInterfaces> ::= <ListaInterfaces> ',' <Nombre>
       final int RULE_CUERPOCLASE_LBRACE_RBRACE                            =  36;  // <CuerpoClase> ::= '{' <DeclaracionesCuerpoClase> '}'
       final int RULE_CUERPOCLASE_LBRACE_RBRACE2                           =  37;  // <CuerpoClase> ::= '{' '}'
       final int RULE_DECLARACIONESCUERPOCLASE                             =  38;  // <DeclaracionesCuerpoClase> ::= <DeclaracionCuerpoClase>
       final int RULE_DECLARACIONESCUERPOCLASE2                            =  39;  // <DeclaracionesCuerpoClase> ::= <DeclaracionesCuerpoClase> <DeclaracionCuerpoClase>
       final int RULE_DECLARACIONCUERPOCLASE                               =  40;  // <DeclaracionCuerpoClase> ::= <DeclaracionMiembroClase>
       final int RULE_DECLARACIONCUERPOCLASE_STATIC                        =  41;  // <DeclaracionCuerpoClase> ::= static <Block>
       final int RULE_DECLARACIONCUERPOCLASE2                              =  42;  // <DeclaracionCuerpoClase> ::= <DeclaracionConstructor>
       final int RULE_DECLARACIONMIEMBROCLASE                              =  43;  // <DeclaracionMiembroClase> ::= <DeclaracionCampo>
       final int RULE_DECLARACIONMIEMBROCLASE2                             =  44;  // <DeclaracionMiembroClase> ::= <CabeceraMetodo> <CuerpoMetodo>
       final int RULE_DECLARACIONCAMPO_SEMI                                =  45;  // <DeclaracionCampo> ::= <Modificador2> <Tipo> <DeclaradoresVariable> ';'
       final int RULE_DECLARACIONCAMPO_SEMI2                               =  46;  // <DeclaracionCampo> ::= <Tipo> <DeclaradoresVariable> ';'
       final int RULE_DECLARADORESVARIABLE                                 =  47;  // <DeclaradoresVariable> ::= <DeclaradorVariable>
       final int RULE_DECLARADORESVARIABLE_COMMA                           =  48;  // <DeclaradoresVariable> ::= <DeclaradoresVariable> ',' <DeclaradorVariable>
       final int RULE_DECLARADORVARIABLE                                   =  49;  // <DeclaradorVariable> ::= <DeclaradorVariableId>
       final int RULE_DECLARADORVARIABLE_EQ                                =  50;  // <DeclaradorVariable> ::= <DeclaradorVariableId> '=' <VariableIni>
       final int RULE_DECLARADORVARIABLEID_ID                              =  51;  // <DeclaradorVariableId> ::= Id
       final int RULE_DECLARADORVARIABLEID_LBRACKET_RBRACKET               =  52;  // <DeclaradorVariableId> ::= <DeclaradorVariableId> '[' ']'
       final int RULE_VARIABLEINI                                          =  53;  // <VariableIni> ::= <ExpresionAsigna>
       final int RULE_VARIABLEINI2                                         =  54;  // <VariableIni> ::= <ArrayIni>
       final int RULE_CABECERAMETODO                                       =  55;  // <CabeceraMetodo> ::= <Modificador2> <Tipo> <DeclaradorMetodo> <Throws>
       final int RULE_CABECERAMETODO2                                      =  56;  // <CabeceraMetodo> ::= <Modificador2> <Tipo> <DeclaradorMetodo>
       final int RULE_CABECERAMETODO3                                      =  57;  // <CabeceraMetodo> ::= <Tipo> <DeclaradorMetodo> <Throws>
       final int RULE_CABECERAMETODO4                                      =  58;  // <CabeceraMetodo> ::= <Tipo> <DeclaradorMetodo>
       final int RULE_CABECERAMETODO_VOID                                  =  59;  // <CabeceraMetodo> ::= <Modificador2> void <DeclaradorMetodo> <Throws>
       final int RULE_CABECERAMETODO_VOID2                                 =  60;  // <CabeceraMetodo> ::= <Modificador2> void <DeclaradorMetodo>
       final int RULE_CABECERAMETODO_VOID3                                 =  61;  // <CabeceraMetodo> ::= void <DeclaradorMetodo> <Throws>
       final int RULE_CABECERAMETODO_VOID4                                 =  62;  // <CabeceraMetodo> ::= void <DeclaradorMetodo>
       final int RULE_DECLARADORMETODO_ID_LPARAN_RPARAN                    =  63;  // <DeclaradorMetodo> ::= Id '(' <ParamList> ')'
       final int RULE_DECLARADORMETODO_ID_LPARAN_RPARAN2                   =  64;  // <DeclaradorMetodo> ::= Id '(' ')'
       final int RULE_DECLARADORMETODO_LBRACKET_RBRACKET                   =  65;  // <DeclaradorMetodo> ::= <DeclaradorMetodo> '[' ']'
       final int RULE_PARAMLIST                                            =  66;  // <ParamList> ::= <Tipo> <DeclaradorVariableId>
       final int RULE_PARAMLIST_COMMA                                      =  67;  // <ParamList> ::= <ParamList> ',' <Tipo> <DeclaradorVariableId>
       final int RULE_CARACTER_CHARINDIRECTO                               =  68;  // <Caracter> ::= CharIndirecto
       final int RULE_CARACTER_STESCAPECHAR                                =  69;  // <Caracter> ::= StEscapeChar
       final int RULE_CARACTER_OCTALESCAPECHAR                             =  70;  // <Caracter> ::= OctalEscapeChar
       final int RULE_CARACTER_HEXESCAPECHAR                               =  71;  // <Caracter> ::= HexEscapeChar
       final int RULE_NUMDECIMAL_NUMCERO                                   =  72;  // <numdecimal> ::= NumCero
       final int RULE_NUMDECIMAL_NUM                                       =  73;  // <numdecimal> ::= Num
       final int RULE_FLOAT_NUMFLOAT                                       =  74;  // <float> ::= NumFloat
       final int RULE_FLOAT_NUMFLOATEXP                                    =  75;  // <float> ::= NumFloatExp
       final int RULE_INT                                                  =  76;  // <Int> ::= <numdecimal>
       final int RULE_INT_NUMHEX                                           =  77;  // <Int> ::= NumHex
       final int RULE_INT_NUMOCTAL                                         =  78;  // <Int> ::= NumOctal
       final int RULE_LITERAL                                              =  79;  // <Literal> ::= <Int>
       final int RULE_LITERAL2                                             =  80;  // <Literal> ::= <float>
       final int RULE_LITERAL_BOOL                                         =  81;  // <Literal> ::= Bool
       final int RULE_LITERAL3                                             =  82;  // <Literal> ::= <Caracter>
       final int RULE_LITERAL_UNSTRING                                     =  83;  // <Literal> ::= unString
       final int RULE_LITERAL_EXPRNULL                                     =  84;  // <Literal> ::= ExprNull
       final int RULE_TIPO                                                 =  85;  // <Tipo> ::= <TipoPrimitivo>
       final int RULE_TIPO2                                                =  86;  // <Tipo> ::= <TipoReferencia>
       final int RULE_TIPOPRIMITIVO                                        =  87;  // <TipoPrimitivo> ::= <TipoNumerico>
       final int RULE_TIPOPRIMITIVO_BOOLEAN                                =  88;  // <TipoPrimitivo> ::= boolean
       final int RULE_TIPOPRIMITIVO_STRING                                 =  89;  // <TipoPrimitivo> ::= String
       final int RULE_TIPOPRIMITIVO_VECTOR                                 =  90;  // <TipoPrimitivo> ::= Vector
       final int RULE_TIPONUMERICO                                         =  91;  // <TipoNumerico> ::= <TipoInt>
       final int RULE_TIPONUMERICO2                                        =  92;  // <TipoNumerico> ::= <TipoFlotante>
       final int RULE_TIPOINT_BYTE                                         =  93;  // <TipoInt> ::= byte
       final int RULE_TIPOINT_SHORT                                        =  94;  // <TipoInt> ::= short
       final int RULE_TIPOINT_INT                                          =  95;  // <TipoInt> ::= int
       final int RULE_TIPOINT_LONG                                         =  96;  // <TipoInt> ::= long
       final int RULE_TIPOINT_CHAR                                         =  97;  // <TipoInt> ::= char
       final int RULE_TIPOFLOTANTE_FLOAT                                   =  98;  // <TipoFlotante> ::= float
       final int RULE_TIPOFLOTANTE_DOUBLE                                  =  99;  // <TipoFlotante> ::= double
       final int RULE_TIPOREFERENCIA                                       = 100;  // <TipoReferencia> ::= <Nombre>
       final int RULE_TIPOREFERENCIA2                                      = 101;  // <TipoReferencia> ::= <TipoArray>
       final int RULE_TIPOARRAY_LBRACKET_RBRACKET                          = 102;  // <TipoArray> ::= <TipoPrimitivo> '[' ']'
       final int RULE_TIPOARRAY_LBRACKET_RBRACKET2                         = 103;  // <TipoArray> ::= <Nombre> '[' ']'
       final int RULE_TIPOARRAY_LBRACKET_RBRACKET3                         = 104;  // <TipoArray> ::= <TipoArray> '[' ']'
       final int RULE_NOMBRE                                               = 105;  // <Nombre> ::= <NombreSimple>
       final int RULE_NOMBRE2                                              = 106;  // <Nombre> ::= <NombreClasificado>
       final int RULE_NOMBRESIMPLE_ID                                      = 107;  // <NombreSimple> ::= Id
       final int RULE_NOMBRECLASIFICADO_DOT_ID                             = 108;  // <NombreClasificado> ::= <Nombre> '.' Id
       final int RULE_THROWS_THROWS                                        = 109;  // <Throws> ::= throws <ListaTipoClase>
       final int RULE_LISTATIPOCLASE                                       = 110;  // <ListaTipoClase> ::= <Nombre>
       final int RULE_LISTATIPOCLASE_COMMA                                 = 111;  // <ListaTipoClase> ::= <ListaTipoClase> ',' <Nombre>
       final int RULE_CUERPOMETODO                                         = 112;  // <CuerpoMetodo> ::= <Block>
       final int RULE_CUERPOMETODO_SEMI                                    = 113;  // <CuerpoMetodo> ::= ';'
       final int RULE_DECLARACIONCONSTRUCTOR                               = 114;  // <DeclaracionConstructor> ::= <Modificador2> <ConstructorDeclarator> <Throws> <CuerpoConstructor>
       final int RULE_DECLARACIONCONSTRUCTOR2                              = 115;  // <DeclaracionConstructor> ::= <Modificador2> <ConstructorDeclarator> <CuerpoConstructor>
       final int RULE_DECLARACIONCONSTRUCTOR3                              = 116;  // <DeclaracionConstructor> ::= <ConstructorDeclarator> <Throws> <CuerpoConstructor>
       final int RULE_DECLARACIONCONSTRUCTOR4                              = 117;  // <DeclaracionConstructor> ::= <ConstructorDeclarator> <CuerpoConstructor>
       final int RULE_CONSTRUCTORDECLARATOR_LPARAN_RPARAN                  = 118;  // <ConstructorDeclarator> ::= <NombreSimple> '(' <ParamList> ')'
       final int RULE_CONSTRUCTORDECLARATOR_LPARAN_RPARAN2                 = 119;  // <ConstructorDeclarator> ::= <NombreSimple> '(' ')'
       final int RULE_CUERPOCONSTRUCTOR_LBRACE_RBRACE                      = 120;  // <CuerpoConstructor> ::= '{' <InvoExplicitaConstructor> <BlockSentencias> '}'
       final int RULE_CUERPOCONSTRUCTOR_LBRACE_RBRACE2                     = 121;  // <CuerpoConstructor> ::= '{' <InvoExplicitaConstructor> '}'
       final int RULE_CUERPOCONSTRUCTOR_LBRACE_RBRACE3                     = 122;  // <CuerpoConstructor> ::= '{' <BlockSentencias> '}'
       final int RULE_CUERPOCONSTRUCTOR_LBRACE_RBRACE4                     = 123;  // <CuerpoConstructor> ::= '{' '}'
       final int RULE_INVOEXPLICITACONSTRUCTOR_THIS_LPARAN_RPARAN_SEMI     = 124;  // <InvoExplicitaConstructor> ::= this '(' <ListaArgumento> ')' ';'
       final int RULE_INVOEXPLICITACONSTRUCTOR_THIS_LPARAN_RPARAN_SEMI2    = 125;  // <InvoExplicitaConstructor> ::= this '(' ')' ';'
       final int RULE_INVOEXPLICITACONSTRUCTOR_SUPER_LPARAN_RPARAN_SEMI    = 126;  // <InvoExplicitaConstructor> ::= super '(' <ListaArgumento> ')' ';'
       final int RULE_INVOEXPLICITACONSTRUCTOR_SUPER_LPARAN_RPARAN_SEMI2   = 127;  // <InvoExplicitaConstructor> ::= super '(' ')' ';'
       final int RULE_DECLARACIONINTERFAZ_INTERFACE_ID                     = 128;  // <DeclaracionInterfaz> ::= <Modificador2> interface Id <ExtendsInterfaces> <CuerpoInterfaz>
       final int RULE_DECLARACIONINTERFAZ_INTERFACE_ID2                    = 129;  // <DeclaracionInterfaz> ::= <Modificador2> interface Id <CuerpoInterfaz>
       final int RULE_DECLARACIONINTERFAZ_INTERFACE_ID3                    = 130;  // <DeclaracionInterfaz> ::= interface Id <ExtendsInterfaces> <CuerpoInterfaz>
       final int RULE_DECLARACIONINTERFAZ_INTERFACE_ID4                    = 131;  // <DeclaracionInterfaz> ::= interface Id <CuerpoInterfaz>
       final int RULE_EXTENDSINTERFACES_EXTENDS                            = 132;  // <ExtendsInterfaces> ::= extends <Nombre>
       final int RULE_EXTENDSINTERFACES_COMMA                              = 133;  // <ExtendsInterfaces> ::= <ExtendsInterfaces> ',' <Nombre>
       final int RULE_CUERPOINTERFAZ_LBRACE_RBRACE                         = 134;  // <CuerpoInterfaz> ::= '{' <DeclaracionesMiembroInterfaz> '}'
       final int RULE_CUERPOINTERFAZ_LBRACE_RBRACE2                        = 135;  // <CuerpoInterfaz> ::= '{' '}'
       final int RULE_DECLARACIONESMIEMBROINTERFAZ                         = 136;  // <DeclaracionesMiembroInterfaz> ::= <DeclaracionMiembroInterfaz>
       final int RULE_DECLARACIONESMIEMBROINTERFAZ2                        = 137;  // <DeclaracionesMiembroInterfaz> ::= <DeclaracionesMiembroInterfaz> <DeclaracionMiembroInterfaz>
       final int RULE_DECLARACIONMIEMBROINTERFAZ                           = 138;  // <DeclaracionMiembroInterfaz> ::= <DeclaracionCampo>
       final int RULE_DECLARACIONMIEMBROINTERFAZ2                          = 139;  // <DeclaracionMiembroInterfaz> ::= <DeclaracionMetodoAbstracto>
       final int RULE_DECLARACIONMETODOABSTRACTO_SEMI                      = 140;  // <DeclaracionMetodoAbstracto> ::= <CabeceraMetodo> ';'
       final int RULE_ARRAYINI_LBRACE_COMMA_RBRACE                         = 141;  // <ArrayIni> ::= '{' <VariableInis> ',' '}'
       final int RULE_ARRAYINI_LBRACE_RBRACE                               = 142;  // <ArrayIni> ::= '{' <VariableInis> '}'
       final int RULE_ARRAYINI_LBRACE_COMMA_RBRACE2                        = 143;  // <ArrayIni> ::= '{' ',' '}'
       final int RULE_ARRAYINI_LBRACE_RBRACE2                              = 144;  // <ArrayIni> ::= '{' '}'
       final int RULE_VARIABLEINIS                                         = 145;  // <VariableInis> ::= <VariableIni>
       final int RULE_VARIABLEINIS_COMMA                                   = 146;  // <VariableInis> ::= <VariableInis> ',' <VariableIni>
       final int RULE_BLOCK_LBRACE_RBRACE                                  = 147;  // <Block> ::= '{' <BlockSentencias> '}'
       final int RULE_BLOCK_LBRACE_RBRACE2                                 = 148;  // <Block> ::= '{' '}'
       final int RULE_BLOCKSENTENCIAS                                      = 149;  // <BlockSentencias> ::= <BlockSentencia>
       final int RULE_BLOCKSENTENCIAS2                                     = 150;  // <BlockSentencias> ::= <BlockSentencias> <BlockSentencia>
       final int RULE_BLOCKSENTENCIA_SEMI                                  = 151;  // <BlockSentencia> ::= <Tipo> <DeclaradoresVariable> ';'
       final int RULE_BLOCKSENTENCIA                                       = 152;  // <BlockSentencia> ::= <Sentencia>
       final int RULE_SENTENCIA                                            = 153;  // <Sentencia> ::= <SentenciaSinSubsentencia>
       final int RULE_SENTENCIA_ID_COLON                                   = 154;  // <Sentencia> ::= Id ':' <Sentencia>
       final int RULE_SENTENCIA_IF_LPARAN_RPARAN                           = 155;  // <Sentencia> ::= if '(' <ExpresionAsigna> ')' <Sentencia>
       final int RULE_SENTENCIA_IF_LPARAN_RPARAN_ELSE                      = 156;  // <Sentencia> ::= if '(' <ExpresionAsigna> ')' <SentenciaIfExtendido> else <Sentencia>
       final int RULE_SENTENCIA_WHILE_LPARAN_RPARAN                        = 157;  // <Sentencia> ::= while '(' <ExpresionAsigna> ')' <Sentencia>
       final int RULE_SENTENCIA2                                           = 158;  // <Sentencia> ::= <ForSentencia>
       final int RULE_SENTENCIAIFEXTENDIDO                                 = 159;  // <SentenciaIfExtendido> ::= <SentenciaSinSubsentencia>
       final int RULE_SENTENCIAIFEXTENDIDO_ID_COLON                        = 160;  // <SentenciaIfExtendido> ::= Id ':' <SentenciaIfExtendido>
       final int RULE_SENTENCIAIFEXTENDIDO_IF_LPARAN_RPARAN_ELSE           = 161;  // <SentenciaIfExtendido> ::= if '(' <ExpresionAsigna> ')' <SentenciaIfExtendido> else <SentenciaIfExtendido>
       final int RULE_SENTENCIAIFEXTENDIDO_WHILE_LPARAN_RPARAN             = 162;  // <SentenciaIfExtendido> ::= while '(' <ExpresionAsigna> ')' <SentenciaIfExtendido>
       final int RULE_SENTENCIAIFEXTENDIDO2                                = 163;  // <SentenciaIfExtendido> ::= <ForSentenciaIfExtendido>
       final int RULE_SENTENCIASINSUBSENTENCIA                             = 164;  // <SentenciaSinSubsentencia> ::= <Block>
       final int RULE_SENTENCIASINSUBSENTENCIA_SEMI                        = 165;  // <SentenciaSinSubsentencia> ::= ';'
       final int RULE_SENTENCIASINSUBSENTENCIA_SEMI2                       = 166;  // <SentenciaSinSubsentencia> ::= <SentenciaExpresion> ';'
       final int RULE_SENTENCIASINSUBSENTENCIA_SWITCH_LPARAN_RPARAN        = 167;  // <SentenciaSinSubsentencia> ::= switch '(' <ExpresionAsigna> ')' <SwitchBlock>
       final int RULE_SENTENCIASINSUBSENTENCIA_DO_WHILE_LPARAN_RPARAN_SEMI = 168;  // <SentenciaSinSubsentencia> ::= do <Sentencia> while '(' <ExpresionAsigna> ')' ';'
       final int RULE_SENTENCIASINSUBSENTENCIA2                            = 169;  // <SentenciaSinSubsentencia> ::= <BreakSentencia>
       final int RULE_SENTENCIASINSUBSENTENCIA3                            = 170;  // <SentenciaSinSubsentencia> ::= <ContinueSentencia>
       final int RULE_SENTENCIASINSUBSENTENCIA4                            = 171;  // <SentenciaSinSubsentencia> ::= <ReturnSentencia>
       final int RULE_SENTENCIASINSUBSENTENCIA_SYNCHRONIZED_LPARAN_RPARAN  = 172;  // <SentenciaSinSubsentencia> ::= synchronized '(' <ExpresionAsigna> ')' <Block>
       final int RULE_SENTENCIASINSUBSENTENCIA_THROW_SEMI                  = 173;  // <SentenciaSinSubsentencia> ::= throw <ExpresionAsigna> ';'
       final int RULE_SENTENCIASINSUBSENTENCIA5                            = 174;  // <SentenciaSinSubsentencia> ::= <TrySentencia>
       final int RULE_SENTENCIAEXPRESION                                   = 175;  // <SentenciaExpresion> ::= <LeftSide> <OperadorAsignacion> <ExpresionAsigna>
       final int RULE_SENTENCIAEXPRESION_PLUSPLUS                          = 176;  // <SentenciaExpresion> ::= '++' <UnarioExpresion>
       final int RULE_SENTENCIAEXPRESION_MINUSMINUS                        = 177;  // <SentenciaExpresion> ::= -- <UnarioExpresion>
       final int RULE_SENTENCIAEXPRESION_PLUSPLUS2                         = 178;  // <SentenciaExpresion> ::= <PosfijoExpresion> '++'
       final int RULE_SENTENCIAEXPRESION_MINUSMINUS2                       = 179;  // <SentenciaExpresion> ::= <PosfijoExpresion> --
       final int RULE_SENTENCIAEXPRESION2                                  = 180;  // <SentenciaExpresion> ::= <InvocacionMetodo>
       final int RULE_SENTENCIAEXPRESION3                                  = 181;  // <SentenciaExpresion> ::= <CreacionInstancia>
       final int RULE_SWITCHBLOCK_LBRACE_RBRACE                            = 182;  // <SwitchBlock> ::= '{' <GruposSwitch> <SwitchLabels> '}'
       final int RULE_SWITCHBLOCK_LBRACE_RBRACE2                           = 183;  // <SwitchBlock> ::= '{' <GruposSwitch> '}'
       final int RULE_SWITCHBLOCK_LBRACE_RBRACE3                           = 184;  // <SwitchBlock> ::= '{' <SwitchLabels> '}'
       final int RULE_SWITCHBLOCK_LBRACE_RBRACE4                           = 185;  // <SwitchBlock> ::= '{' '}'
       final int RULE_GRUPOSSWITCH                                         = 186;  // <GruposSwitch> ::= <SwitchLabels> <BlockSentencias>
       final int RULE_GRUPOSSWITCH2                                        = 187;  // <GruposSwitch> ::= <GruposSwitch> <SwitchLabels> <BlockSentencias>
       final int RULE_SWITCHLABELS                                         = 188;  // <SwitchLabels> ::= <SwitchLabel>
       final int RULE_SWITCHLABELS2                                        = 189;  // <SwitchLabels> ::= <SwitchLabels> <SwitchLabel>
       final int RULE_SWITCHLABEL_CASE_COLON                               = 190;  // <SwitchLabel> ::= case <ExpresionAsigna> ':'
       final int RULE_SWITCHLABEL_DEFAULT_COLON                            = 191;  // <SwitchLabel> ::= default ':'
       final int RULE_FORSENTENCIA_FOR_LPARAN_SEMI_SEMI_RPARAN             = 192;  // <ForSentencia> ::= for '(' <InicializarFor> ';' <ExpresionAsigna> ';' <ForActualizar> ')' <Sentencia>
       final int RULE_FORSENTENCIA_FOR_LPARAN_SEMI_SEMI_RPARAN2            = 193;  // <ForSentencia> ::= for '(' <InicializarFor> ';' <ExpresionAsigna> ';' ')' <Sentencia>
       final int RULE_FORSENTENCIA_FOR_LPARAN_SEMI_SEMI_RPARAN3            = 194;  // <ForSentencia> ::= for '(' <InicializarFor> ';' ';' <ForActualizar> ')' <Sentencia>
       final int RULE_FORSENTENCIA_FOR_LPARAN_SEMI_SEMI_RPARAN4            = 195;  // <ForSentencia> ::= for '(' <InicializarFor> ';' ';' ')' <Sentencia>
       final int RULE_FORSENTENCIA_FOR_LPARAN_SEMI_SEMI_RPARAN5            = 196;  // <ForSentencia> ::= for '(' ';' <ExpresionAsigna> ';' <ForActualizar> ')' <Sentencia>
       final int RULE_FORSENTENCIA_FOR_LPARAN_SEMI_SEMI_RPARAN6            = 197;  // <ForSentencia> ::= for '(' ';' <ExpresionAsigna> ';' ')' <Sentencia>
       final int RULE_FORSENTENCIA_FOR_LPARAN_SEMI_SEMI_RPARAN7            = 198;  // <ForSentencia> ::= for '(' ';' ';' <ForActualizar> ')' <Sentencia>
       final int RULE_FORSENTENCIA_FOR_LPARAN_SEMI_SEMI_RPARAN8            = 199;  // <ForSentencia> ::= for '(' ';' ';' ')' <Sentencia>
       final int RULE_FORSENTENCIAIFEXTENDIDO_FOR_LPARAN_SEMI_SEMI_RPARAN  = 200;  // <ForSentenciaIfExtendido> ::= for '(' <InicializarFor> ';' <ExpresionAsigna> ';' <ForActualizar> ')' <SentenciaIfExtendido>
       final int RULE_FORSENTENCIAIFEXTENDIDO_FOR_LPARAN_SEMI_SEMI_RPARAN2 = 201;  // <ForSentenciaIfExtendido> ::= for '(' <InicializarFor> ';' <ExpresionAsigna> ';' ')' <SentenciaIfExtendido>
       final int RULE_FORSENTENCIAIFEXTENDIDO_FOR_LPARAN_SEMI_SEMI_RPARAN3 = 202;  // <ForSentenciaIfExtendido> ::= for '(' <InicializarFor> ';' ';' <ForActualizar> ')' <SentenciaIfExtendido>
       final int RULE_FORSENTENCIAIFEXTENDIDO_FOR_LPARAN_SEMI_SEMI_RPARAN4 = 203;  // <ForSentenciaIfExtendido> ::= for '(' <InicializarFor> ';' ';' ')' <SentenciaIfExtendido>
       final int RULE_FORSENTENCIAIFEXTENDIDO_FOR_LPARAN_SEMI_SEMI_RPARAN5 = 204;  // <ForSentenciaIfExtendido> ::= for '(' ';' <ExpresionAsigna> ';' <ForActualizar> ')' <SentenciaIfExtendido>
       final int RULE_FORSENTENCIAIFEXTENDIDO_FOR_LPARAN_SEMI_SEMI_RPARAN6 = 205;  // <ForSentenciaIfExtendido> ::= for '(' ';' <ExpresionAsigna> ';' ')' <SentenciaIfExtendido>
       final int RULE_FORSENTENCIAIFEXTENDIDO_FOR_LPARAN_SEMI_SEMI_RPARAN7 = 206;  // <ForSentenciaIfExtendido> ::= for '(' ';' ';' <ForActualizar> ')' <SentenciaIfExtendido>
       final int RULE_FORSENTENCIAIFEXTENDIDO_FOR_LPARAN_SEMI_SEMI_RPARAN8 = 207;  // <ForSentenciaIfExtendido> ::= for '(' ';' ';' ')' <SentenciaIfExtendido>
       final int RULE_INICIALIZARFOR                                       = 208;  // <InicializarFor> ::= <ListadoSentenciaExpresion>
       final int RULE_INICIALIZARFOR2                                      = 209;  // <InicializarFor> ::= <Tipo> <DeclaradoresVariable>
       final int RULE_FORACTUALIZAR                                        = 210;  // <ForActualizar> ::= <ListadoSentenciaExpresion>
       final int RULE_LISTADOSENTENCIAEXPRESION                            = 211;  // <ListadoSentenciaExpresion> ::= <SentenciaExpresion>
       final int RULE_LISTADOSENTENCIAEXPRESION_COMMA                      = 212;  // <ListadoSentenciaExpresion> ::= <ListadoSentenciaExpresion> ',' <SentenciaExpresion>
       final int RULE_PRIMARY                                              = 213;  // <Primary> ::= <PrimaryNoNewArray>
       final int RULE_PRIMARY2                                             = 214;  // <Primary> ::= <CreacionArray>
       final int RULE_PRIMARYNONEWARRAY                                    = 215;  // <PrimaryNoNewArray> ::= <Literal>
       final int RULE_PRIMARYNONEWARRAY_THIS                               = 216;  // <PrimaryNoNewArray> ::= this
       final int RULE_PRIMARYNONEWARRAY_LPARAN_RPARAN                      = 217;  // <PrimaryNoNewArray> ::= '(' <ExpresionAsigna> ')'
       final int RULE_PRIMARYNONEWARRAY2                                   = 218;  // <PrimaryNoNewArray> ::= <CreacionInstancia>
       final int RULE_PRIMARYNONEWARRAY3                                   = 219;  // <PrimaryNoNewArray> ::= <AccesoCampo>
       final int RULE_PRIMARYNONEWARRAY4                                   = 220;  // <PrimaryNoNewArray> ::= <InvocacionMetodo>
       final int RULE_PRIMARYNONEWARRAY5                                   = 221;  // <PrimaryNoNewArray> ::= <AccesoArray>
       final int RULE_CREACIONINSTANCIA_NEW_LPARAN_RPARAN                  = 222;  // <CreacionInstancia> ::= new <Nombre> '(' <ListaArgumento> ')'
       final int RULE_CREACIONINSTANCIA_NEW_LPARAN_RPARAN2                 = 223;  // <CreacionInstancia> ::= new <Nombre> '(' ')'
       final int RULE_LISTAARGUMENTO                                       = 224;  // <ListaArgumento> ::= <ExpresionAsigna>
       final int RULE_LISTAARGUMENTO_COMMA                                 = 225;  // <ListaArgumento> ::= <ListaArgumento> ',' <ExpresionAsigna>
       final int RULE_CREACIONARRAY_NEW                                    = 226;  // <CreacionArray> ::= new <TipoPrimitivo> <ExprsCorchetes> <Corchetes>
       final int RULE_CREACIONARRAY_NEW2                                   = 227;  // <CreacionArray> ::= new <TipoPrimitivo> <ExprsCorchetes>
       final int RULE_CREACIONARRAY_NEW3                                   = 228;  // <CreacionArray> ::= new <Nombre> <ExprsCorchetes> <Corchetes>
       final int RULE_CREACIONARRAY_NEW4                                   = 229;  // <CreacionArray> ::= new <Nombre> <ExprsCorchetes>
       final int RULE_EXPRSCORCHETES                                       = 230;  // <ExprsCorchetes> ::= <ExprCorchetes>
       final int RULE_EXPRSCORCHETES2                                      = 231;  // <ExprsCorchetes> ::= <ExprsCorchetes> <ExprCorchetes>
       final int RULE_EXPRCORCHETES_LBRACKET_RBRACKET                      = 232;  // <ExprCorchetes> ::= '[' <ExpresionAsigna> ']'
       final int RULE_CORCHETES_LBRACKET_RBRACKET                          = 233;  // <Corchetes> ::= '[' ']'
       final int RULE_CORCHETES_LBRACKET_RBRACKET2                         = 234;  // <Corchetes> ::= <Corchetes> '[' ']'
       final int RULE_ACCESOCAMPO_DOT_ID                                   = 235;  // <AccesoCampo> ::= <Primary> '.' Id
       final int RULE_ACCESOCAMPO_SUPER_DOT_ID                             = 236;  // <AccesoCampo> ::= super '.' Id
       final int RULE_INVOCACIONMETODO_LPARAN_RPARAN                       = 237;  // <InvocacionMetodo> ::= <Nombre> '(' <ListaArgumento> ')'
       final int RULE_INVOCACIONMETODO_LPARAN_RPARAN2                      = 238;  // <InvocacionMetodo> ::= <Nombre> '(' ')'
       final int RULE_INVOCACIONMETODO_DOT_ID_LPARAN_RPARAN                = 239;  // <InvocacionMetodo> ::= <Primary> '.' Id '(' <ListaArgumento> ')'
       final int RULE_INVOCACIONMETODO_DOT_ID_LPARAN_RPARAN2               = 240;  // <InvocacionMetodo> ::= <Primary> '.' Id '(' ')'
       final int RULE_INVOCACIONMETODO_SUPER_DOT_ID_LPARAN_RPARAN          = 241;  // <InvocacionMetodo> ::= super '.' Id '(' <ListaArgumento> ')'
       final int RULE_INVOCACIONMETODO_SUPER_DOT_ID_LPARAN_RPARAN2         = 242;  // <InvocacionMetodo> ::= super '.' Id '(' ')'
       final int RULE_ACCESOARRAY_LBRACKET_RBRACKET                        = 243;  // <AccesoArray> ::= <Nombre> '[' <ExpresionAsigna> ']'
       final int RULE_ACCESOARRAY_LBRACKET_RBRACKET2                       = 244;  // <AccesoArray> ::= <PrimaryNoNewArray> '[' <ExpresionAsigna> ']'
       final int RULE_CASTEXPRESION_LPARAN_RPARAN                          = 245;  // <CastExpresion> ::= '(' <TipoPrimitivo> <Corchetes> ')' <UnarioExpresion>
       final int RULE_CASTEXPRESION_LPARAN_RPARAN2                         = 246;  // <CastExpresion> ::= '(' <TipoPrimitivo> ')' <UnarioExpresion>
       final int RULE_CASTEXPRESION_LPARAN_RPARAN3                         = 247;  // <CastExpresion> ::= '(' <ExpresionAsigna> ')' <UnarioExpresionOtra>
       final int RULE_CASTEXPRESION_LPARAN_RPARAN4                         = 248;  // <CastExpresion> ::= '(' <Nombre> <Corchetes> ')' <UnarioExpresionOtra>
       final int RULE_MULTEXPRESION                                        = 249;  // <MultExpresion> ::= <UnarioExpresion>
       final int RULE_MULTEXPRESION_TIMES                                  = 250;  // <MultExpresion> ::= <MultExpresion> '*' <UnarioExpresion>
       final int RULE_MULTEXPRESION_DIV                                    = 251;  // <MultExpresion> ::= <MultExpresion> '/' <UnarioExpresion>
       final int RULE_MULTEXPRESION_PERCENT                                = 252;  // <MultExpresion> ::= <MultExpresion> '%' <UnarioExpresion>
       final int RULE_ADDEXPRESION                                         = 253;  // <AddExpresion> ::= <MultExpresion>
       final int RULE_ADDEXPRESION_PLUS                                    = 254;  // <AddExpresion> ::= <AddExpresion> '+' <MultExpresion>
       final int RULE_ADDEXPRESION_MINUS                                   = 255;  // <AddExpresion> ::= <AddExpresion> '-' <MultExpresion>
       final int RULE_EXPRESIONCOMPARAR                                    = 256;  // <ExpresionComparar> ::= <AddExpresion>
       final int RULE_EXPRESIONCOMPARAR_LT                                 = 257;  // <ExpresionComparar> ::= <ExpresionComparar> '<' <AddExpresion>
       final int RULE_EXPRESIONCOMPARAR_GT                                 = 258;  // <ExpresionComparar> ::= <ExpresionComparar> '>' <AddExpresion>
       final int RULE_EXPRESIONCOMPARAR_LTEQ                               = 259;  // <ExpresionComparar> ::= <ExpresionComparar> '<=' <AddExpresion>
       final int RULE_EXPRESIONCOMPARAR_GTEQ                               = 260;  // <ExpresionComparar> ::= <ExpresionComparar> '>=' <AddExpresion>
       final int RULE_EXPRESIONCOMPARAR_INSTANCEOF                         = 261;  // <ExpresionComparar> ::= <ExpresionComparar> instanceof <TipoReferencia>
       final int RULE_EXPRESIONIGUAL                                       = 262;  // <ExpresionIgual> ::= <ExpresionComparar>
       final int RULE_EXPRESIONIGUAL_EQEQ                                  = 263;  // <ExpresionIgual> ::= <ExpresionIgual> '==' <ExpresionComparar>
       final int RULE_EXPRESIONIGUAL_EXCLAMEQ                              = 264;  // <ExpresionIgual> ::= <ExpresionIgual> '!=' <ExpresionComparar>
       final int RULE_ANDCONDICIONALEXPRESION                              = 265;  // <AndCondicionalExpresion> ::= <ExpresionIgual>
       final int RULE_ANDCONDICIONALEXPRESION_AMPAMP                       = 266;  // <AndCondicionalExpresion> ::= <AndCondicionalExpresion> '&&' <ExpresionIgual>
       final int RULE_ORCONDICIONALEXPRESION                               = 267;  // <OrCondicionalExpresion> ::= <AndCondicionalExpresion>
       final int RULE_ORCONDICIONALEXPRESION_PIPEPIPE                      = 268;  // <OrCondicionalExpresion> ::= <OrCondicionalExpresion> '||' <AndCondicionalExpresion>
       final int RULE_EXPRESIONCONDICIONAL                                 = 269;  // <ExpresionCondicional> ::= <OrCondicionalExpresion>
       final int RULE_EXPRESIONCONDICIONAL_QUESTION_COLON                  = 270;  // <ExpresionCondicional> ::= <OrCondicionalExpresion> '?' <ExpresionAsigna> ':' <ExpresionCondicional>
       final int RULE_POSFIJOEXPRESION                                     = 271;  // <PosfijoExpresion> ::= <Primary>
       final int RULE_POSFIJOEXPRESION2                                    = 272;  // <PosfijoExpresion> ::= <Nombre>
       final int RULE_POSFIJOEXPRESION_PLUSPLUS                            = 273;  // <PosfijoExpresion> ::= <PosfijoExpresion> '++'
       final int RULE_POSFIJOEXPRESION_MINUSMINUS                          = 274;  // <PosfijoExpresion> ::= <PosfijoExpresion> --
       final int RULE_UNARIOEXPRESION_PLUSPLUS                             = 275;  // <UnarioExpresion> ::= '++' <UnarioExpresion>
       final int RULE_UNARIOEXPRESION_MINUSMINUS                           = 276;  // <UnarioExpresion> ::= -- <UnarioExpresion>
       final int RULE_UNARIOEXPRESION_PLUS                                 = 277;  // <UnarioExpresion> ::= '+' <UnarioExpresion>
       final int RULE_UNARIOEXPRESION_MINUS                                = 278;  // <UnarioExpresion> ::= '-' <UnarioExpresion>
       final int RULE_UNARIOEXPRESION                                      = 279;  // <UnarioExpresion> ::= <UnarioExpresionOtra>
       final int RULE_UNARIOEXPRESIONOTRA                                  = 280;  // <UnarioExpresionOtra> ::= <PosfijoExpresion>
       final int RULE_UNARIOEXPRESIONOTRA2                                 = 281;  // <UnarioExpresionOtra> ::= <CastExpresion>
       final int RULE_EXPRESIONASIGNA                                      = 282;  // <ExpresionAsigna> ::= <ExpresionCondicional>
       final int RULE_EXPRESIONASIGNA2                                     = 283;  // <ExpresionAsigna> ::= <LeftSide> <OperadorAsignacion> <ExpresionAsigna>
       final int RULE_LEFTSIDE                                             = 284;  // <LeftSide> ::= <Nombre>
       final int RULE_LEFTSIDE2                                            = 285;  // <LeftSide> ::= <AccesoCampo>
       final int RULE_LEFTSIDE3                                            = 286;  // <LeftSide> ::= <AccesoArray>
       final int RULE_OPERADORASIGNACION_EQ                                = 287;  // <OperadorAsignacion> ::= '='
       final int RULE_OPERADORASIGNACION_TIMESEQ                           = 288;  // <OperadorAsignacion> ::= '*='
       final int RULE_OPERADORASIGNACION_DIVEQ                             = 289;  // <OperadorAsignacion> ::= '/='
       final int RULE_OPERADORASIGNACION_PERCENTEQ                         = 290;  // <OperadorAsignacion> ::= '%='
       final int RULE_OPERADORASIGNACION_PLUSEQ                            = 291;  // <OperadorAsignacion> ::= '+='
       final int RULE_OPERADORASIGNACION_MINUSEQ                           = 292;  // <OperadorAsignacion> ::= '-='
       final int RULE_CONTINUESENTENCIA_CONTINUE_ID_SEMI                   = 293;  // <ContinueSentencia> ::= continue Id ';'
       final int RULE_CONTINUESENTENCIA_CONTINUE_SEMI                      = 294;  // <ContinueSentencia> ::= continue ';'
       final int RULE_RETURNSENTENCIA_RETURN_SEMI                          = 295;  // <ReturnSentencia> ::= return <ExpresionAsigna> ';'
       final int RULE_RETURNSENTENCIA_RETURN_SEMI2                         = 296;  // <ReturnSentencia> ::= return ';'
       final int RULE_TRYSENTENCIA_TRY                                     = 297;  // <TrySentencia> ::= try <Block> <Catches>
       final int RULE_TRYSENTENCIA_TRY_FINALLY                             = 298;  // <TrySentencia> ::= try <Block> <Catches> finally <Block>
       final int RULE_TRYSENTENCIA_TRY_FINALLY2                            = 299;  // <TrySentencia> ::= try <Block> finally <Block>
       final int RULE_CATCHES_CATCH_LPARAN_RPARAN                          = 300;  // <Catches> ::= catch '(' <Tipo> <DeclaradorVariableId> ')' <Block>
       final int RULE_CATCHES_CATCH_LPARAN_RPARAN2                         = 301;  // <Catches> ::= <Catches> catch '(' <Tipo> <DeclaradorVariableId> ')' <Block>
       final int RULE_BREAKSENTENCIA_BREAK_ID_SEMI                         = 302;  // <BreakSentencia> ::= break Id ';'
       final int RULE_BREAKSENTENCIA_BREAK_SEMI                            = 303;  // <BreakSentencia> ::= break ';'
    };

    /**constante para el conteo de pasadas del compilador*/
    final int uno=1,dos=2,tres=3,cuatro=4;
    /**almacena los datos de la tabla de simbolos*/
    TablaSimbolos tabla=new TablaSimbolos();
    TablaObjetos tablaO=new TablaObjetos();
    /**se encarga de manejar el reporte de errores correspondientes*/
    Reporte errSem=new Reporte("c:\\cacheTomcat\\errSemanticos.htm"),
            errlex=new Reporte("c:\\cacheTomcat\\errLexicos.htm"),
            errSin=new Reporte("c:\\cacheTomcat\\errSintacticos.htm");
    /**flujo para crear el javascript temporal*/
    Escritor tmpJs=new Escritor("C:\\cacheTomcat\\tmpjs");

    /**
     * Da la orden para compilar el archivo recibido como parametro
     * @param archivos vector con las rutas absolutas de los archivos a compilar
     */
    public void compilar(Vector archivos){
        int pasada=uno,cantidad=archivos.size();
        for(pasada=uno;pasada<5;pasada++){
            if(pasada==cuatro){
                tmpJs.writeln("</style>\n<script type=\"text/javascript\">");
            }
            for(int i=0;i<cantidad;i++){
                String archivo=archivos.elementAt(i).toString();
                parsear(archivo,pasada);
            }
        }
        tablaO.generarDoc(tabla);
    }

    /***************************************************************
     * parsea un archivo.
     * funcionamiento del parser:
     * pasada 1: crear paquetes y crear clases en la tabla de simbolos, despues agregar los import a cada clase
     * pasada 2: agregar las clases a los paquetes y agregar la herencia a cada una
     * pasada 3: atributos/metodos a cada tipo de dato (clase) con sus modificadores y tipos
     * pasada 4: buscar errores faltantes
     * pasada 5: si no hay errores, generar codigo
     * @param archivo ruta absoluta del archivo a ser compilado.
     * @param pasada indica el numero de pasada actual del compilador
     ***************************************************************/
    void parsear(String archivo,int pasada)
    {
        //int tmpi=archivo.lastIndexOf('\\'),tmpf=archivo.lastIndexOf('.');
        String claseActual="";//archivo.substring(tmpi+1,tmpf);//nombre de la clase actual (ahora mejor lo inicializo al crear la clase)
        String paqueteActual="";//paquete actual
        String entorno="clase";//guarda el entorno actual, al entrar en una cabecera de metodo lo cambia al de ese metodo y al salir cambia a "clase"
        String tipoDatoActual="";//tipo de dato actual, usado para instanciar, se verifica si el tipo de dato es igual al declarado

       String textToParse = "", compiledGrammar = "";

       compiledGrammar="c:\\tablas.cgt";
       textToParse=archivo;

       GOLDParser parser = new GOLDParser();
       //parser.setTrimReductions(false);

       try
       {
          parser.loadCompiledGrammar(compiledGrammar);
          parser.openFile(textToParse);
       }
       catch(ParserException parse)
       {
          System.out.println("**PARSER ERROR**\n" + parse.toString());
          System.exit(1);
       }

       boolean done = false;
       int response = -1;

       while(!done)
       {
          try
            {
                  response = parser.parse();
            }
            catch(ParserException parse)
            {
                System.out.println("**PARSER ERROR**\n" + parse.toString());
                System.exit(1);
            }

            switch(response)
            {
               case gpMsgTokenRead:
                   /* A token was read by the parser. The Token Object can be accessed
                      through the CurrentToken() property:  Parser.CurrentToken */
                   break;

               case gpMsgReduction:
                   /* This message is returned when a rule was reduced by the parse engine.
                      The CurrentReduction property is assigned a Reduction object
                      containing the rule and its related tokens. You can reassign this
                      property to your own customized class. If this is not the case,
                      this message can be ignored and the Reduction object will be used
                      to store the parse tree.  */

                      switch(parser.currentReduction().getParentRule().getTableIndex())
                      {
                         case RuleConstants.RULE_PROGRAM_PACKAGE_SEMI:{
                            //<Program> ::= package <Nombre> ';' <DeclaracionesImport> <DeclaracionesTipo>
                             if(pasada==uno){
                                 Reduction r=(Reduction)parser.currentReduction().getToken(1).getData();
                                 Nodo n=(Nodo)r.getToken(0).getData();
                                 String tmp=n.getUnion(".");
                                 tabla.crearPaquete(tmp);
                                 paqueteActual=new String(tmp);
                                 //creando clase
                                 Reduction r2=(Reduction)parser.currentReduction().getToken(4).getData();
                                 Nodo n2=(Nodo)r2.getToken(0).getData();
                                 TipoDato t=null;
                                 if(n2.listado.elementAt(3)!=null)
                                     t=(TipoDato)n2.listado.elementAt(3);
                                 claseActual=(String)n2.listado.elementAt(2);
                                 tabla.crearTabla(paqueteActual, n2.listado.elementAt(0).toString(), n2.listado.elementAt(1).toString(), claseActual, t);
                                 //agregando import
                                 Reduction r3=(Reduction)parser.currentReduction().getToken(3).getData();
                                 Nodo n3=(Nodo)r3.getToken(0).getData();
                                 Iterator i=n3.listado.iterator();
                                 while(i.hasNext()){
                                     String sImp=(String)i.next();
                                     TipoDato tActual=tabla.getTabla(paqueteActual, claseActual);
                                     tActual.importar(sImp);
                                 }
                             }
                         }break;
                         case RuleConstants.RULE_PROGRAM_PACKAGE_SEMI2:{
                            //<Program> ::= package <Nombre> ';' <DeclaracionesImport>
                             if(pasada==uno){
                                 Reduction r=(Reduction)parser.currentReduction().getToken(1).getData();
                                 Nodo n=(Nodo)r.getToken(0).getData();
                                 String tmp=n.getUnion(".");
                                 tabla.crearPaquete(tmp);
                                 paqueteActual=new String(tmp);
                             }
                         }break;
                         case RuleConstants.RULE_PROGRAM_PACKAGE_SEMI3:{
                            //<Program> ::= package <Nombre> ';' <DeclaracionesTipo>
                             if(pasada==uno){
                                 Reduction r=(Reduction)parser.currentReduction().getToken(1).getData();
                                 Nodo n=(Nodo)r.getToken(0).getData();
                                 String tmp=n.getUnion(".");
                                 tabla.crearPaquete(tmp);
                                 paqueteActual=new String(tmp);
                                 //creando tabla
                                 Reduction r2=(Reduction)parser.currentReduction().getToken(3).getData();
                                 Nodo n2=(Nodo)r2.getToken(0).getData();
                                 TipoDato t=null;
                                 if(n2.listado.elementAt(3)!=null)
                                     t=(TipoDato)n2.listado.elementAt(3);
                                 claseActual=n2.listado.elementAt(2).toString();
                                 tabla.crearTabla(paqueteActual, n2.listado.elementAt(0).toString(), n2.listado.elementAt(1).toString(), claseActual, t);
                             }
                         }break;
                         case RuleConstants.RULE_PROGRAM_PACKAGE_SEMI4:{
                            //<Program> ::= package <Nombre> ';'
                             if(pasada==uno){
                                 Reduction r=(Reduction)parser.currentReduction().getToken(1).getData();
                                 Nodo n=(Nodo)r.getToken(0).getData();
                                 String tmp=n.getUnion(".");
                                 tabla.crearPaquete(tmp);
                                 paqueteActual=new String(tmp);
                             }
                         }break;
                         case RuleConstants.RULE_PROGRAM:{
                            //<Program> ::= <DeclaracionesImport> <DeclaracionesTipo>
                             if(pasada==uno){
                                 errSem.reportar("Linea 1: No se definio un paquete.");
                                 //creando tabla
                                 Reduction r2=(Reduction)parser.currentReduction().getToken(1).getData();
                                 Nodo n2=(Nodo)r2.getToken(0).getData();
                                 TipoDato t=null;
                                 if(n2.listado.elementAt(3)!=null)
                                     t=(TipoDato)n2.listado.elementAt(3);
                                 claseActual=(String)n2.listado.elementAt(2);
                                 tabla.crearTabla("", n2.listado.elementAt(0).toString(), n2.listado.elementAt(1).toString(), claseActual, t);
                                 //agregando import
                                 Reduction r3=(Reduction)parser.currentReduction().getToken(0).getData();
                                 Nodo n3=(Nodo)r3.getToken(0).getData();
                                 Iterator i=n3.listado.iterator();
                                 while(i.hasNext()){
                                     String sImp=(String)i.next();
                                     TipoDato tActual=tabla.getTabla(paqueteActual, claseActual);
                                     tActual.importar(sImp);
                                 }
                             }
                         }break;
                         case RuleConstants.RULE_PROGRAM2:{
                            //<Program> ::= <DeclaracionesImport>
                             if(pasada==uno){
                                 errSem.reportar("Linea 1: No se definio un paquete.");
                                 errSem.reportar("La clase esta vacia; se esperaba codigo.");
                                 //esto no se ejecuta
                             }
                         }break;
                         case RuleConstants.RULE_PROGRAM3:{
                            //<Program> ::= <DeclaracionesTipo>
                             if(pasada==uno){
                                 errSem.reportar("Linea 1: No se definio un paquete.");
                                 //esto no se ejecuta
                             }
                         }break;
                         case RuleConstants.RULE_PROGRAM4:{
                            //<Program> ::=
                             if(pasada==uno){
                                 errSem.reportar("Linea 1: No se definio un paquete.");
                                 errSem.reportar("La clase esta vacia; se esperaba codigo.");
                             }
                         }break;
                         case RuleConstants.RULE_DECLARACIONESIMPORT:{
                            //<DeclaracionesImport> ::= <DeclaracionImport>
                             Reduction r=(Reduction)parser.currentReduction().getToken(0).getData();
                             Nodo n=(Nodo)r.getToken(0).getData();
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_DECLARACIONESIMPORT2:{
                            //<DeclaracionesImport> ::= <DeclaracionesImport> <DeclaracionImport>
                             Reduction r1=(Reduction)parser.currentReduction().getToken(0).getData();
                             Reduction r2=(Reduction)parser.currentReduction().getToken(1).getData();
                             Nodo n1=(Nodo)r1.getToken(0).getData();
                             Nodo n2=(Nodo)r2.getToken(0).getData();
                             n1.add(n2.listado.firstElement());
                             parser.currentReduction().getToken(0).setData(n1);
                         }break;
                         case RuleConstants.RULE_DECLARACIONESTIPO:{
                            //<DeclaracionesTipo> ::= <DeclaracionTipo>
                             Reduction r=(Reduction)parser.currentReduction().getToken(0).getData();
                             Nodo n=(Nodo)r.getToken(0).getData();
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_DECLARACIONESTIPO2:{
                            //<DeclaracionesTipo> ::= <DeclaracionesTipo> <DeclaracionTipo>
                             errSem.reportar("Error. No se permite 2 clases en un archivo, no se puede compilar");
                             done=true;
                         }break;
                         case RuleConstants.RULE_DECLARACIONIMPORT_IMPORT_SEMI:{
                            //<DeclaracionImport> ::= import <Nombre> ';'
                             if(pasada==uno){
                                 Reduction rNom=(Reduction)parser.currentReduction().getToken(1).getData();
                                 Nodo nNom=(Nodo)rNom.getToken(0).getData();
                                 String s=nNom.getUnion(".");
                                 int iInd=s.lastIndexOf('.');
                                 if(iInd!=-1){
                                     String Paq=s.substring(0, iInd);
                                     String Nom=s.substring(iInd+1);
                                     if(tabla.getTabla(Paq, Nom)==null){
                                         errSem.reportar("Linea "+nNom.linea+": No se encuentra la clase "+s);
                                         parser.currentReduction().getToken(0).setData(new Nodo("",nNom.linea));
                                     }
                                     else{
                                         Nodo n=new Nodo(s,nNom.linea);
                                         parser.currentReduction().getToken(0).setData(n);
                                     }
                                 }else{
                                     errSem.reportar("Linea "+nNom.linea+": Se esperaba '.'");
                                     parser.currentReduction().getToken(0).setData(new Nodo("",nNom.linea));
                                 }
                             }
                         }break;
                         case RuleConstants.RULE_DECLARACIONIMPORT_IMPORT_DOT_TIMES_SEMI:{
                            //<DeclaracionImport> ::= import <Nombre> '.' '*' ';'
                             if(pasada==uno){
                                 Reduction rNom=(Reduction)parser.currentReduction().getToken(1).getData();
                                 Nodo nNom=(Nodo)rNom.getToken(0).getData();
                                 errSem.reportar("Linea "+nNom.linea+": No se permite importar de la forma paquete.*");
                             }
                         }break;
                         case RuleConstants.RULE_DECLARACIONTIPO:
                            //<DeclaracionTipo> ::= <DeclaracionClase>
                            break;
                         case RuleConstants.RULE_DECLARACIONTIPO2:
                            //<DeclaracionTipo> ::= <DeclaracionInterfaz>
                            break;
                         case RuleConstants.RULE_MODIFICADOR2_STATIC:{
                            //<Modificador2> ::= static
                             Nodo n=new Nodo("static",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_MODIFICADOR2_ABSTRACT:{
                            //<Modificador2> ::= abstract
                             Nodo n=new Nodo("abstract",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_MODIFICADOR2_FINAL:{
                            //<Modificador2> ::= final
                             Nodo n=new Nodo("final",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_MODIFICADOR2:{
                            //<Modificador2> ::= <Modificador>
                             Reduction r=(Reduction)parser.currentReduction().getToken(0).getData();
                             Nodo n=(Nodo)r.getToken(0).getData();
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_MODIFICADOR2_STATIC2:{
                            //<Modificador2> ::= <Modificador> static
                             Reduction r=(Reduction)parser.currentReduction().getToken(0).getData();
                             Nodo n=(Nodo)r.getToken(0).getData();
                             String s=n.listado.firstElement().toString();
                             Nodo n2=new Nodo(s+" static",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n2);
                         }break;
                         case RuleConstants.RULE_MODIFICADOR2_ABSTRACT2:{
                            //<Modificador2> ::= <Modificador> abstract
                             Reduction r=(Reduction)parser.currentReduction().getToken(0).getData();
                             Nodo n=(Nodo)r.getToken(0).getData();
                             String s=n.listado.firstElement().toString();
                             Nodo n2=new Nodo(s+" abstract",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n2);
                         }break;
                         case RuleConstants.RULE_MODIFICADOR2_FINAL2:{
                            //<Modificador2> ::= <Modificador> final
                             Reduction r=(Reduction)parser.currentReduction().getToken(0).getData();
                             Nodo n=(Nodo)r.getToken(0).getData();
                             String s=n.listado.firstElement().toString();
                             Nodo n2=new Nodo(s+" final",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n2);
                         }break;
                         case RuleConstants.RULE_MODIFICADOR_PUBLIC:{
                            //<Modificador> ::= public
                             Nodo n=new Nodo("public",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_MODIFICADOR_PROTECTED:{
                            //<Modificador> ::= protected
                             Nodo n=new Nodo("protected",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_MODIFICADOR_PRIVATE:{
                            //<Modificador> ::= private
                             Nodo n=new Nodo("private",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_DECLARACIONCLASE_CLASS_ID_EXTENDS_IMPLEMENTS:
                             //<DeclaracionClase> ::= <Modificador2> class Id extends <Nombre> implements <ListaInterfaces> <CuerpoClase>
                         case RuleConstants.RULE_DECLARACIONCLASE_CLASS_ID_EXTENDS:{
                            //<DeclaracionClase> ::= <Modificador2> class Id extends <Nombre> <CuerpoClase>
                             if(pasada==uno||pasada==dos){
                                 Reduction rMods=(Reduction)parser.currentReduction().getToken(0).getData();
                                 Reduction rExt=(Reduction)parser.currentReduction().getToken(4).getData();
                                 Nodo nMods=(Nodo)rMods.getToken(0).getData();
                                 Nodo nExt=(Nodo)rExt.getToken(0).getData();
                                    String[] sArray=nMods.listado.firstElement().toString().split(" ");
                                 String sM1=sArray[0],sM2=sArray.length==2?sArray[1]:"";
                                 String sId=(String)parser.currentReduction().getToken(2).getData();
                                 String sExt=nExt.getUnion(".");
                                 String sExtPaquete=new String(paqueteActual),sExtNombre=new String(sExt);
                                    int iInd=sExt.lastIndexOf('.');
                                    if(iInd!=-1){
                                        sExtPaquete=sExt.substring(0, iInd);
                                        sExtNombre=sExt.substring(iInd+1);
                                    }
                                 TipoDato t=null;
                                 if(pasada==dos){
                                     t=tabla.getTabla(sExtPaquete, sExtNombre);
                                     if(t==null){
                                         if(!tabla.tieneAcceso(paqueteActual, sId, sExt))
                                             errSem.reportar("Linea "+nMods.linea+": No se encuentra la clase "+sExt);
                                     }
                                 }

                                 TipoDato tmp=tabla.getTabla(paqueteActual, sId);
                                 if(tmp!=null)
                                     if(pasada==uno)
                                         errSem.reportar("Linea "+nMods.linea+": La clase "+sId+" ya existe en el paquete "+paqueteActual);
                                     else
                                         tmp.hereda=t;
                                 else{
                                     Nodo n=new Nodo(sM1,nMods.linea);
                                     n.add(sM2);
                                     n.add(sId);
                                     n.add(t);
                                     parser.currentReduction().getToken(0).setData(n);//tabla.crearTabla(paqueteActual, sM1, sM2, sId, t); -> lo crea mas arriba
                                 }
                             }
                         } break;
                         case RuleConstants.RULE_DECLARACIONCLASE_CLASS_ID_IMPLEMENTS:
                             //<DeclaracionClase> ::= <Modificador2> class Id implements <ListaInterfaces> <CuerpoClase>
                         case RuleConstants.RULE_DECLARACIONCLASE_CLASS_ID:{
                            //<DeclaracionClase> ::= <Modificador2> class Id <CuerpoClase>
                             if(pasada==uno){
                                 Reduction rMods=(Reduction)parser.currentReduction().getToken(0).getData();
                                 Nodo nMods=(Nodo)rMods.getToken(0).getData();
                                    String[] sArray=nMods.listado.firstElement().toString().split(" ");
                                 String sM1=sArray[0],sM2=sArray.length==2?sArray[1]:"";
                                 String sId=(String)parser.currentReduction().getToken(2).getData();
                                 if(tabla.getTabla(paqueteActual, sId)!=null)
                                     errSem.reportar("Linea "+nMods.linea+": La clase "+sId+" ya existe en el paquete "+paqueteActual);
                                 else{
                                     Nodo n=new Nodo(sM1,nMods.linea);
                                     n.add(sM2);
                                     n.add(sId);
                                     n.add(null);
                                     parser.currentReduction().getToken(0).setData(n);//tabla.crearTabla(paqueteActual, sM1, sM2, sId, null); -> lo crea mas arriba
                                 }
                             }
                         }break;
                         case RuleConstants.RULE_DECLARACIONCLASE_CLASS_ID_EXTENDS_IMPLEMENTS2:
                            //<DeclaracionClase> ::= class Id extends <Nombre> implements <ListaInterfaces> <CuerpoClase>
                         case RuleConstants.RULE_DECLARACIONCLASE_CLASS_ID_EXTENDS2:{
                            //<DeclaracionClase> ::= class Id extends <Nombre> <CuerpoClase>
                             if(pasada==uno||pasada==dos){
                                 Reduction rExt=(Reduction)parser.currentReduction().getToken(3).getData();
                                 Nodo nExt=(Nodo)rExt.getToken(0).getData();
                                 String sId=(String)parser.currentReduction().getToken(1).getData();
                                 String sExt=nExt.getUnion(".");
                                 String sExtPaquete=new String(paqueteActual),sExtNombre=new String(sExt);
                                    int iInd=sExt.lastIndexOf('.');
                                    if(iInd!=-1){
                                        sExtPaquete=sExt.substring(0, iInd);
                                        sExtNombre=sExt.substring(iInd+1);
                                    }
                                 TipoDato t=null;
                                 if(pasada==dos){
                                     t=tabla.getTabla(sExtPaquete, sExtNombre);
                                     if(t==null){
                                         if(!tabla.tieneAcceso(paqueteActual, sId, sExt))
                                             errSem.reportar("Linea "+nExt.linea+": No se encuentra la clase "+sExt);
                                     }
                                 }

                                 TipoDato tmp=tabla.getTabla(paqueteActual, sId);
                                 if(tmp!=null)
                                     if(pasada==uno)
                                         errSem.reportar("Linea "+nExt.linea+": La clase "+sId+" ya existe en el paquete "+paqueteActual);
                                     else
                                         tmp.hereda=t;
                                 else{
                                     Nodo n=new Nodo("",nExt.linea);
                                     n.add("");
                                     n.add(sId);
                                     n.add(t);
                                     parser.currentReduction().getToken(0).setData(n);//tabla.crearTabla(paqueteActual, "", "", sId, t); -> lo crea mas arriba
                                 }
                             }
                         }break;
                         case RuleConstants.RULE_DECLARACIONCLASE_CLASS_ID_IMPLEMENTS2:
                            //<DeclaracionClase> ::= class Id implements <ListaInterfaces> <CuerpoClase>
                         case RuleConstants.RULE_DECLARACIONCLASE_CLASS_ID2:{
                            //<DeclaracionClase> ::= class Id <CuerpoClase>
                             if(pasada==uno){
                                 String sId=(String)parser.currentReduction().getToken(1).getData();

                                 if(tabla.getTabla(paqueteActual, sId)!=null)
                                     errSem.reportar("La clase "+sId+" ya existe en el paquete "+paqueteActual);
                                 else{
                                     Nodo n=new Nodo("",0);
                                     n.add("");
                                     n.add(sId);
                                     n.add(null);
                                     parser.currentReduction().getToken(0).setData(n);//tabla.crearTabla(paqueteActual, "", "", sId, null); -> lo crea mas arriba
                                 }
                             }
                         }break;
                         case RuleConstants.RULE_LISTAINTERFACES:
                            //<ListaInterfaces> ::= <Nombre>
                            break;
                         case RuleConstants.RULE_LISTAINTERFACES_COMMA:
                            //<ListaInterfaces> ::= <ListaInterfaces> ',' <Nombre>
                            break;
                         case RuleConstants.RULE_CUERPOCLASE_LBRACE_RBRACE:
                            //<CuerpoClase> ::= '{' <DeclaracionesCuerpoClase> '}'
                            break;
                         case RuleConstants.RULE_CUERPOCLASE_LBRACE_RBRACE2:
                            //<CuerpoClase> ::= '{' '}'
                            break;
                         case RuleConstants.RULE_DECLARACIONESCUERPOCLASE:
                            //<DeclaracionesCuerpoClase> ::= <DeclaracionCuerpoClase>
                            break;
                         case RuleConstants.RULE_DECLARACIONESCUERPOCLASE2:
                            //<DeclaracionesCuerpoClase> ::= <DeclaracionesCuerpoClase> <DeclaracionCuerpoClase>
                            break;
                         case RuleConstants.RULE_DECLARACIONCUERPOCLASE:
                            //<DeclaracionCuerpoClase> ::= <DeclaracionMiembroClase>
                            break;
                         case RuleConstants.RULE_DECLARACIONCUERPOCLASE_STATIC:
                            //<DeclaracionCuerpoClase> ::= static <Block>
                            break;
                         case RuleConstants.RULE_DECLARACIONCUERPOCLASE2:
                            //<DeclaracionCuerpoClase> ::= <DeclaracionConstructor>
                            break;
                         case RuleConstants.RULE_DECLARACIONMIEMBROCLASE:
                            //<DeclaracionMiembroClase> ::= <DeclaracionCampo>
                            break;
                         case RuleConstants.RULE_DECLARACIONMIEMBROCLASE2:{
                            //<DeclaracionMiembroClase> ::= <CabeceraMetodo> <CuerpoMetodo>
                             entorno="clase";
                         }break;
                         case RuleConstants.RULE_DECLARACIONCAMPO_SEMI:{
                            //<DeclaracionCampo> ::= <Modificador2> <Tipo> <DeclaradoresVariable> ';'
                             if(pasada==tres){
                                 Reduction r1=(Reduction)parser.currentReduction().getToken(0).getData();
                                 Nodo n1=(Nodo)r1.getToken(0).getData();
                                 String s1=n1.listado.firstElement().toString();
                                 Reduction r2=(Reduction)parser.currentReduction().getToken(1).getData();
                                 Nodo n2=(Nodo)r2.getToken(0).getData();
                                 String s2=n2.getUnion("");
                                 Reduction r3=(Reduction)parser.currentReduction().getToken(2).getData();
                                 Nodo n3=(Nodo)r3.getToken(0).getData();
                                 Iterator i=n3.listado.iterator();
                                 TipoDato t=tabla.getTabla(paqueteActual, claseActual);
                                 int pos=tablaO.convertPos(s2);
                                 if(t!=null)
                                     while(i.hasNext()){
                                         Object tmp=i.next();
                                         t.agregar(s1, s2, tmp.toString(), false, "clase");
                                         tablaO.addItem(tmp.toString(), pos);
                                     }
                             }
                         }break;
                         case RuleConstants.RULE_DECLARACIONCAMPO_SEMI2:{
                            //<DeclaracionCampo> ::= <Tipo> <DeclaradoresVariable> ';'
                             if(pasada==tres){
                                 Reduction r1=(Reduction)parser.currentReduction().getToken(0).getData();
                                 Nodo n1=(Nodo)r1.getToken(0).getData();
                                 String s1=n1.getUnion("");
                                 Reduction r2=(Reduction)parser.currentReduction().getToken(1).getData();
                                 Nodo n2=(Nodo)r2.getToken(0).getData();
                                 Iterator i=n2.listado.iterator();
                                 TipoDato t=tabla.getTabla(paqueteActual, claseActual);
                                 int pos=tablaO.convertPos(s1);
                                 if(t!=null)
                                     while(i.hasNext()){
                                         Object tmp=i.next();
                                         t.agregar("", s1, tmp.toString(), false, "clase");
                                         tablaO.addItem(tmp.toString(), pos);
                                     }
                             }
                         }break;
                         case RuleConstants.RULE_DECLARADORESVARIABLE:
                            //<DeclaradoresVariable> ::= <DeclaradorVariable>
                            break;
                         case RuleConstants.RULE_DECLARADORESVARIABLE_COMMA:{
                            //<DeclaradoresVariable> ::= <DeclaradoresVariable> ',' <DeclaradorVariable>
                             if(pasada==tres){
                                 Reduction r1=(Reduction)parser.currentReduction().getToken(0).getData();
                                 Nodo n1=(Nodo)r1.getToken(0).getData();
                                 Reduction r2=(Reduction)parser.currentReduction().getToken(2).getData();
                                 Nodo n2=(Nodo)r2.getToken(0).getData();
                                 n1.add(n2.listado.firstElement());
                                 parser.currentReduction().getToken(0).setData(n1);
                             }
                         }break;
                         case RuleConstants.RULE_DECLARADORVARIABLE:
                            //<DeclaradorVariable> ::= <DeclaradorVariableId>
                            break;
                         case RuleConstants.RULE_DECLARADORVARIABLE_EQ:{
                            //<DeclaradorVariable> ::= <DeclaradorVariableId> '=' <VariableIni>
                             if(pasada==tres){
                                 Reduction rv=(Reduction)parser.currentReduction().getToken(0).getData();
                                 Nodo nv=(Nodo)rv.getToken(0).getData();
                                 String sv=nv.getUnion("");
                                 Nodo n=new Nodo(sv,nv.linea);
                                 parser.currentReduction().getToken(0).setData(n);
                             }
                             if(pasada==cuatro){
                                 //variableini traeria un nodo null si no coinciden tipos, o si no un nodo con vector vacio si solo es 'new xxx()', si no el vector esta lleno con cada parametro
                                 Reduction rId=(Reduction)parser.currentReduction().getToken(0).getData();
                                 Nodo nId=(Nodo)rId.getToken(0).getData();
                                 String sId=nId.getUnion("");
                                 Reduction rIni=(Reduction)parser.currentReduction().getToken(2).getData();
                                 Nodo nIni=(Nodo)rIni.getToken(0).getData();
                                 if(tipoDatoActual.startsWith("@")||tipoDatoActual.startsWith("!"))tipoDatoActual=tipoDatoActual.substring(1);
                                 if(nIni!=null && entorno.equals("initComponents")){
                                     tablaO.existeItem(sId);
                                     boolean paramsBien=tablaO.inicializar(tablaO.ultimoTipoBuscado, sId, nIni);
                                     if(!paramsBien)
                                         errSem.reportar("Linea "+nId.linea+": los parametros son erroneos");
                                 }//else ya se reporto el error (no coinciden tipos)
                                 tipoDatoActual="";
                             }
                         }break;
                         case RuleConstants.RULE_DECLARADORVARIABLEID_ID:{
                            //<DeclaradorVariableId> ::= Id
                             String s=(String)parser.currentReduction().getToken(0).getData();
                             Nodo n=new Nodo(s,parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_DECLARADORVARIABLEID_LBRACKET_RBRACKET:{
                            //<DeclaradorVariableId> ::= <DeclaradorVariableId> '[' ']'
                             Reduction r=(Reduction)parser.currentReduction().getToken(0).getData();
                             Nodo n=(Nodo)r.getToken(0).getData();
                             n.add("[]");
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_VARIABLEINI:
                            //<VariableIni> ::= <ExpresionAsigna>
                            break;
                         case RuleConstants.RULE_VARIABLEINI2:
                            //<VariableIni> ::= <ArrayIni>
                            break;
                         case RuleConstants.RULE_CABECERAMETODO:
                            //<CabeceraMetodo> ::= <Modificador2> <Tipo> <DeclaradorMetodo> <Throws>
                         case RuleConstants.RULE_CABECERAMETODO2:{
                        //<CabeceraMetodo> ::= <Modificador2> <Tipo> <DeclaradorMetodo>
                             if(pasada==tres){
                                 Reduction rMod=(Reduction)parser.currentReduction().getToken(0).getData();
                                 Nodo nMod=(Nodo)rMod.getToken(0).getData();
                                 Reduction rTipo=(Reduction)parser.currentReduction().getToken(1).getData();
                                 Nodo nTipo=(Nodo)rTipo.getToken(0).getData();
                                 Reduction rDM=(Reduction)parser.currentReduction().getToken(2).getData();
                                 Nodo nDM=(Nodo)rDM.getToken(0).getData();
                                 String sMod=nMod.listado.firstElement().toString();
                                 String sTipo=nTipo.getUnion("");
                                 String sDM=nDM.listado.firstElement().toString();
                                 if(!tabla.existeAtribMetodo(paqueteActual, claseActual, sDM, true, "clase"))
                                     tabla.agregarAtribMetodo(paqueteActual, claseActual, sMod, sTipo, sDM, true, "clase");
                                 else
                                     errSem.reportar("Linea "+nMod.linea+": ya existe el metodo "+sDM);
                             }
                         }break;
                         case RuleConstants.RULE_CABECERAMETODO3:
                            //<CabeceraMetodo> ::= <Tipo> <DeclaradorMetodo> <Throws>
                         case RuleConstants.RULE_CABECERAMETODO4:{
                            //<CabeceraMetodo> ::= <Tipo> <DeclaradorMetodo>
                             if(pasada==tres){
                                 Reduction rTipo=(Reduction)parser.currentReduction().getToken(0).getData();
                                 Nodo nTipo=(Nodo)rTipo.getToken(0).getData();
                                 Reduction rDM=(Reduction)parser.currentReduction().getToken(1).getData();
                                 Nodo nDM=(Nodo)rDM.getToken(0).getData();
                                 String sTipo=nTipo.getUnion("");
                                 String sDM=nDM.listado.firstElement().toString();
                                 if(!tabla.existeAtribMetodo(paqueteActual, claseActual, sDM, true, "clase"))
                                     tabla.agregarAtribMetodo(paqueteActual, claseActual, "", sTipo, sDM, true, "clase");
                                 else
                                     errSem.reportar("Linea "+nTipo.linea+": ya existe el metodo "+sDM);
                             }
                         }break;
                         case RuleConstants.RULE_CABECERAMETODO_VOID:
                            //<CabeceraMetodo> ::= <Modificador2> void <DeclaradorMetodo> <Throws>
                         case RuleConstants.RULE_CABECERAMETODO_VOID2:{
                            //<CabeceraMetodo> ::= <Modificador2> void <DeclaradorMetodo>
                             if(pasada==tres){
                                 Reduction rMod=(Reduction)parser.currentReduction().getToken(0).getData();
                                 Nodo nMod=(Nodo)rMod.getToken(0).getData();
                                 Reduction rDM=(Reduction)parser.currentReduction().getToken(2).getData();
                                 Nodo nDM=(Nodo)rDM.getToken(0).getData();
                                 String sMod=nMod.listado.firstElement().toString();
                                 String sDM=nDM.listado.firstElement().toString();
                                 if(!tabla.existeAtribMetodo(paqueteActual, claseActual, sDM, true, "clase"))
                                     tabla.agregarAtribMetodo(paqueteActual, claseActual, sMod, "void", sDM, true, "clase");
                                 else
                                     errSem.reportar("Linea "+nMod.linea+": ya existe el metodo "+sDM);
                             }
                         }break;
                         case RuleConstants.RULE_CABECERAMETODO_VOID3:
                            //<CabeceraMetodo> ::= void <DeclaradorMetodo> <Throws>
                         case RuleConstants.RULE_CABECERAMETODO_VOID4:{
                            //<CabeceraMetodo> ::= void <DeclaradorMetodo>
                             if(pasada==tres){
                                 Reduction rDM=(Reduction)parser.currentReduction().getToken(1).getData();
                                 Nodo nDM=(Nodo)rDM.getToken(0).getData();
                                 String sDM=nDM.listado.firstElement().toString();
                                 if(!tabla.existeAtribMetodo(paqueteActual, claseActual, sDM, true, "clase"))
                                     tabla.agregarAtribMetodo(paqueteActual, claseActual, "", "void", sDM, true, "clase");
                                 else
                                     errSem.reportar("Linea "+nDM.linea+": ya existe el metodo "+sDM);
                             }
                         }break;
                         case RuleConstants.RULE_DECLARADORMETODO_ID_LPARAN_RPARAN:{
                            //<DeclaradorMetodo> ::= Id '(' <ParamList> ')'
                             String s=(String)parser.currentReduction().getToken(0).getData();
                             entorno=new String(s);
                             Reduction r=(Reduction)parser.currentReduction().getToken(2).getData();
                             Nodo nr=(Nodo)r.getToken(0).getData();
                             String lista=nr.getUnion(",");
                             s+="("+lista+")";
                             Nodo n=new Nodo(s,nr.linea);
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_DECLARADORMETODO_ID_LPARAN_RPARAN2:{
                            //<DeclaradorMetodo> ::= Id '(' ')'
                             String s=(String)parser.currentReduction().getToken(0).getData();
                             entorno=new String(s);
                             s+="()";
                             Nodo n=new Nodo(s,parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_DECLARADORMETODO_LBRACKET_RBRACKET:
                            //<DeclaradorMetodo> ::= <DeclaradorMetodo> '[' ']'
                             //no se que es
                            break;
                         case RuleConstants.RULE_PARAMLIST:{
                            //<ParamList> ::= <Tipo> <DeclaradorVariableId>
                             Reduction r0=(Reduction)parser.currentReduction().getToken(0).getData();
                             Reduction r1=(Reduction)parser.currentReduction().getToken(1).getData();
                             Nodo n0=(Nodo)r0.getToken(0).getData();
                                String sTipo=n0.getUnion("");
                             Nodo n1=(Nodo)r1.getToken(0).getData();
                                String sId=n1.getUnion("");
                             String sr=(pasada==dos||pasada==tres)?sTipo:sTipo+" "+sId; //vuelta dos|tres: 'int', else: 'int a'
                             Nodo n=new Nodo(sr,n0.linea);
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_PARAMLIST_COMMA:{
                            //<ParamList> ::= <ParamList> ',' <Tipo> <DeclaradorVariableId>
                             Reduction rTipo=(Reduction)parser.currentReduction().getToken(2).getData();
                             Reduction rId=(Reduction)parser.currentReduction().getToken(3).getData();
                             Nodo nTipo=(Nodo)rTipo.getToken(0).getData();
                                String sTipo=nTipo.getUnion("");
                             Nodo nId=(Nodo)rId.getToken(0).getData();
                                String sId=nId.getUnion("");
                             String sr=(pasada==dos||pasada==tres)?sTipo:sTipo+" "+sId; //vuelta dos|tres: 'int', else: 'int a'

                             Reduction rParam=(Reduction)parser.currentReduction().getToken(0).getData();
                             Nodo n=(Nodo)rParam.getToken(0).getData();
                             n.add(sr);
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_CARACTER_CHARINDIRECTO:{
                            //<Caracter> ::= CharIndirecto
                             String s=(String)parser.currentReduction().getToken(0).getData();
                             Nodo n=new Nodo(s,parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_CARACTER_STESCAPECHAR:{
                            //<Caracter> ::= StEscapeChar
                             String s=(String)parser.currentReduction().getToken(0).getData();
                             Nodo n=new Nodo(s,parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_CARACTER_OCTALESCAPECHAR:{
                            //<Caracter> ::= OctalEscapeChar
                             String s=(String)parser.currentReduction().getToken(0).getData();
                             Nodo n=new Nodo(s,parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_CARACTER_HEXESCAPECHAR:{
                            //<Caracter> ::= HexEscapeChar
                             String s=(String)parser.currentReduction().getToken(0).getData();
                             Nodo n=new Nodo(s,parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_NUMDECIMAL_NUMCERO:{
                            //<numdecimal> ::= NumCero
                             String s=(String)parser.currentReduction().getToken(0).getData();
                             Nodo n=new Nodo(s,parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_NUMDECIMAL_NUM:{
                            //<numdecimal> ::= Num
                             String s=(String)parser.currentReduction().getToken(0).getData();
                             Nodo n=new Nodo(s,parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_FLOAT_NUMFLOAT:{
                            //<float> ::= NumFloat
                             String s=(String)parser.currentReduction().getToken(0).getData();
                             Nodo n=new Nodo(s,parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_FLOAT_NUMFLOATEXP:{
                            //<float> ::= NumFloatExp
                             String s=(String)parser.currentReduction().getToken(0).getData();
                             Nodo n=new Nodo(s,parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_INT:{
                            //<Int> ::= <numdecimal>
                             String s=(String)parser.currentReduction().getToken(0).getData();
                             Nodo n=new Nodo(s,parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_INT_NUMHEX:{
                            //<Int> ::= NumHex
                             String s=(String)parser.currentReduction().getToken(0).getData();
                             Nodo n=new Nodo(s,parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_INT_NUMOCTAL:{
                            //<Int> ::= NumOctal
                             String s=(String)parser.currentReduction().getToken(0).getData();
                             Nodo n=new Nodo(s,parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_LITERAL:
                            //<Literal> ::= <Int>
                         break;
                         case RuleConstants.RULE_LITERAL2:
                            //<Literal> ::= <float>
                            break;
                         case RuleConstants.RULE_LITERAL_BOOL:{
                            //<Literal> ::= Bool
                             String s=(String)parser.currentReduction().getToken(0).getData();
                             Nodo n=new Nodo(s,parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_LITERAL3:
                            //<Literal> ::= <Caracter>
                            break;
                         case RuleConstants.RULE_LITERAL_UNSTRING:{
                            //<Literal> ::= unString
                             String s=(String)parser.currentReduction().getToken(0).getData();
                             Nodo n=new Nodo(s,parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_LITERAL_EXPRNULL:{
                            //<Literal> ::= ExprNull
                             String s=(String)parser.currentReduction().getToken(0).getData();
                             Nodo n=new Nodo(s,parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_TIPO:
                            //<Tipo>  ::= <TipoPrimitivo>
                            break;
                         case RuleConstants.RULE_TIPO2:
                            //<Tipo> ::= <TipoReferencia>
                            break;
                         case RuleConstants.RULE_TIPOPRIMITIVO:
                            //<TipoPrimitivo> ::= <TipoNumerico>
                            break;
                         case RuleConstants.RULE_TIPOPRIMITIVO_BOOLEAN:{
                            //<TipoPrimitivo> ::= boolean
                             if(tipoDatoActual.equals("")) tipoDatoActual="boolean";
                             Nodo n=new Nodo("boolean",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_TIPOPRIMITIVO_STRING:{
                            //<TipoPrimitivo> ::= String
                             if(tipoDatoActual.equals("")) tipoDatoActual="String";
                             Nodo n=new Nodo("String",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_TIPOPRIMITIVO_VECTOR:{
                            //<TipoPrimitivo> ::= Vector
                             if(tipoDatoActual.equals("")) tipoDatoActual="Vector";
                             Nodo n=new Nodo("Vector",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_TIPONUMERICO:
                            //<TipoNumerico> ::= <TipoInt>
                            break;
                         case RuleConstants.RULE_TIPONUMERICO2:
                            //<TipoNumerico> ::= <TipoFlotante>
                            break;
                         case RuleConstants.RULE_TIPOINT_BYTE:{
                            //<TipoInt> ::= byte
                             if(tipoDatoActual.equals("")) tipoDatoActual="byte";
                             Nodo n=new Nodo("byte",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_TIPOINT_SHORT:{
                            //<TipoInt> ::= short
                             if(tipoDatoActual.equals("")) tipoDatoActual="short";
                             Nodo n=new Nodo("short",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_TIPOINT_INT:{
                            //<TipoInt> ::= int
                             if(tipoDatoActual.equals("")) tipoDatoActual="int";
                             Nodo n=new Nodo("int",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_TIPOINT_LONG:{
                            //<TipoInt> ::= long
                             if(tipoDatoActual.equals("")) tipoDatoActual="long";
                             Nodo n=new Nodo("long",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_TIPOINT_CHAR:{
                            //<TipoInt> ::= char
                             if(tipoDatoActual.equals("")) tipoDatoActual="char";
                             Nodo n=new Nodo("char",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_TIPOFLOTANTE_FLOAT:{
                            //<TipoFlotante> ::= float
                             if(tipoDatoActual.equals("")) tipoDatoActual="float";
                             Nodo n=new Nodo("float",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_TIPOFLOTANTE_DOUBLE:{
                            //<TipoFlotante> ::= double
                             if(tipoDatoActual.equals("")) tipoDatoActual="double";
                             Nodo n=new Nodo("double",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_TIPOREFERENCIA:
                            //<TipoReferencia> ::= <Nombre>
                            break;
                         case RuleConstants.RULE_TIPOREFERENCIA2:
                            //<TipoReferencia> ::= <TipoArray>
                            break;
                         case RuleConstants.RULE_TIPOARRAY_LBRACKET_RBRACKET:{
                            //<TipoArray> ::= <TipoPrimitivo> '[' ']'
                             Reduction r=(Reduction)parser.currentReduction().getToken(0).getData();
                             Nodo n=(Nodo)r.getToken(0).getData();
                             n.add("[]");
                             if(tipoDatoActual.equals("")) tipoDatoActual="!"+n.getUnion("");
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_TIPOARRAY_LBRACKET_RBRACKET2:{
                            //<TipoArray> ::= <Nombre> '[' ']'
                             Reduction r=(Reduction)parser.currentReduction().getToken(0).getData();
                             Nodo n=(Nodo)r.getToken(0).getData();
                             n.add("[]");
                             if(tipoDatoActual.equals("")) tipoDatoActual="!"+n.getUnion("");
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_TIPOARRAY_LBRACKET_RBRACKET3:{
                            //<TipoArray> ::= <TipoArray> '[' ']'
                             Reduction r=(Reduction)parser.currentReduction().getToken(0).getData();
                             Nodo n=(Nodo)r.getToken(0).getData();
                             n.add("[]");
                             if(tipoDatoActual.equals("") || tipoDatoActual.startsWith("!")) tipoDatoActual="!"+n.getUnion("");
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_NOMBRE:{
                            //<Nombre> ::= <NombreSimple>
                             Reduction r=(Reduction)parser.currentReduction().getToken(0).getData();
                             Nodo n=(Nodo)r.getToken(0).getData();
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_NOMBRE2:{
                            //<Nombre> ::= <NombreClasificado>
                             Reduction r=(Reduction)parser.currentReduction().getToken(0).getData();
                             Nodo n=(Nodo)r.getToken(0).getData();
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_NOMBRESIMPLE_ID:{
                            //<NombreSimple> ::= Id
                             String s=(String)parser.currentReduction().getToken(0).getData();
                             if(tipoDatoActual.equals("")) tipoDatoActual="@"+s;
                             Nodo n=new Nodo(s,parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_NOMBRECLASIFICADO_DOT_ID:{
                            //<NombreClasificado> ::= <Nombre> '.' Id
                             Reduction r=(Reduction)parser.currentReduction().getToken(0).getData();
                             Nodo n=(Nodo)r.getToken(0).getData();
                             String s=(String)parser.currentReduction().getToken(2).getData();
                             n.add(s);
                             if(tipoDatoActual.equals("") || tipoDatoActual.startsWith("@")) tipoDatoActual="@"+n.getUnion(".");
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_THROWS_THROWS:{
                            //<Throws> ::= throws <ListaTipoClase>
                             Reduction r1=(Reduction)parser.currentReduction().getToken(1).getData();
                             Nodo n1=(Nodo)r1.getToken(0).getData();
                             if(n1.listado.firstElement().equals("#@lista")){
                                 n1.listado.removeElementAt(0);
                                 ListIterator li=n1.get();
                                 while(li.hasNext()){
                                     String tmp=(String)li.next();
                                     if(!tabla.tieneAcceso(paqueteActual, claseActual, tmp))
                                         errSem.reportar("Linea "+n1.linea+": No se encuentra la clase "+tmp);
                                 }
                             }else{
                                 String s=n1.getUnion(".");
                                 if(!tabla.tieneAcceso(paqueteActual, claseActual, s))
                                    errSem.reportar("Linea "+n1.linea+": No se encuentra la clase "+s);
                             }
                         }break;
                         case RuleConstants.RULE_LISTATIPOCLASE:
                            //<ListaTipoClase> ::= <Nombre>
                            break;
                         case RuleConstants.RULE_LISTATIPOCLASE_COMMA:{
                            //<ListaTipoClase> ::= <ListaTipoClase> ',' <Nombre>
                             Reduction r1=(Reduction)parser.currentReduction().getToken(0).getData();
                             Nodo n1=(Nodo)r1.getToken(0).getData();
                                 if(!n1.listado.firstElement().toString().equals("#@lista")){
                                     String s1=n1.getUnion(".");
                                     int l=n1.linea;
                                     n1=new Nodo("#@lista",l);
                                     n1.add(s1);
                                 }
                             Reduction r2=(Reduction)parser.currentReduction().getToken(2).getData();
                             Nodo n2=(Nodo)r2.getToken(0).getData();
                             String s2=n2.getUnion(".");
                             n1.add(s2);
                             parser.currentReduction().getToken(0).setData(n1);
                         }break;
                         case RuleConstants.RULE_CUERPOMETODO:
                            //<CuerpoMetodo> ::= <Block>
                            break;
                         case RuleConstants.RULE_CUERPOMETODO_SEMI:
                            //<CuerpoMetodo> ::= ';'
                         break;
                         case RuleConstants.RULE_DECLARACIONCONSTRUCTOR:
                            //<DeclaracionConstructor> ::= <Modificador2> <ConstructorDeclarator> <Throws> <CuerpoConstructor>
                         case RuleConstants.RULE_DECLARACIONCONSTRUCTOR2:{
                            //<DeclaracionConstructor> ::= <Modificador2> <ConstructorDeclarator> <CuerpoConstructor>
                             if(pasada==dos){
                                 Reduction rMod=(Reduction)parser.currentReduction().getToken(0).getData();
                                 Nodo nMod=(Nodo)rMod.getToken(0).getData();
                                 String sMod=nMod.listado.firstElement().toString();
                                 String[] sArray=sMod.split(" ");
                                 if(sArray.length==2)
                                     errSem.reportar("Linea "+nMod.linea+": El constructor no puede tener el modificador "+sArray[1]);
                                 if(!sArray[0].startsWith("p"))
                                     errSem.reportar("Linea "+nMod.linea+": El constructor no puede tener el modificador "+sArray[0]);
                                 else{
                                     Reduction rDec=(Reduction)parser.currentReduction().getToken(1).getData();
                                     Nodo nDec=(Nodo)rDec.getToken(0).getData();
                                     String sDec=nDec.listado.firstElement().toString();
                                     tabla.agregarTipo(paqueteActual, sDec);
                                 }
                             }
                         }break;
                         case RuleConstants.RULE_DECLARACIONCONSTRUCTOR3:
                            //<DeclaracionConstructor> ::= <ConstructorDeclarator> <Throws> <CuerpoConstructor>
                         case RuleConstants.RULE_DECLARACIONCONSTRUCTOR4:{
                            //<DeclaracionConstructor> ::= <ConstructorDeclarator> <CuerpoConstructor>
                             if(pasada==dos){
                                 Reduction rDec=(Reduction)parser.currentReduction().getToken(0).getData();
                                 Nodo nDec=(Nodo)rDec.getToken(0).getData();
                                 String sDec=nDec.listado.firstElement().toString();
                                 tabla.agregarTipo(paqueteActual, sDec);
                             }
                         }break;
                         case RuleConstants.RULE_CONSTRUCTORDECLARATOR_LPARAN_RPARAN:{
                            //<ConstructorDeclarator> ::= <NombreSimple> '(' <ParamList> ')'
                             Reduction rNom=(Reduction)parser.currentReduction().getToken(0).getData();
                             Reduction rParam=(Reduction)parser.currentReduction().getToken(2).getData();
                             Nodo nNom=(Nodo)rNom.getToken(0).getData();
                             Nodo nParam=(Nodo)rParam.getToken(0).getData();
                             String sNom=nNom.listado.firstElement().toString();
                             entorno=new String(sNom);
                             String sParam=nParam.getUnion(",");
                             Nodo n=new Nodo(sNom+"("+sParam+")",nNom.linea);
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_CONSTRUCTORDECLARATOR_LPARAN_RPARAN2:{
                            //<ConstructorDeclarator> ::= <NombreSimple> '(' ')'
                             Reduction rNom=(Reduction)parser.currentReduction().getToken(0).getData();
                             Nodo nNom=(Nodo)rNom.getToken(0).getData();
                             String sNom=nNom.listado.firstElement().toString();
                             entorno=new String(sNom);
                             Nodo n=new Nodo(sNom+"()",nNom.linea);
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_CUERPOCONSTRUCTOR_LBRACE_RBRACE:{
                            //<CuerpoConstructor> ::= '{' <InvoExplicitaConstructor> <BlockSentencias> '}'
                             entorno="clase";
                         }break;
                         case RuleConstants.RULE_CUERPOCONSTRUCTOR_LBRACE_RBRACE2:{
                            //<CuerpoConstructor> ::= '{' <InvoExplicitaConstructor> '}'
                             entorno="clase";
                         }break;
                         case RuleConstants.RULE_CUERPOCONSTRUCTOR_LBRACE_RBRACE3:{
                            //<CuerpoConstructor> ::= '{' <BlockSentencias> '}'
                             entorno="clase";
                         }break;
                         case RuleConstants.RULE_CUERPOCONSTRUCTOR_LBRACE_RBRACE4:{
                            //<CuerpoConstructor> ::= '{' '}'
                             entorno="clase";
                         }break;
                         case RuleConstants.RULE_INVOEXPLICITACONSTRUCTOR_THIS_LPARAN_RPARAN_SEMI:
                            //<InvoExplicitaConstructor> ::= this '(' <ListaArgumento> ')' ';'
                            break;
                         case RuleConstants.RULE_INVOEXPLICITACONSTRUCTOR_THIS_LPARAN_RPARAN_SEMI2:
                            //<InvoExplicitaConstructor> ::= this '(' ')' ';'
                            break;
                         case RuleConstants.RULE_INVOEXPLICITACONSTRUCTOR_SUPER_LPARAN_RPARAN_SEMI:
                            //<InvoExplicitaConstructor> ::= super '(' <ListaArgumento> ')' ';'
                            break;
                         case RuleConstants.RULE_INVOEXPLICITACONSTRUCTOR_SUPER_LPARAN_RPARAN_SEMI2:
                            //<InvoExplicitaConstructor> ::= super '(' ')' ';'
                            break;
                         case RuleConstants.RULE_DECLARACIONINTERFAZ_INTERFACE_ID:
                            //<DeclaracionInterfaz> ::= <Modificador2> interface Id <ExtendsInterfaces> <CuerpoInterfaz>
                            break;
                         case RuleConstants.RULE_DECLARACIONINTERFAZ_INTERFACE_ID2:
                            //<DeclaracionInterfaz> ::= <Modificador2> interface Id <CuerpoInterfaz>
                            break;
                         case RuleConstants.RULE_DECLARACIONINTERFAZ_INTERFACE_ID3:
                            //<DeclaracionInterfaz> ::= interface Id <ExtendsInterfaces> <CuerpoInterfaz>
                            break;
                         case RuleConstants.RULE_DECLARACIONINTERFAZ_INTERFACE_ID4:
                            //<DeclaracionInterfaz> ::= interface Id <CuerpoInterfaz>
                            break;
                         case RuleConstants.RULE_EXTENDSINTERFACES_EXTENDS:
                            //<ExtendsInterfaces> ::= extends <Nombre>
                            break;
                         case RuleConstants.RULE_EXTENDSINTERFACES_COMMA:
                            //<ExtendsInterfaces> ::= <ExtendsInterfaces> ',' <Nombre>
                            break;
                         case RuleConstants.RULE_CUERPOINTERFAZ_LBRACE_RBRACE:
                            //<CuerpoInterfaz> ::= '{' <DeclaracionesMiembroInterfaz> '}'
                            break;
                         case RuleConstants.RULE_CUERPOINTERFAZ_LBRACE_RBRACE2:
                            //<CuerpoInterfaz> ::= '{' '}'
                            break;
                         case RuleConstants.RULE_DECLARACIONESMIEMBROINTERFAZ:
                            //<DeclaracionesMiembroInterfaz> ::= <DeclaracionMiembroInterfaz>
                            break;
                         case RuleConstants.RULE_DECLARACIONESMIEMBROINTERFAZ2:
                            //<DeclaracionesMiembroInterfaz> ::= <DeclaracionesMiembroInterfaz> <DeclaracionMiembroInterfaz>
                            break;
                         case RuleConstants.RULE_DECLARACIONMIEMBROINTERFAZ:
                            //<DeclaracionMiembroInterfaz> ::= <DeclaracionCampo>
                            break;
                         case RuleConstants.RULE_DECLARACIONMIEMBROINTERFAZ2:
                            //<DeclaracionMiembroInterfaz> ::= <DeclaracionMetodoAbstracto>
                            break;
                         case RuleConstants.RULE_DECLARACIONMETODOABSTRACTO_SEMI:
                            //<DeclaracionMetodoAbstracto> ::= <CabeceraMetodo> ';'
                            break;
                         case RuleConstants.RULE_ARRAYINI_LBRACE_COMMA_RBRACE:
                            //<ArrayIni> ::= '{' <VariableInis> ',' '}'
                            break;
                         case RuleConstants.RULE_ARRAYINI_LBRACE_RBRACE:
                            //<ArrayIni> ::= '{' <VariableInis> '}'
                            break;
                         case RuleConstants.RULE_ARRAYINI_LBRACE_COMMA_RBRACE2:
                            //<ArrayIni> ::= '{' ',' '}'
                            break;
                         case RuleConstants.RULE_ARRAYINI_LBRACE_RBRACE2:
                            //<ArrayIni> ::= '{' '}'
                            break;
                         case RuleConstants.RULE_VARIABLEINIS:
                            //<VariableInis> ::= <VariableIni>
                            break;
                         case RuleConstants.RULE_VARIABLEINIS_COMMA:
                            //<VariableInis> ::= <VariableInis> ',' <VariableIni>
                            break;
                         case RuleConstants.RULE_BLOCK_LBRACE_RBRACE:
                            //<Block> ::= '{' <BlockSentencias> '}'
                            break;
                         case RuleConstants.RULE_BLOCK_LBRACE_RBRACE2:
                            //<Block> ::= '{' '}'
                            break;
                         case RuleConstants.RULE_BLOCKSENTENCIAS:
                            //<BlockSentencias> ::= <BlockSentencia>
                            break;
                         case RuleConstants.RULE_BLOCKSENTENCIAS2:
                            //<BlockSentencias> ::= <BlockSentencias> <BlockSentencia>
                            break;
                         case RuleConstants.RULE_BLOCKSENTENCIA_SEMI:
                            //<BlockSentencia> ::= <Tipo> <DeclaradoresVariable> ';'
                            break;
                         case RuleConstants.RULE_BLOCKSENTENCIA:
                            //<BlockSentencia> ::= <Sentencia>
                            break;
                         case RuleConstants.RULE_SENTENCIA:
                            //<Sentencia> ::= <SentenciaSinSubsentencia>
                            break;
                         case RuleConstants.RULE_SENTENCIA_ID_COLON:
                            //<Sentencia> ::= Id ':' <Sentencia>
                            break;
                         case RuleConstants.RULE_SENTENCIA_IF_LPARAN_RPARAN:
                            //<Sentencia> ::= if '(' <ExpresionAsigna> ')' <Sentencia>
                            break;
                         case RuleConstants.RULE_SENTENCIA_IF_LPARAN_RPARAN_ELSE:
                            //<Sentencia> ::= if '(' <ExpresionAsigna> ')' <SentenciaIfExtendido> else <Sentencia>
                            break;
                         case RuleConstants.RULE_SENTENCIA_WHILE_LPARAN_RPARAN:
                            //<Sentencia> ::= while '(' <ExpresionAsigna> ')' <Sentencia>
                            break;
                         case RuleConstants.RULE_SENTENCIA2:
                            //<Sentencia> ::= <ForSentencia>
                            break;
                         case RuleConstants.RULE_SENTENCIAIFEXTENDIDO:
                            //<SentenciaIfExtendido> ::= <SentenciaSinSubsentencia>
                            break;
                         case RuleConstants.RULE_SENTENCIAIFEXTENDIDO_ID_COLON:
                            //<SentenciaIfExtendido> ::= Id ':' <SentenciaIfExtendido>
                            break;
                         case RuleConstants.RULE_SENTENCIAIFEXTENDIDO_IF_LPARAN_RPARAN_ELSE:
                            //<SentenciaIfExtendido> ::= if '(' <ExpresionAsigna> ')' <SentenciaIfExtendido> else <SentenciaIfExtendido>
                            break;
                         case RuleConstants.RULE_SENTENCIAIFEXTENDIDO_WHILE_LPARAN_RPARAN:
                            //<SentenciaIfExtendido> ::= while '(' <ExpresionAsigna> ')' <SentenciaIfExtendido>
                            break;
                         case RuleConstants.RULE_SENTENCIAIFEXTENDIDO2:
                            //<SentenciaIfExtendido> ::= <ForSentenciaIfExtendido>
                            break;
                         case RuleConstants.RULE_SENTENCIASINSUBSENTENCIA:
                            //<SentenciaSinSubsentencia> ::= <Block>
                            break;
                         case RuleConstants.RULE_SENTENCIASINSUBSENTENCIA_SEMI:
                            //<SentenciaSinSubsentencia> ::= ';'
                            break;
                         case RuleConstants.RULE_SENTENCIASINSUBSENTENCIA_SEMI2:
                            //<SentenciaSinSubsentencia> ::= <SentenciaExpresion> ';'
                            break;
                         case RuleConstants.RULE_SENTENCIASINSUBSENTENCIA_SWITCH_LPARAN_RPARAN:
                            //<SentenciaSinSubsentencia> ::= switch '(' <ExpresionAsigna> ')' <SwitchBlock>
                            break;
                         case RuleConstants.RULE_SENTENCIASINSUBSENTENCIA_DO_WHILE_LPARAN_RPARAN_SEMI:
                            //<SentenciaSinSubsentencia> ::= do <Sentencia> while '(' <ExpresionAsigna> ')' ';'
                            break;
                         case RuleConstants.RULE_SENTENCIASINSUBSENTENCIA2:
                            //<SentenciaSinSubsentencia> ::= <BreakSentencia>
                            break;
                         case RuleConstants.RULE_SENTENCIASINSUBSENTENCIA3:
                            //<SentenciaSinSubsentencia> ::= <ContinueSentencia>
                            break;
                         case RuleConstants.RULE_SENTENCIASINSUBSENTENCIA4:
                            //<SentenciaSinSubsentencia> ::= <ReturnSentencia>
                            break;
                         case RuleConstants.RULE_SENTENCIASINSUBSENTENCIA_SYNCHRONIZED_LPARAN_RPARAN:
                            //<SentenciaSinSubsentencia> ::= synchronized '(' <ExpresionAsigna> ')' <Block>
                            break;
                         case RuleConstants.RULE_SENTENCIASINSUBSENTENCIA_THROW_SEMI:
                            //<SentenciaSinSubsentencia> ::= throw <ExpresionAsigna> ';'
                            break;
                         case RuleConstants.RULE_SENTENCIASINSUBSENTENCIA5:
                            //<SentenciaSinSubsentencia> ::= <TrySentencia>
                            break;
                         case RuleConstants.RULE_SENTENCIAEXPRESION:{
                            //<SentenciaExpresion> ::= <LeftSide> <OperadorAsignacion> <ExpresionAsigna>
                             if(pasada==cuatro){
                                 //variableini traeria un nodo null si no coinciden tipos, o si no un nodo con vector vacio si solo es 'new xxx()', si no el vector esta lleno con cada parametro
                                 Reduction rOp=(Reduction)parser.currentReduction().getToken(1).getData();
                                 Nodo nOp=(Nodo)rOp.getToken(0).getData();
                                 String sOp=nOp.listado.firstElement().toString();
                                 Reduction rId=(Reduction)parser.currentReduction().getToken(0).getData();
                                 Nodo nId=(Nodo)rId.getToken(0).getData();
                                 String sId=nId.getUnion("");
                                 Reduction rIni=(Reduction)parser.currentReduction().getToken(2).getData();
                                 Nodo nIni=(Nodo)rIni.getToken(0).getData();
                                 if(tipoDatoActual.startsWith("@")||tipoDatoActual.startsWith("!"))tipoDatoActual=tipoDatoActual.substring(1);
                                 if(nIni!=null && sOp.equals("=") && entorno.equals("initComponents")){
                                     tablaO.existeItem(sId);
                                     boolean paramsBien=tablaO.inicializar(tablaO.ultimoTipoBuscado, sId, nIni);
                                     if(!paramsBien)
                                         errSem.reportar("Linea "+nId.linea+": los parametros son erroneos");
                                 }//else ya se reporto el error (no coinciden tipos)
                                 tipoDatoActual="";
                             }
                         }break;
                         case RuleConstants.RULE_SENTENCIAEXPRESION_PLUSPLUS:
                            //<SentenciaExpresion> ::= '++' <UnarioExpresion>
                            break;
                         case RuleConstants.RULE_SENTENCIAEXPRESION_MINUSMINUS:
                            //<SentenciaExpresion> ::= -- <UnarioExpresion>
                            break;
                         case RuleConstants.RULE_SENTENCIAEXPRESION_PLUSPLUS2:
                            //<SentenciaExpresion> ::= <PosfijoExpresion> '++'
                            break;
                         case RuleConstants.RULE_SENTENCIAEXPRESION_MINUSMINUS2:
                            //<SentenciaExpresion> ::= <PosfijoExpresion> --
                            break;
                         case RuleConstants.RULE_SENTENCIAEXPRESION2:
                            //<SentenciaExpresion> ::= <InvocacionMetodo>
                            break;
                         case RuleConstants.RULE_SENTENCIAEXPRESION3:
                            //<SentenciaExpresion> ::= <CreacionInstancia>
                            break;
                         case RuleConstants.RULE_SWITCHBLOCK_LBRACE_RBRACE:
                            //<SwitchBlock> ::= '{' <GruposSwitch> <SwitchLabels> '}'
                            break;
                         case RuleConstants.RULE_SWITCHBLOCK_LBRACE_RBRACE2:
                            //<SwitchBlock> ::= '{' <GruposSwitch> '}'
                            break;
                         case RuleConstants.RULE_SWITCHBLOCK_LBRACE_RBRACE3:
                            //<SwitchBlock> ::= '{' <SwitchLabels> '}'
                            break;
                         case RuleConstants.RULE_SWITCHBLOCK_LBRACE_RBRACE4:
                            //<SwitchBlock> ::= '{' '}'
                            break;
                         case RuleConstants.RULE_GRUPOSSWITCH:
                            //<GruposSwitch> ::= <SwitchLabels> <BlockSentencias>
                            break;
                         case RuleConstants.RULE_GRUPOSSWITCH2:
                            //<GruposSwitch> ::= <GruposSwitch> <SwitchLabels> <BlockSentencias>
                            break;
                         case RuleConstants.RULE_SWITCHLABELS:
                            //<SwitchLabels> ::= <SwitchLabel>
                            break;
                         case RuleConstants.RULE_SWITCHLABELS2:
                            //<SwitchLabels> ::= <SwitchLabels> <SwitchLabel>
                            break;
                         case RuleConstants.RULE_SWITCHLABEL_CASE_COLON:
                            //<SwitchLabel> ::= case <ExpresionAsigna> ':'
                            break;
                         case RuleConstants.RULE_SWITCHLABEL_DEFAULT_COLON:
                            //<SwitchLabel> ::= default ':'
                            break;
                         case RuleConstants.RULE_FORSENTENCIA_FOR_LPARAN_SEMI_SEMI_RPARAN:
                            //<ForSentencia> ::= for '(' <InicializarFor> ';' <ExpresionAsigna> ';' <ForActualizar> ')' <Sentencia>
                            break;
                         case RuleConstants.RULE_FORSENTENCIA_FOR_LPARAN_SEMI_SEMI_RPARAN2:
                            //<ForSentencia> ::= for '(' <InicializarFor> ';' <ExpresionAsigna> ';' ')' <Sentencia>
                            break;
                         case RuleConstants.RULE_FORSENTENCIA_FOR_LPARAN_SEMI_SEMI_RPARAN3:
                            //<ForSentencia> ::= for '(' <InicializarFor> ';' ';' <ForActualizar> ')' <Sentencia>
                            break;
                         case RuleConstants.RULE_FORSENTENCIA_FOR_LPARAN_SEMI_SEMI_RPARAN4:
                            //<ForSentencia> ::= for '(' <InicializarFor> ';' ';' ')' <Sentencia>
                            break;
                         case RuleConstants.RULE_FORSENTENCIA_FOR_LPARAN_SEMI_SEMI_RPARAN5:
                            //<ForSentencia> ::= for '(' ';' <ExpresionAsigna> ';' <ForActualizar> ')' <Sentencia>
                            break;
                         case RuleConstants.RULE_FORSENTENCIA_FOR_LPARAN_SEMI_SEMI_RPARAN6:
                            //<ForSentencia> ::= for '(' ';' <ExpresionAsigna> ';' ')' <Sentencia>
                            break;
                         case RuleConstants.RULE_FORSENTENCIA_FOR_LPARAN_SEMI_SEMI_RPARAN7:
                            //<ForSentencia> ::= for '(' ';' ';' <ForActualizar> ')' <Sentencia>
                            break;
                         case RuleConstants.RULE_FORSENTENCIA_FOR_LPARAN_SEMI_SEMI_RPARAN8:
                            //<ForSentencia> ::= for '(' ';' ';' ')' <Sentencia>
                            break;
                         case RuleConstants.RULE_FORSENTENCIAIFEXTENDIDO_FOR_LPARAN_SEMI_SEMI_RPARAN:
                            //<ForSentenciaIfExtendido> ::= for '(' <InicializarFor> ';' <ExpresionAsigna> ';' <ForActualizar> ')' <SentenciaIfExtendido>
                            break;
                         case RuleConstants.RULE_FORSENTENCIAIFEXTENDIDO_FOR_LPARAN_SEMI_SEMI_RPARAN2:
                            //<ForSentenciaIfExtendido> ::= for '(' <InicializarFor> ';' <ExpresionAsigna> ';' ')' <SentenciaIfExtendido>
                            break;
                         case RuleConstants.RULE_FORSENTENCIAIFEXTENDIDO_FOR_LPARAN_SEMI_SEMI_RPARAN3:
                            //<ForSentenciaIfExtendido> ::= for '(' <InicializarFor> ';' ';' <ForActualizar> ')' <SentenciaIfExtendido>
                            break;
                         case RuleConstants.RULE_FORSENTENCIAIFEXTENDIDO_FOR_LPARAN_SEMI_SEMI_RPARAN4:
                            //<ForSentenciaIfExtendido> ::= for '(' <InicializarFor> ';' ';' ')' <SentenciaIfExtendido>
                            break;
                         case RuleConstants.RULE_FORSENTENCIAIFEXTENDIDO_FOR_LPARAN_SEMI_SEMI_RPARAN5:
                            //<ForSentenciaIfExtendido> ::= for '(' ';' <ExpresionAsigna> ';' <ForActualizar> ')' <SentenciaIfExtendido>
                            break;
                         case RuleConstants.RULE_FORSENTENCIAIFEXTENDIDO_FOR_LPARAN_SEMI_SEMI_RPARAN6:
                            //<ForSentenciaIfExtendido> ::= for '(' ';' <ExpresionAsigna> ';' ')' <SentenciaIfExtendido>
                            break;
                         case RuleConstants.RULE_FORSENTENCIAIFEXTENDIDO_FOR_LPARAN_SEMI_SEMI_RPARAN7:
                            //<ForSentenciaIfExtendido> ::= for '(' ';' ';' <ForActualizar> ')' <SentenciaIfExtendido>
                            break;
                         case RuleConstants.RULE_FORSENTENCIAIFEXTENDIDO_FOR_LPARAN_SEMI_SEMI_RPARAN8:
                            //<ForSentenciaIfExtendido> ::= for '(' ';' ';' ')' <SentenciaIfExtendido>
                            break;
                         case RuleConstants.RULE_INICIALIZARFOR:
                            //<InicializarFor> ::= <ListadoSentenciaExpresion>
                            break;
                         case RuleConstants.RULE_INICIALIZARFOR2:
                            //<InicializarFor> ::= <Tipo> <DeclaradoresVariable>
                            break;
                         case RuleConstants.RULE_FORACTUALIZAR:
                            //<ForActualizar> ::= <ListadoSentenciaExpresion>
                            break;
                         case RuleConstants.RULE_LISTADOSENTENCIAEXPRESION:
                            //<ListadoSentenciaExpresion> ::= <SentenciaExpresion>
                            break;
                         case RuleConstants.RULE_LISTADOSENTENCIAEXPRESION_COMMA:
                            //<ListadoSentenciaExpresion> ::= <ListadoSentenciaExpresion> ',' <SentenciaExpresion>
                            break;
                         case RuleConstants.RULE_PRIMARY:
                            //<Primary> ::= <PrimaryNoNewArray>
                            break;
                         case RuleConstants.RULE_PRIMARY2:
                            //<Primary> ::= <CreacionArray>
                            break;
                         case RuleConstants.RULE_PRIMARYNONEWARRAY:
                            //<PrimaryNoNewArray> ::= <Literal>
                            break;
                         case RuleConstants.RULE_PRIMARYNONEWARRAY_THIS:{
                            //<PrimaryNoNewArray> ::= this
                             Nodo n=new Nodo("this",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_PRIMARYNONEWARRAY_LPARAN_RPARAN:{
                            //<PrimaryNoNewArray> ::= '(' <ExpresionAsigna> ')'
                             Reduction r=(Reduction)parser.currentReduction().getToken(1).getData();
                             Nodo n=new Nodo(r,parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_PRIMARYNONEWARRAY2:
                            //<PrimaryNoNewArray> ::= <CreacionInstancia>
                            break;
                         case RuleConstants.RULE_PRIMARYNONEWARRAY3:
                            //<PrimaryNoNewArray> ::= <AccesoCampo>
                            break;
                         case RuleConstants.RULE_PRIMARYNONEWARRAY4:
                            //<PrimaryNoNewArray> ::= <InvocacionMetodo>
                            break;
                         case RuleConstants.RULE_PRIMARYNONEWARRAY5:
                            //<PrimaryNoNewArray> ::= <AccesoArray>
                            break;
                         case RuleConstants.RULE_CREACIONINSTANCIA_NEW_LPARAN_RPARAN:{
                            //<CreacionInstancia> ::= new <Nombre> '(' <ListaArgumento> ')'
                             if(pasada==cuatro){
                                 Reduction r1=(Reduction)parser.currentReduction().getToken(1).getData();
                                 Nodo n1=(Nodo)r1.getToken(0).getData();
                                 String s1=n1.listado.lastElement().toString();
                                 Reduction r2=(Reduction)parser.currentReduction().getToken(3).getData();
                                 Nodo n2=(Nodo)r2.getToken(0).getData();
                                 if(n2.listado.firstElement().equals("#@lista")) n2.listado.removeElementAt(0);
                                 Nodo n=null;
                                 if(tipoDatoActual.startsWith("@")||tipoDatoActual.startsWith("!"))tipoDatoActual=tipoDatoActual.substring(1);
                                 /*if(tipoDatoActual.equals(s1)) n=n2;
                                 else errSem.reportar("Linea "+n1.linea+": no coinciden los tipos");*/
                                 n=n2;
                                 parser.currentReduction().getToken(0).setData(n);
                             }
                         }break;
                         case RuleConstants.RULE_CREACIONINSTANCIA_NEW_LPARAN_RPARAN2:{
                            //<CreacionInstancia> ::= new <Nombre> '(' ')'
                             if(pasada==cuatro){
                                 Reduction r1=(Reduction)parser.currentReduction().getToken(1).getData();
                                 Nodo n1=(Nodo)r1.getToken(0).getData();
                                 String s1=n1.listado.lastElement().toString();
                                 Nodo n=null;
                                 if(tipoDatoActual.startsWith("@")||tipoDatoActual.startsWith("!"))tipoDatoActual=tipoDatoActual.substring(1);
                                 /*if(tipoDatoActual.equals(s1)){
                                     n=new Nodo("",n1.linea);
                                     n.listado.removeAllElements();
                                 }else errSem.reportar("Linea "+n1.linea+": no coinciden los tipos");*/
                                 n=new Nodo("",n1.linea);
                                 n.listado.removeAllElements();
                                 parser.currentReduction().getToken(0).setData(n);
                             }
                         }break;
                         case RuleConstants.RULE_LISTAARGUMENTO:
                            //<ListaArgumento> ::= <ExpresionAsigna>
                            break;
                         case RuleConstants.RULE_LISTAARGUMENTO_COMMA:{
                            //<ListaArgumento> ::= <ListaArgumento> ',' <ExpresionAsigna>
                             Reduction r1=(Reduction)parser.currentReduction().getToken(0).getData();
                             Nodo n1=(Nodo)r1.getToken(0).getData();
                                 if(!n1.listado.firstElement().toString().equals("#@lista")){
                                     String s1=n1.getUnion(".");
                                     int l=n1.linea;
                                     n1=new Nodo("#@lista",l);
                                     n1.add(s1);
                                 }
                             Reduction r2=(Reduction)parser.currentReduction().getToken(2).getData();
                             Nodo n2=(Nodo)r2.getToken(0).getData();
                             String s2=n2.getUnion(".");
                             n1.add(s2);
                             parser.currentReduction().getToken(0).setData(n1);
                         }break;
                         case RuleConstants.RULE_CREACIONARRAY_NEW:
                            //<CreacionArray> ::= new <TipoPrimitivo> <ExprsCorchetes> <Corchetes>
                            break;
                         case RuleConstants.RULE_CREACIONARRAY_NEW2:
                            //<CreacionArray> ::= new <TipoPrimitivo> <ExprsCorchetes>
                            break;
                         case RuleConstants.RULE_CREACIONARRAY_NEW3:
                            //<CreacionArray> ::= new <Nombre> <ExprsCorchetes> <Corchetes>
                            break;
                         case RuleConstants.RULE_CREACIONARRAY_NEW4:
                            //<CreacionArray> ::= new <Nombre> <ExprsCorchetes>
                            break;
                         case RuleConstants.RULE_EXPRSCORCHETES:
                            //<ExprsCorchetes> ::= <ExprCorchetes>
                            break;
                         case RuleConstants.RULE_EXPRSCORCHETES2:
                            //<ExprsCorchetes> ::= <ExprsCorchetes> <ExprCorchetes>
                            break;
                         case RuleConstants.RULE_EXPRCORCHETES_LBRACKET_RBRACKET:
                            //<ExprCorchetes> ::= '[' <ExpresionAsigna> ']'
                            break;
                         case RuleConstants.RULE_CORCHETES_LBRACKET_RBRACKET:
                            //<Corchetes> ::= '[' ']'
                            break;
                         case RuleConstants.RULE_CORCHETES_LBRACKET_RBRACKET2:
                            //<Corchetes> ::= <Corchetes> '[' ']'
                            break;
                         case RuleConstants.RULE_ACCESOCAMPO_DOT_ID:{
                            //<AccesoCampo> ::= <Primary> '.' Id
                             Reduction r=(Reduction)parser.currentReduction().getToken(0).getData();
                             Nodo n=(Nodo)r.getToken(0).getData();
                             String s=(String)parser.currentReduction().getToken(2).getData();
                             String s2=n.getUnion(".")+"."+s;
                             Nodo n2=new Nodo(s2,n.linea);
                             parser.currentReduction().getToken(0).setData(n2);
                         }break;
                         case RuleConstants.RULE_ACCESOCAMPO_SUPER_DOT_ID:
                            //<AccesoCampo> ::= super '.' Id
                            break;
                         case RuleConstants.RULE_INVOCACIONMETODO_LPARAN_RPARAN:{
                            //<InvocacionMetodo> ::= <Nombre> '(' <ListaArgumento> ')'
                             Reduction r=(Reduction)parser.currentReduction().getToken(0).getData();
                             Nodo n=(Nodo)r.getToken(0).getData();
                             Reduction r2=(Reduction)parser.currentReduction().getToken(2).getData();
                             Nodo nParams=(Nodo)r2.getToken(0).getData();
                             if(nParams.listado.firstElement().equals("#@lista")) nParams.listado.remove(0);
                             String metodo=new String(n.listado.lastElement().toString());
                             n.listado.removeElementAt(n.listado.size()-1);
                             String id=new String(n.listado.lastElement().toString());
                             n.listado.removeElementAt(n.listado.size()-1);
                             if(pasada==cuatro && entorno.equals("initComponents")){
                                 if(metodo.equals("setText") || metodo.equals("setIcon") || metodo.equals("setSelected") || metodo.equals("setTypeButton")){//1 param
                                     if(!tablaO.setItem(id, tablaO.convertPos(metodo), nParams.listado.firstElement().toString().replace("\"", "")))
                                         errSem.reportar("Linea "+n.linea+": Error con llamar al metodo "+metodo);
                                 }else
                                 if(metodo.equals("setHorizontalAlignment") || metodo.equals("setHorizontalTextPosition")){
                                     if(!tablaO.setItem(id, tablaO.convertPos(metodo), nParams.listado.lastElement()))
                                         errSem.reportar("Linea "+n.linea+": Error con llamar al metodo "+metodo);
                                 }else
                                 if(metodo.equals("setBounds")){
                                     if(!tablaO.setItem(id, Posiciones.LEFT, nParams.listado.elementAt(0)))
                                         errSem.reportar("Linea "+n.linea+": Error con llamar al metodo "+metodo);
                                     if(!tablaO.setItem(id, Posiciones.TOP, nParams.listado.elementAt(1)))
                                         errSem.reportar("Linea "+n.linea+": Error con llamar al metodo "+metodo);
                                     if(!tablaO.setItem(id, Posiciones.WIDTH, nParams.listado.elementAt(2)))
                                         errSem.reportar("Linea "+n.linea+": Error con llamar al metodo "+metodo);
                                     if(!tablaO.setItem(id, Posiciones.HEIGHT, nParams.listado.elementAt(3)))
                                         errSem.reportar("Linea "+n.linea+": Error con llamar al metodo "+metodo);
                                 }else
                                 if(metodo.equals("add")){
                                     if(!tablaO.addItemToPanel(id, nParams.listado.firstElement()))
                                         errSem.reportar("Linea "+n.linea+": Error con llamar al metodo "+metodo);
                                 }else
                                 if(metodo.equals("setSize")){
                                     if(!tablaO.setItem(id, Posiciones.WIDTH, nParams.listado.elementAt(0)))
                                         errSem.reportar("Linea "+n.linea+": Error con llamar al metodo "+metodo);
                                     if(!tablaO.setItem(id, Posiciones.HEIGHT, nParams.listado.elementAt(1)))
                                         errSem.reportar("Linea "+n.linea+": Error con llamar al metodo "+metodo);
                                 }else
                                     errSem.reportar("Linea "+n.linea+": Llamada al metodo no es valido en initComponents(): "+metodo);
                             }
                         }break;
                         case RuleConstants.RULE_INVOCACIONMETODO_LPARAN_RPARAN2:{
                            //<InvocacionMetodo> ::= <Nombre> '(' ')'
                             Reduction r=(Reduction)parser.currentReduction().getToken(0).getData();
                             Nodo n=(Nodo)r.getToken(0).getData();
                             String metodo=new String(n.listado.lastElement().toString());
                             n.listado.removeElementAt(n.listado.size()-1);
                             String id=new String(n.listado.lastElement().toString());
                             n.listado.removeElementAt(n.listado.size()-1);
                             Object valor=new String("");
                             if(pasada==cuatro && entorno.equals("initComponents")){
                                 if(metodo.equals("getText") || metodo.equals("getIcon") || metodo.equals("isSelected") || metodo.equals("getTypeButton") || metodo.equals("getHorizontalAlignment") || metodo.equals("getHorizontalTextPosition") || metodo.equals("getX") || metodo.equals("getY") || metodo.equals("getWidth") || metodo.equals("getHeight")){//1 param
                                     tablaO.existeItem(id);//haciendo que el atributo ultimoTipoBuscado se posicione en el tipo de dato
                                     valor=tablaO.getItem(tablaO.ultimoTipoBuscado, tablaO.convertPos(metodo), id);
                                 }else
                                     errSem.reportar("Linea "+n.linea+": Llamada al metodo no es valido en initComponents(): "+metodo);
                             }
                             Nodo enviar=new Nodo(valor,n.linea);
                             parser.currentReduction().getToken(0).setData(enviar);
                         }break;
                         case RuleConstants.RULE_INVOCACIONMETODO_DOT_ID_LPARAN_RPARAN:
                            //<InvocacionMetodo> ::= <Primary> '.' Id '(' <ListaArgumento> ')'
                            break;
                         case RuleConstants.RULE_INVOCACIONMETODO_DOT_ID_LPARAN_RPARAN2:
                            //<InvocacionMetodo> ::= <Primary> '.' Id '(' ')'
                            break;
                         case RuleConstants.RULE_INVOCACIONMETODO_SUPER_DOT_ID_LPARAN_RPARAN:
                            //<InvocacionMetodo> ::= super '.' Id '(' <ListaArgumento> ')'
                            break;
                         case RuleConstants.RULE_INVOCACIONMETODO_SUPER_DOT_ID_LPARAN_RPARAN2:
                            //<InvocacionMetodo> ::= super '.' Id '(' ')'
                            break;
                         case RuleConstants.RULE_ACCESOARRAY_LBRACKET_RBRACKET:
                            //<AccesoArray> ::= <Nombre> '[' <ExpresionAsigna> ']'
                            break;
                         case RuleConstants.RULE_ACCESOARRAY_LBRACKET_RBRACKET2:
                            //<AccesoArray> ::= <PrimaryNoNewArray> '[' <ExpresionAsigna> ']'
                            break;
                         case RuleConstants.RULE_CASTEXPRESION_LPARAN_RPARAN:
                            //<CastExpresion> ::= '(' <TipoPrimitivo> <Corchetes> ')' <UnarioExpresion>
                            break;
                         case RuleConstants.RULE_CASTEXPRESION_LPARAN_RPARAN2:
                            //<CastExpresion> ::= '(' <TipoPrimitivo> ')' <UnarioExpresion>
                            break;
                         case RuleConstants.RULE_CASTEXPRESION_LPARAN_RPARAN3:
                            //<CastExpresion> ::= '(' <ExpresionAsigna> ')' <UnarioExpresionOtra>
                            break;
                         case RuleConstants.RULE_CASTEXPRESION_LPARAN_RPARAN4:
                            //<CastExpresion> ::= '(' <Nombre> <Corchetes> ')' <UnarioExpresionOtra>
                            break;
                         case RuleConstants.RULE_MULTEXPRESION:
                            //<MultExpresion> ::= <UnarioExpresion>
                            break;
                         case RuleConstants.RULE_MULTEXPRESION_TIMES:
                            //<MultExpresion> ::= <MultExpresion> '*' <UnarioExpresion>
                            break;
                         case RuleConstants.RULE_MULTEXPRESION_DIV:
                            //<MultExpresion> ::= <MultExpresion> '/' <UnarioExpresion>
                            break;
                         case RuleConstants.RULE_MULTEXPRESION_PERCENT:
                            //<MultExpresion> ::= <MultExpresion> '%' <UnarioExpresion>
                            break;
                         case RuleConstants.RULE_ADDEXPRESION:
                            //<AddExpresion> ::= <MultExpresion>
                            break;
                         case RuleConstants.RULE_ADDEXPRESION_PLUS:
                            //<AddExpresion> ::= <AddExpresion> '+' <MultExpresion>
                            break;
                         case RuleConstants.RULE_ADDEXPRESION_MINUS:
                            //<AddExpresion> ::= <AddExpresion> '-' <MultExpresion>
                            break;
                         case RuleConstants.RULE_EXPRESIONCOMPARAR:
                            //<ExpresionComparar> ::= <AddExpresion>
                            break;
                         case RuleConstants.RULE_EXPRESIONCOMPARAR_LT:
                            //<ExpresionComparar> ::= <ExpresionComparar> '<' <AddExpresion>
                            break;
                         case RuleConstants.RULE_EXPRESIONCOMPARAR_GT:
                            //<ExpresionComparar> ::= <ExpresionComparar> '>' <AddExpresion>
                            break;
                         case RuleConstants.RULE_EXPRESIONCOMPARAR_LTEQ:
                            //<ExpresionComparar> ::= <ExpresionComparar> '<=' <AddExpresion>
                            break;
                         case RuleConstants.RULE_EXPRESIONCOMPARAR_GTEQ:
                            //<ExpresionComparar> ::= <ExpresionComparar> '>=' <AddExpresion>
                            break;
                         case RuleConstants.RULE_EXPRESIONCOMPARAR_INSTANCEOF:
                            //<ExpresionComparar> ::= <ExpresionComparar> instanceof <TipoReferencia>
                            break;
                         case RuleConstants.RULE_EXPRESIONIGUAL:
                            //<ExpresionIgual> ::= <ExpresionComparar>
                            break;
                         case RuleConstants.RULE_EXPRESIONIGUAL_EQEQ:
                            //<ExpresionIgual> ::= <ExpresionIgual> '==' <ExpresionComparar>
                            break;
                         case RuleConstants.RULE_EXPRESIONIGUAL_EXCLAMEQ:
                            //<ExpresionIgual> ::= <ExpresionIgual> '!=' <ExpresionComparar>
                            break;
                         case RuleConstants.RULE_ANDCONDICIONALEXPRESION:
                            //<AndCondicionalExpresion> ::= <ExpresionIgual>
                            break;
                         case RuleConstants.RULE_ANDCONDICIONALEXPRESION_AMPAMP:
                            //<AndCondicionalExpresion> ::= <AndCondicionalExpresion> '&&' <ExpresionIgual>
                            break;
                         case RuleConstants.RULE_ORCONDICIONALEXPRESION:
                            //<OrCondicionalExpresion> ::= <AndCondicionalExpresion>
                            break;
                         case RuleConstants.RULE_ORCONDICIONALEXPRESION_PIPEPIPE:
                            //<OrCondicionalExpresion> ::= <OrCondicionalExpresion> '||' <AndCondicionalExpresion>
                            break;
                         case RuleConstants.RULE_EXPRESIONCONDICIONAL:
                            //<ExpresionCondicional> ::= <OrCondicionalExpresion>
                            break;
                         case RuleConstants.RULE_EXPRESIONCONDICIONAL_QUESTION_COLON:
                            //<ExpresionCondicional> ::= <OrCondicionalExpresion> '?' <ExpresionAsigna> ':' <ExpresionCondicional>
                            break;
                         case RuleConstants.RULE_POSFIJOEXPRESION:
                            //<PosfijoExpresion> ::= <Primary>
                            break;
                         case RuleConstants.RULE_POSFIJOEXPRESION2:
                            //<PosfijoExpresion> ::= <Nombre>
                            break;
                         case RuleConstants.RULE_POSFIJOEXPRESION_PLUSPLUS:
                            //<PosfijoExpresion> ::= <PosfijoExpresion> '++'
                            break;
                         case RuleConstants.RULE_POSFIJOEXPRESION_MINUSMINUS:
                            //<PosfijoExpresion> ::= <PosfijoExpresion> --
                            break;
                         case RuleConstants.RULE_UNARIOEXPRESION_PLUSPLUS:
                            //<UnarioExpresion> ::= '++' <UnarioExpresion>
                            break;
                         case RuleConstants.RULE_UNARIOEXPRESION_MINUSMINUS:
                            //<UnarioExpresion> ::= -- <UnarioExpresion>
                            break;
                         case RuleConstants.RULE_UNARIOEXPRESION_PLUS:
                            //<UnarioExpresion> ::= '+' <UnarioExpresion>
                            break;
                         case RuleConstants.RULE_UNARIOEXPRESION_MINUS:
                            //<UnarioExpresion> ::= '-' <UnarioExpresion>
                            break;
                         case RuleConstants.RULE_UNARIOEXPRESION:
                            //<UnarioExpresion> ::= <UnarioExpresionOtra>
                            break;
                         case RuleConstants.RULE_UNARIOEXPRESIONOTRA:
                            //<UnarioExpresionOtra> ::= <PosfijoExpresion>
                            break;
                         case RuleConstants.RULE_UNARIOEXPRESIONOTRA2:
                            //<UnarioExpresionOtra> ::= <CastExpresion>
                            break;
                         case RuleConstants.RULE_EXPRESIONASIGNA:
                            //<ExpresionAsigna> ::= <ExpresionCondicional>
                            break;
                         case RuleConstants.RULE_EXPRESIONASIGNA2:{
                            //<ExpresionAsigna> ::= <LeftSide> <OperadorAsignacion> <ExpresionAsigna>
                             if(pasada==cuatro){
                                 //variableini traeria un nodo null si no coinciden tipos, o si no un nodo con vector vacio si solo es 'new xxx()', si no el vector esta lleno con cada parametro
                                 Reduction rOp=(Reduction)parser.currentReduction().getToken(1).getData();
                                 Nodo nOp=(Nodo)rOp.getToken(0).getData();
                                 String sOp=nOp.listado.firstElement().toString();
                                 Reduction rId=(Reduction)parser.currentReduction().getToken(0).getData();
                                 Nodo nId=(Nodo)rId.getToken(0).getData();
                                 String sId=nId.getUnion("");
                                 Reduction rIni=(Reduction)parser.currentReduction().getToken(2).getData();
                                 Nodo nIni=(Nodo)rIni.getToken(0).getData();
                                 if(tipoDatoActual.startsWith("@")||tipoDatoActual.startsWith("!"))tipoDatoActual=tipoDatoActual.substring(1);
                                 if(nIni!=null && sOp.equals("=") && entorno.equals("initComponents")){
                                     tablaO.existeItem(sId);
                                     boolean paramsBien=tablaO.inicializar(tablaO.ultimoTipoBuscado, sId, nIni);
                                     if(!paramsBien)
                                         errSem.reportar("Linea "+nId.linea+": los parametros son erroneos");
                                 }//else ya se reporto el error (no coinciden tipos)
                                 tipoDatoActual="";
                             }
                         }break;
                         case RuleConstants.RULE_LEFTSIDE:
                            //<LeftSide> ::= <Nombre>
                            break;
                         case RuleConstants.RULE_LEFTSIDE2:
                            //<LeftSide> ::= <AccesoCampo>
                            break;
                         case RuleConstants.RULE_LEFTSIDE3:
                            //<LeftSide> ::= <AccesoArray>
                            break;
                         case RuleConstants.RULE_OPERADORASIGNACION_EQ:{
                            //<OperadorAsignacion> ::= '='
                             Nodo n=new Nodo("=",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_OPERADORASIGNACION_TIMESEQ:{
                            //<OperadorAsignacion> ::= '*='
                             Nodo n=new Nodo("*=",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_OPERADORASIGNACION_DIVEQ:{
                            //<OperadorAsignacion> ::= '/='
                             Nodo n=new Nodo("/=",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_OPERADORASIGNACION_PERCENTEQ:{
                            //<OperadorAsignacion> ::= '%='
                             Nodo n=new Nodo("%=",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_OPERADORASIGNACION_PLUSEQ:{
                            //<OperadorAsignacion> ::= '+='
                             Nodo n=new Nodo("+=",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_OPERADORASIGNACION_MINUSEQ:{
                            //<OperadorAsignacion> ::= '-='
                             Nodo n=new Nodo("-=",parser.currentLineNumber());
                             parser.currentReduction().getToken(0).setData(n);
                         }break;
                         case RuleConstants.RULE_CONTINUESENTENCIA_CONTINUE_ID_SEMI:
                            //<ContinueSentencia> ::= continue Id ';'
                            break;
                         case RuleConstants.RULE_CONTINUESENTENCIA_CONTINUE_SEMI:
                            //<ContinueSentencia> ::= continue ';'
                            break;
                         case RuleConstants.RULE_RETURNSENTENCIA_RETURN_SEMI:
                            //<ReturnSentencia> ::= return <ExpresionAsigna> ';'
                            break;
                         case RuleConstants.RULE_RETURNSENTENCIA_RETURN_SEMI2:
                            //<ReturnSentencia> ::= return ';'
                            break;
                         case RuleConstants.RULE_TRYSENTENCIA_TRY:
                            //<TrySentencia> ::= try <Block> <Catches>
                            break;
                         case RuleConstants.RULE_TRYSENTENCIA_TRY_FINALLY:
                            //<TrySentencia> ::= try <Block> <Catches> finally <Block>
                            break;
                         case RuleConstants.RULE_TRYSENTENCIA_TRY_FINALLY2:
                            //<TrySentencia> ::= try <Block> finally <Block>
                            break;
                         case RuleConstants.RULE_CATCHES_CATCH_LPARAN_RPARAN:
                            //<Catches> ::= catch '(' <Tipo> <DeclaradorVariableId> ')' <Block>
                            break;
                         case RuleConstants.RULE_CATCHES_CATCH_LPARAN_RPARAN2:
                            //<Catches> ::= <Catches> catch '(' <Tipo> <DeclaradorVariableId> ')' <Block>
                            break;
                         case RuleConstants.RULE_BREAKSENTENCIA_BREAK_ID_SEMI:
                            //<BreakSentencia> ::= break Id ';'
                            break;
                         case RuleConstants.RULE_BREAKSENTENCIA_BREAK_SEMI:
                            //<BreakSentencia> ::= break ';'
                            break;
                      }

                          //Parser.Reduction = //Object you created to store the rule

                    // ************************************** log file
                    System.out.println("gpMsgReduction");
                    Reduction myRed = parser.currentReduction();
                    System.out.println(myRed.getParentRule().getText());
                    // ************************************** end log

                    break;

                case gpMsgAccept:
                    /* The program was accepted by the parsing engine */

                    // ************************************** log file
                    System.out.println("gpMsgAccept");
                    // ************************************** end log

                    done = true;

                    break;

                case gpMsgLexicalError:
                    /* Place code here to handle a illegal or unrecognized token
                           To recover, pop the token from the stack: Parser.PopInputToken */

                    // ************************************** log file
                    System.out.println("gpMsgLexicalError");
                    // ************************************** end log

                    parser.popInputToken();

                    break;

                case gpMsgNotLoadedError:
                    /* Load the Compiled Grammar Table file first. */

                    // ************************************** log file
                    System.out.println("gpMsgNotLoadedError");
                    // ************************************** end log

                    done = true;

                    break;

                case gpMsgSyntaxError:
                    /* This is a syntax error: the source has produced a token that was
                           not expected by the LALR State Machine. The expected tokens are stored
                           into the Tokens() list. To recover, push one of the
                              expected tokens onto the parser's input queue (the first in this case):
                           You should limit the number of times this type of recovery can take
                           place. */

                    done = true;

                    Token theTok = parser.currentToken();
                    System.out.println("Token not expected: " + (String)theTok.getData());

                    // ************************************** log file
                    System.out.println("gpMsgSyntaxError");
                    // ************************************** end log

                    break;

                case gpMsgCommentError:
                    /* The end of the input was reached while reading a comment.
                             This is caused by a comment that was not terminated */

                    // ************************************** log file
                    System.out.println("gpMsgCommentError");
                    // ************************************** end log

                    done = true;

                              break;

                case gpMsgInternalError:
                    /* Something horrid happened inside the parser. You cannot recover */

                    // ************************************** log file
                    System.out.println("gpMsgInternalError");
                    // ************************************** end log

                    done = true;

                    break;
            }
        }
        try
        {
              parser.closeFile();
        }
        catch(ParserException parse)
        {
            System.out.println("**PARSER ERROR**\n" + parse.toString());
            System.exit(1);
        }
    }
}
