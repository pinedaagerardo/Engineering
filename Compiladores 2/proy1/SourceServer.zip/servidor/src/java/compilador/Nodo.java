/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package compilador;

import java.util.ListIterator;
import java.util.Vector;

/**
 * guarda informacion para uso del compilador.
 * ej. suponiendo que guarda 'id1.id2', el primer dato en el vector es 'id1' y el ultimo es 'id2'.
 * si guarda 'int a,String b' el primer dato en el vector es 'int a' y el ultimo 'String b'.
 * @author g
 */
public class Nodo {

    /**vector que guarda la informacion*/
    public Vector listado = new Vector();
    /**numero de linea en el documento original donde se encuentra*/
    public int linea;

    /**
     * constructor. guarda el parametro recibido como si se llamara al metodo add(Object o)
     * @param o objeto que se guarda en el vector. Sera el primer dato del nodo
     * @param linea linea actual en el documento original
     */
    public Nodo(Object o,int linea){
        add(o);
        this.linea=linea;
    }

    /**
     * agrega al final del listado un nuevo dato
     * @param o dato a ser agregado
     */
    public void add(Object o){
        listado.addElement(o);
    }

    /**
     * devuelve un ListIterator de los datos en el nodo
     * @return un ListIterator de todos los datos
     */
    public ListIterator get(){
        return listado.listIterator();
    }

    /**
     * retorna la union de cada palabra almacenada en el vector, con el separador
     * indicado enmedio de cada uno de ellos.
     * ej:
     * separador="."
     * vector={id1,id2,id3}
     * retorna "id1.id2.id3"
     * @param separador el separador de cada posicion en el vector
     * @return una union de cada posicion con un separador enmedio de cada uno
     */
    public String getUnion(String separador){
        ListIterator i=get();
        String union="";
        while(i.hasNext()){
            union+=i.next().toString();
            union+=i.hasNext()?separador:"";
        }
        return union;
    }
}
