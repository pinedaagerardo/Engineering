/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package compilador;

import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * clase que se encarga de escribir un reporte web.
 * si el archivo a crear ya existe, es reemplazado por uno nuevo, vacio (en el metodo reportar, fileout.setLength(0)).
 * @author g
 */
public class Reporte {

    private boolean existe=false;
    private String archivo;

    /**
     * constructor.
     * @param archivo ruta absoluta del archivo
     */
    public Reporte(String archivo){
        this.archivo=archivo;
    }

    /**
     * retorna un string con la ruta absoluta del archivo generado
     * @return la ruta absoluta del archivo generado
     */
    public String getArchivo(){
        return archivo;
    }

    /**
     * indica si los archivos compilados tuvieron errores del tipo correspondiente
     * al reporte.
     * @return un boolean que indica si se escribio alguna vez en el archivo.
     */
    public boolean existenErrores(){
        return existe;
    }

    /**
     * escribe o agrega al archivo nueva informacion
     * @param info la informacion usada en la aplicacion
     */
    void reportar(String info){
            try{
            RandomAccessFile fileout=new RandomAccessFile(archivo,"rw");
            if(!existe){
                    fileout.setLength(0); //si el archivo ya existe pero se va a escribir por primera vez en el, se borra su contenido para reemplazarlo
                    fileout.writeBytes("<html>\n");
                    fileout.writeBytes("<head>\n");
                    fileout.writeBytes("<title>Reporte</title>\n");
                    fileout.writeBytes("</head>\n");
                    fileout.writeBytes("<body bgcolor=#000F00 text=white>\n");
                    fileout.writeBytes("<br><p>\n");
                    fileout.writeBytes("<marquee behavior=alternate width=50% height=60 align=center><b><i>Reporte</i></b></marquee>\n");
                    fileout.writeBytes("<br><br><p>\n");
                    fileout.writeBytes("<table width=100% border=1>\n");
                    fileout.writeBytes("<tr align=center>\n");
                    fileout.writeBytes("<td width=100%> <strong>Errores</strong> </td>\n");
                    fileout.writeBytes("</tr>\n");
            }
            if(existe) fileout.seek((fileout.length())-22); //con esta condicion no se regresa el cursor las posiciones la primera vez que se escribe y se escribe bien el archivo
            else existe=true;
            fileout.writeBytes("<tr align=center>\n");
            fileout.writeBytes("<td width=100%> <strong>"+info+"</strong> </td>\n");
            fileout.writeBytes("</tr>\n");
            fileout.writeBytes("</table></body></html>");
            fileout.close();
            }catch(IOException e){
                System.out.println("No se pudo guardar el reporte "+archivo);
            }
    }
}
