/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package compilador;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;

/**
 * realiza todas las acciones relacionadas con los archivos
 * @author g
 */
public class Escritor {

    PrintWriter escritor;

    /**
     * constructor. si el archivo a crear ya existe, es reemplazado por uno nuevo, vacio.
     * @param archivo ruta absoluta del archivo que se va a escribir
     */
    public Escritor(String archivo){
        File f=new File(archivo);
        if(f.exists()) f.delete();

        try {
            escritor = new PrintWriter(new FileWriter(archivo));
        } catch (Exception ex) {
            System.out.println("Error al abrir el archivo "+archivo);
        }
    }

    /**
     * escribe un texto al archivo en la posicion actual
     * @param texto texto a escribir
     */
    public void write(String texto){
        escritor.print(texto);
    }

    /**
     * escribe una linea en la posicion actual del archivo seguido de '\n'
     * @param linea linea a escribir
     */
    public void writeln(String linea){
        escritor.println(linea);
    }

    /**
     * cierra el flujo. Es nesecario hacer esto para que se guarden los cambios al archivo
     */
    public void cerrar(){
        escritor.close();
    }

    /**
     * borra los archivos dentro de la carpeta 'C:\cacheTomcat'
     */
    public static void borrarCache(){
        try {
            Process p=Runtime.getRuntime().exec("cmd /c erase /q \"C:\\cacheTomcat\"");
            p.waitFor();
        }catch (Exception e){
            System.out.println("Error al borrar cache");
        }
    }
}
