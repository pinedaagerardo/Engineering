/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package TablaSim;

import compilador.*;
import java.io.File;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.*;

/**
 *
 * @author g
 */
public class TablaObjetos {

    public String vg_nombre_clase; //nombre de la clase a la que pertenece la tabla
    public String vg_nombre_paquete; //paquete al que pertenece la clase
    public Vector imports=new Vector(); //imports de la clase
    public String vg_acceso; //modificador de acceso de la clase

    final int vg_num_tipos = 17; //cantidad de tipos de datos en la tabla
    final int vg_num_inicio = 1; //posicion donde inicia los tipos en la tabla
    final int vg_num_propiedades = 21; //cantidad de propiedades de los objetos en la tabla
    Object[] vg_tabla = new Object[vg_num_tipos]; //variable con los datos de la tabla de simbolos

    public int ultimoTipoBuscado=0;//almacena la posicion en la tabla del tipo de dato del ultimo objeto buscado por el metodo existeItem(String)

    /**
     * constructor
     */
    public TablaObjetos(){
        for (int i = 0; i < vg_num_tipos; i++) //aqui si comienza desde 0 porque tambien necesita vector la posicion 0
        {
            vg_tabla[i] = new ArrayList(100);
        }
    }

    /**
     * agrega un item nuevo
     * @param id id del item nuevo
     * @param pos_tipo el tipo del item a agregar (usar metodo convertPos(String) o interfaz posiciones)
     */
    public void addItem(String id, int pos_tipo)
    {
        if(pos_tipo==-1) return;
        Object[] tmppropiedades = new Object[vg_num_propiedades];
        for (int i = 0; i < vg_num_propiedades; i++)
            if(i==Posiciones.ADD)
                tmppropiedades[i] = new Vector(100);
            else
                tmppropiedades[i] = null;
        tmppropiedades[Posiciones.ID] = id;
        tmppropiedades[Posiciones.EXISTE] = false;
        ArrayList tmparray = (ArrayList)vg_tabla[pos_tipo];
        tmparray.add(tmppropiedades);
    }

    /**
     * dice si un item existe
     * @param id el id del item a buscar
     * @return true si existe, false de lo contrario
     */
    public boolean existeItem(String id)
    {
        for (int i = vg_num_inicio; i < vg_num_tipos; i++)
        {
            ultimoTipoBuscado=i;
            ArrayList tmparray = (ArrayList)vg_tabla[i];
            int size=tmparray.size();
            for(int j=0;j<size;j++)
            {
                Object[] tmpitem = (Object[])tmparray.get(j);
                if (tmpitem[Posiciones.ID].toString().equals(id))
                    return true;
            }
        }
        return false;
    }

    /**
     * devuelve el array donde se guardan los datos
     * @return el array donde se guardan los datos
     */
    public Object[] getTabla(){
        return vg_tabla;
    }

    /**
     * devuelve la instancia de la clase
     * @return la posicion en memoria de esta clase
     */
    public TablaObjetos getInstance()
    {
        return this;
    }

    /**
     * modifica un atributo de un objeto y devuelve un boolean indicando si tuvo exito
     * @param id el id del objeto a modificar
     * @param pos_propiedad la propiedad a modificar (usar metodo convertPos(String) o interfaz posiciones)
     * @param dato valor del dato a escribir
     * @return return true si tuvo exito, false de lo contrario
     */
    public boolean setItem(String id, int pos_propiedad, Object dato)
    {
        if(pos_propiedad==-1) return false;
        for (int i = vg_num_inicio; i < vg_num_tipos; i++)
        {
            ArrayList tmparray = (ArrayList)vg_tabla[i];
            int size=tmparray.size();
            for(int j=0;j<size;j++)
            {
                Object[] tmpitem = (Object[])tmparray.get(j);
                if (tmpitem[Posiciones.ID].toString().equals(id))
                {
                    tmpitem[pos_propiedad] = dato;
                    tmpitem[Posiciones.EXISTE] = true;
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * agrega un id de un objeto al listado de agregados de un panel (vector)
     * y retorna un boolean indicando si tuvo exito
     * @param id id del panel
     * @param obj id del objeto a agregar
     * @return true si tuvo exito la operacion, false de lo contrario
     */
    public boolean addItemToPanel(String id,Object obj){
        ArrayList tmparray = (ArrayList)vg_tabla[Posiciones.JPANEL];
        int size=tmparray.size();
        for(int j=0;j<size;j++){
            Object[] tmpitem = (Object[])tmparray.get(j);
            if (tmpitem[Posiciones.ID].toString().equals(id)){
                Vector v=(Vector)tmpitem[Posiciones.ADD];
                v.addElement(obj);
                setItem(id,Posiciones.EXISTE,true);
                return true;
            }
        }
        return false;
    }

    /**
     * devuelve un atributo de un objeto
     * @param pos_tipo la posicion del tipo de dato del objeto a buscar en la tabla
     * @param pos_propiedad la posicion de la propiedad a buscar (usar metodo convertPos(String) o interfaz posiciones)
     * @param id nombre del objeto a buscar
     * @return el atributo encontrado en la tabla o null si no lo encuentra
     */
    public Object getItem(int pos_tipo, int pos_propiedad, String id)
    {
        if(pos_tipo<vg_num_inicio || pos_tipo>=vg_num_tipos || pos_propiedad==-1) return null;
        ArrayList tmparray = (ArrayList)vg_tabla[pos_tipo];
        int size=tmparray.size();
        for(int j=0;j<size;j++)
        {
            Object[] tmpitem = (Object[])tmparray.get(j);
            if (tmpitem[Posiciones.ID].toString().equals(id))
            {
                return tmpitem[pos_propiedad];
            }
        }
        return null;
    }

    /**
     * retorna un objeto de un tipo determinado o null si no lo encuentra
     * @param tipo posicion del tipo de dato
     * @param id id del objeto
     * @return el objeto o null
     */
    public Object[] getObjeto(int tipo, String id){
        ArrayList tmparray = (ArrayList)vg_tabla[tipo];
        int size=tmparray.size();
        for(int j=0;j<size;j++){
            Object[] tmpitem = (Object[])tmparray.get(j);
            if (tmpitem[Posiciones.ID].toString().equals(id))
                return tmpitem;
        }
        return null;
    }

    /**
     * borra un objeto de la tabla, si existe (borra una posicion del vector de un
     * determinado tipo)
     * @param tipo posicion del tipo de dato del objeto a borrar
     * @param id id del objeto a borrar
     */
    protected void borrarObjeto(int tipo,String id){
        if(tipo<vg_num_inicio || tipo>=vg_num_tipos) return;
        ArrayList tmparray = (ArrayList)vg_tabla[tipo];
        int size=tmparray.size();
        for(int i=0;i<size;i++)
        {
            Object[] tmpitem = (Object[])tmparray.get(i);
            if (tmpitem[Posiciones.ID].toString().equals(id)){
                tmparray.remove(i);
                return;
            }
        }
    }

    /**
     * inicializa en la tablaObjetos el atributo recibido y retorna un boolean
     * indicando si se realizo con exito (con respecto a los parametros)
     * @param tipo el tipo de dato del atributo
     * @param id id del atributo
     * @param params parametros de inicializacion
     * @return true si se realizo con exito, false lo contrario
     */
    public boolean inicializar(String tipo,String id,Nodo params){
        int tipoDato=convertPos(tipo);
        return inicializar(tipoDato,id,params);
    }

    /**
     * inicializa en la tablaObjetos el atributo recibido y retorna un boolean
     * indicando si se realizo con exito (con respecto a los parametros)
     * @param tipo el tipo de dato del atributo
     * @param id id del atributo
     * @param params parametros de inicializacion
     * @return true si se realizo con exito, false lo contrario
     */
    public boolean inicializar(int tipoDato,String id,Nodo params){
        Vector parametros=params.listado;
        if(tipoDato==-1) return true;

        switch(tipoDato){
            case 1:{//JLabel
                if(parametros.size()>3 || parametros.size()==0) return false;
                if(parametros.size()==1){
                    String p=parametros.firstElement().toString();
                    if(p.startsWith("\""))
                        setItem(id, Posiciones.TEXT, convertString(p));
                    else{//si no comienza con comillas es el id de un imageicon
                        if(existeItem(p) && ultimoTipoBuscado==Posiciones.IMAGEICON)
                            setItem(id, Posiciones.IMAGEPATH, p);//p es el id de un ImageIcon
                        else
                            return false;
                    }
                    setItem(id, Posiciones.ALIGNMENT, JLabel.LEFT);
                    return true;
                }
                if(parametros.size()==2){
                    Nodo n1=new Nodo(parametros.firstElement().toString(),params.linea);
                    Nodo n2=new Nodo(parametros.lastElement().toString(),params.linea);
                    if(!inicializar(tipoDato,id,n1)) return false;
                    if(!inicializar(tipoDato,id,n2)) return false;
                    return true;
                }
                if(parametros.size()==3){
                    Nodo n1=new Nodo(parametros.firstElement().toString(),params.linea);
                    n1.add(parametros.elementAt(1).toString());
                    if(!inicializar(tipoDato,id,n1)) return false;
                    String p3=parametros.lastElement().toString();
                    int valor;
                    if(p3.equals("JLabel.CENTER")) valor=JLabel.CENTER;
                    else if(p3.equals("JLabel.LEFT")) valor=JLabel.LEFT;
                    else if(p3.equals("JLabel.RIGHT")) valor=JLabel.RIGHT;
                    else return false;
                    setItem(id, Posiciones.ALIGNMENT, valor);
                    return true;
                }
            }break;
            case 2:{//JButton
                if(parametros.size()!=1)return false;
                String p=parametros.firstElement().toString();
                if(p.startsWith("\"")){
                    setItem(id, Posiciones.TEXT, convertString(p));
                    return true;
                }
            }break;
            case 3:{//jcheckbox
                if(parametros.size()==1){
                    String p=parametros.firstElement().toString();
                    if(p.startsWith("\"")){
                        setItem(id, Posiciones.TEXT, convertString(p));
                        return true;
                    }
                }
            }break;
            case 4:{//jradiobutton
                if(parametros.size()==2){
                    String p1=parametros.firstElement().toString();
                    boolean p2;
                    try{
                        p2=Boolean.getBoolean(parametros.lastElement().toString());
                    }catch(Exception e){return false;}
                    setItem(id, Posiciones.TEXT, convertString(p1));
                    setItem(id, Posiciones.CHECK, p2);
                    return true;
                }
            }break;
            case 5:{//buttongroup
                if(parametros.size()==0){
                    setItem(id, Posiciones.EXISTE, true);
                }
            }break;
            case 6:{//jcombobox
                if(parametros.size()==0){
                    setItem(id, Posiciones.EXISTE, true);
                }
            }break;
            case 7:{//jtextfield
                if(parametros.size()>2) return false;
                if(parametros.size()<=1){
                    setItem(id, Posiciones.EXISTE, true);
                    return true;
                }
                if(parametros.size()==2){
                    String p1=parametros.firstElement().toString();
                    setItem(id, Posiciones.TEXT, convertString(p1));
                    return true;
                }
            }break;
            case 8:{//jtextarea
                if(parametros.size()==0){
                    setItem(id, Posiciones.EXISTE, true);
                    return true;
                }
                if(parametros.size()==1){
                    String p1=parametros.firstElement().toString();
                    setItem(id, Posiciones.TEXT, convertString(p1));
                    return true;
                }
            }break;
            case 9:{//jpasswordfield
                if(parametros.size()==0){
                    setItem(id, Posiciones.EXISTE, true);
                    return true;
                }
                if(parametros.size()==1){
                    String p1=parametros.firstElement().toString();
                    setItem(id, Posiciones.TEXT, convertString(p1));
                    return true;
                }
            }break;
            case 10:{//jtree
                if(parametros.size()==1){
                    String p=parametros.firstElement().toString();
                    if(existeItem(p) && ultimoTipoBuscado==Posiciones.DEFAULTTREEMODEL){
                        setItem(id, Posiciones.TEXT, p);
                        return true;
                    }
                }
            }break;
            case 11:{//jtable
                if(parametros.size()==2){
                    try{
                        int p1=Integer.parseInt(parametros.firstElement().toString());
                        int p2=Integer.parseInt(parametros.lastElement().toString());
                        setItem(id, Posiciones.ROWS, p1);
                        setItem(id, Posiciones.COLS, p2);
                        return true;
                    }catch(Exception e){}
                }
            }break;
            case 12:{//jpanel
                if(parametros.size()==0){
                    setItem(id, Posiciones.EXISTE, true);
                    return true;
                }
            }break;
            case 13:{//jfilechooser
                if(parametros.size()==0){
                    setItem(id, Posiciones.EXISTE, true);
                    return true;
                }
            }break;
            case 14:{//imageicon
                if(parametros.size()==1){
                    String p=parametros.firstElement().toString();
                    p=convertString(p);
                    File f=new File(p);
                    if(f.exists()){
                        setItem(id, Posiciones.IMAGEPATH, p);
                        return true;
                    }
                }
            }break;
            case 15:{//defaultmutabletreenode
                if(parametros.size()==1){
                    String p=parametros.firstElement().toString();
                    if(p.startsWith("\"")){
                        setItem(id, Posiciones.TEXT, convertString(p));
                        return true;
                    }
                }
            }break;
            case 16:{//defaulttreemodel
                if(parametros.size()==1){
                    String p=parametros.firstElement().toString();
                    if(existeItem(p) && ultimoTipoBuscado==Posiciones.DEFAULTMUTABLETREENODE){
                        setItem(id, Posiciones.TEXT, p);
                        return true;
                    }
                }
            }break;
        }
        return false;
    }

    /**
     * devuelve un String sin comillas
     * @param s String a convertir
     * @return el String recibido sin comillas
     */
    String convertString(String s){
        return s.replace("\"", "");
    }

    /**
     * convierte un string al valor correspondiente segun el enum Posiciones
     * @param tipo
     * @return un int representando el valor ingresado basandose en la interfaz posiciones
     */
    public int convertPos(String tipo)
    {
        int tmp=tipo.indexOf('[');
        if(tmp!=-1) tipo=tipo.substring(0, tmp);
        tmp=tipo.lastIndexOf('.');
        if(tmp!=-1)tipo=tipo.substring(tmp+1);

        if (tipo.endsWith("Name")) return Posiciones.ID;
        if (tipo.endsWith("existe")) return Posiciones.EXISTE;
        if (tipo.endsWith("Foreground")) return Posiciones.FORECOLOR;
        if (tipo.endsWith("Foresize")) return Posiciones.FORESIZE;
        if (tipo.endsWith("Text")) return Posiciones.TEXT;
        if (tipo.endsWith("Icon")) return Posiciones.IMAGEPATH;
        if (tipo.endsWith("HorizontalAlignment") || tipo.endsWith("HorizontalTextPosition")) return Posiciones.ALIGNMENT;
        if (tipo.endsWith("TypeTitle")) return Posiciones.TYPETITLE;
        if (tipo.endsWith("Background")) return Posiciones.BACKCOLOR;
        if (tipo.endsWith("Selected")) return Posiciones.CHECK;
        if (tipo.endsWith("TypeButton")) return Posiciones.TYPEBUTTON;
        if (tipo.endsWith("Width")) return Posiciones.WIDTH;
        if (tipo.endsWith("Height")) return Posiciones.HEIGHT;
        if (tipo.endsWith("getY")) return Posiciones.TOP;
        if (tipo.endsWith("getX")) return Posiciones.LEFT;
        if (tipo.endsWith("Cols")) return Posiciones.COLS;
        if (tipo.endsWith("Rows")) return Posiciones.ROWS;
        if (tipo.endsWith("Parent")) return Posiciones.PARENT;
        if (tipo.endsWith("E_clic")) return Posiciones.EVENTO_CLIC;
        if (tipo.endsWith("E_change")) return Posiciones.EVENTO_CHANGE;
        if (tipo.endsWith("add")) return Posiciones.ADD;

        if (tipo.equals("JLabel")) return Posiciones.JLABEL;
        if (tipo.equals("JButton")) return Posiciones.JBUTTON;
        if (tipo.equals("JCheckBox")) return Posiciones.JCHECKBOX;
        if (tipo.equals("JRadioButton")) return Posiciones.JRADIOBUTTON;
        if (tipo.equals("ButtonGroup")) return Posiciones.BUTTONGROUP;
        if (tipo.equals("JComboBox")) return Posiciones.JCOMBOBOX;
        if (tipo.equals("JTextField")) return Posiciones.JTEXTFIELD;
        if (tipo.equals("JTextArea")) return Posiciones.JTEXTAREA;
        if (tipo.equals("JPasswordField")) return Posiciones.JPASSWORDFIELD;
        if (tipo.equals("JTree")) return Posiciones.JTREE;
        if (tipo.equals("JTable")) return Posiciones.JTABLE;
        if (tipo.equals("JPanel")) return Posiciones.JPANEL;
        if (tipo.equals("JFileChooser")) return Posiciones.JFILECHOOSER;
        if (tipo.equals("ImageIcon")) return Posiciones.IMAGEICON;
        if (tipo.equals("DefaultMutableTreeNode")) return Posiciones.DEFAULTMUTABLETREENODE;
        if (tipo.equals("DefaultTreeModel")) return Posiciones.DEFAULTTREEMODEL;

        return -1; //si no coincide con ninguno
    }

    /**
     * genera documentos finales
     * @param tabla tabla de simbolos usada en el parser
     */
    public void generarDoc(TablaSimbolos tabla){
        Escritor tmpehtml=new Escritor("C:\\cacheTomcat\\tmphtml");
        Escritor tmpecss=new Escritor("C:\\cacheTomcat\\tmpestilo");

        tmpecss.writeln("<style type=\"text/css\">");
        tmpehtml.writeln("</script>\n</head>\n<body>");

        ArrayList panels = (ArrayList)vg_tabla[Posiciones.JPANEL];
        for (int i=0;i<panels.size();i++){//iterando en los objetos de cada tipo de dato
            Object[] panel=(Object[])panels.get(i);
                tmpecss.writeln("#tag_"+panel[Posiciones.ID]+"{");
                tmpecss.writeln("width: "+panel[Posiciones.WIDTH]+"px;");
                tmpecss.writeln("height: "+panel[Posiciones.HEIGHT]+"px;");
                tmpecss.writeln("padding-top: "+panel[Posiciones.TOP]+"px;");
                tmpecss.writeln("padding-left: "+panel[Posiciones.LEFT]+"px;");
                tmpecss.writeln("text-align: "+panel[Posiciones.ALIGNMENT]+";");
                tmpecss.writeln("}");
                tmpehtml.writeln("<div id=tag_"+panel[Posiciones.ID]+">");
            escribirPanel(tmpehtml, tmpecss, panel);
                tmpehtml.writeln("</div>");
        }
        tmpehtml.cerrar();
        tmpecss.cerrar();


        /*ehtml.writeln("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 3.2//EN\">");
        ehtml.writeln("<html>");
        ehtml.writeln("    <head>");
        ehtml.writeln("        <title>interfaz grafica</title>");*/
    }

    /**
     * cuando el string equivale a "null" retorna un string vacio
     * @param s el string a verificar
     * @return un string vacio o el mismo string si no es igual a "null"
     */
    protected String quitarNull(String s){
        return (s.equals("null"))?"":s;
    }

    /**
     * escribe el contenido de un panel a los flujos recibidos. esta hecho
     * para usarlo recursivamente, y edita la tabla recibida para que funcione
     * como debe
     * @param html flujo para escribir archivo html
     * @param css flujo para escribir archivo css
     * @param panel panel a escribir
     */
    protected void escribirPanel(Escritor html,Escritor css,Object[] panel){
        Vector objs=(Vector)panel[Posiciones.ADD];
        int size=objs.size();
        boolean seEscribio=false;
        for(int i=0;i<size;i++){//recorriendo objetos por agregar
            seEscribio=false;
            String obj=objs.elementAt(i).toString();

            existeItem(obj);
            String text=String.valueOf(getItem(ultimoTipoBuscado, Posiciones.TEXT, obj)); text=quitarNull(text);
            String img=String.valueOf(getItem(ultimoTipoBuscado, Posiciones.IMAGEPATH, obj)); img=quitarNull(img);
            String width=String.valueOf(getItem(ultimoTipoBuscado, Posiciones.WIDTH, obj)); width=quitarNull(width);
            String height=String.valueOf(getItem(ultimoTipoBuscado, Posiciones.HEIGHT, obj)); height=quitarNull(height);
            String top=String.valueOf(getItem(ultimoTipoBuscado, Posiciones.TOP, obj)); top=quitarNull(top);
            String left=String.valueOf(getItem(ultimoTipoBuscado, Posiciones.LEFT, obj)); left=quitarNull(left);
            String alineacion=String.valueOf(getItem(ultimoTipoBuscado, Posiciones.ALIGNMENT, obj)); alineacion=quitarNull(alineacion);
            String tipoTitulo="H"+String.valueOf(getItem(ultimoTipoBuscado, Posiciones.TYPETITLE, obj)); tipoTitulo=tipoTitulo.replaceAll("null", "4");
            String check=String.valueOf(getItem(ultimoTipoBuscado, Posiciones.CHECK, obj)); check=quitarNull(check);

            if(existeItem(obj) && ultimoTipoBuscado!=Posiciones.JPANEL){
                switch(ultimoTipoBuscado){
                    case Posiciones.JLABEL:{
                        String s="<div id=tag_"+obj+"><"+tipoTitulo+">"+text+"</"+tipoTitulo+">";
                        if(img.length()!=0)
                            s+="<br><img src=\""+img+"\" height=\""+height+"\" width=\""+width+"\" />";
                        s+="</div><br>";
                        html.writeln(s);
                        seEscribio=true;
                    }break;
                    case Posiciones.JBUTTON:{
                        String s="<input id=tag_"+obj+" name=\"btn_"+obj+"\" type=\"submit\" value=\""+text+"\" /><br>";
                        html.writeln(s);
                        seEscribio=true;
                    }break;
                    case Posiciones.JCHECKBOX:{
                        String s="<input id=tag_"+obj+" name=\"chk_"+obj+"\" type=\"checkbox\" value=\""+text+"\" />"+text+"<br>";
                        html.writeln(s);
                        seEscribio=true;
                    }break;
                    case Posiciones.JRADIOBUTTON:{
                        String s="<input id=tag_"+obj+" name=\"rad_"+obj+"\" type=\"radio\" value=\""+check+"\" />"+text+"<br>";
                        html.writeln(s);
                        seEscribio=true;
                    }break;
                    case Posiciones.JCOMBOBOX:{

                    }break;
                    case Posiciones.JTEXTFIELD:{
                        String s="<input id=tag_"+obj+" name=\"txt_"+obj+"\" type=\"text\" /><br>";
                        html.writeln(s);
                        seEscribio=true;
                    }break;
                    case Posiciones.JTEXTAREA:{
                        String s="<input id=tag_"+obj+" name=\"txt_"+obj+"\" type=\"textarea\" /><br>";
                        html.writeln(s);
                        seEscribio=true;
                    }break;
                    case Posiciones.JPASSWORDFIELD:{
                        String s="<input id=tag_"+obj+" name=\"txt_"+obj+"\" type=\"password\" /><br>";
                        html.writeln(s);
                        seEscribio=true;
                    }break;
                    case Posiciones.JTABLE:{

                    }break;
                    case Posiciones.JFILECHOOSER:{
                        String s="<input id=tag_"+obj+" name=\"file_"+obj+"\" type=\"file\" /><br>";
                        html.writeln(s);
                        seEscribio=true;
                    }break;
                }
            }else
                if(existeItem(obj)){
                    html.writeln("<div id=tag_"+obj+">");
                    escribirPanel(html, css, this.getObjeto(ultimoTipoBuscado, obj));
                    html.writeln("</div>");
                    seEscribio=true;
                }

            if(seEscribio){
                css.writeln("#tag_"+obj+"{");
                css.writeln("width: "+width+"px;");
                css.writeln("height: "+height+"px;");
                css.writeln("padding-top: "+top+"px;");
                css.writeln("padding-left: "+left+"px;");
                css.writeln("text-align: "+alineacion+";");
                css.writeln("}");
            }

            borrarObjeto(ultimoTipoBuscado, obj);
        }
    }
}