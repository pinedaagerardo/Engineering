/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package TablaSim;

import java.util.Iterator;
import java.util.Vector;

/**
 * guarda los atributos y metodos de un tipo de dato
 * @author g
 */
public class TipoDato {

    /**paquete de la clase*/
    public String paquete;
    /**listado de tipos (clases) importados de la forma nombre(listaParametros)*/
    public Paquete imports=new Paquete("import");
    /**modificador de acceso de la clase (ej. public)*/
    public String acceso;
    /**segundo modificador de acceso de la clase (ej. static)*/
    public String modificador2;
    /**nombre de la clase*/
    public String nombre;
    /**nombre de la clase de donde hereda*/
    public TipoDato hereda;

    /**modificador de acceso de los atributos/metodos*/
    public Vector accesos=new Vector();
    /**tipo de los atributos/metodos*/
    public Vector tipos=new Vector();
    /**nombre de los atributos/metodos*/
    public Vector nombres=new Vector();
    /**boolean que dice si es metodo o atributo*/
    public Vector esMetodo=new Vector();
    /**entorno de los atributos/metodos*/
    public Vector entornos=new Vector();

    /**
     * constructor de la clase. si algun parametro no se define debera enviarse una cadena vacia.
     * @param paquete nombre del paquete
     * @param acceso modificador de acceso (ej. public)
     * @param mod segundo modificador (ej. static)
     * @param nombre nombre de la clase
     * @param hereda nombre de la clase de donde se hereda
     */
    public TipoDato(String paquete, String acceso, String mod, String nombre, TipoDato hereda){
        this.paquete=new String(paquete);
        this.acceso=new String(acceso);
        this.modificador2=new String(mod);
        this.nombre=new String(nombre);
        this.hereda=hereda;
    }

    /**
     * dice si existe o no en la tabla el atributo/metodo recibido como parametro
     * @param nombre el nombre a buscar
     * @param esMetodo dice si el atributo/metodo es metodo o no
     * @param entorno el entorno del atributo/metodo
     * @return true si existe, false de lo contrario
     */
    public boolean contiene(String nombre, boolean esMetodo, String entorno){
        int i=nombres.indexOf(nombre);
        if(i!=-1){
            boolean btmp=Boolean.valueOf(this.esMetodo.elementAt(i).toString());
            boolean b=esMetodo==btmp;
            boolean b2=this.entornos.elementAt(i).equals(entorno);
            return b&&b2;
        }
        if(hereda!=null){
            return hereda.contiene(nombre, esMetodo, entorno);
        }
        return false;
    }

    /**
     * dice si el nombre recibido es una clase importada. el nombre recibido
     * se toma como si fuera de la forma 'nombre'; si viniera 'paquete.nombre'
     * se toma como si el paquete fuera parte del nombre.
     * @param nombre nombre que se busca entre las clases importadas para decidir si esta o no importado
     * @return true si esta importado, false de lo contrario
     */
    public boolean estaImportado(String nombre){
        // Las clases importadas tienen la forma paquete.nombre
        Iterator i = imports.tipos.iterator();
        while(i.hasNext()){
             String s=(String)i.next();
             int tmp=s.lastIndexOf('.');
             if(tmp!=-1){
                 s=s.substring(tmp+1);
                 if(s.equals(nombre))
                     return true;
             }
        }
        return false;
    }

    /**
     * agrega un atributo/metodo
     * @param acceso modificadores de acceso (ej. public, static)
     * @param tipo tipo de dato del atributo/metodo
     * @param nombre nombre del atributo/metodo
     * @param esMetodo dice si el atributo/metodo es metodo o no
     * @param entorno entorno del atributo/metodo
     */
    public void agregar(String acceso,String tipo,String nombre,boolean esMetodo,String entorno){
        accesos.addElement(acceso);
        tipos.addElement(tipo);
        nombres.addElement(nombre);
        this.esMetodo.addElement(esMetodo);
        entornos.addElement(entorno);
    }

    /**
     * agrega una clase a la lista de clases importadas
     * @param clase clase a importar. Debe estar con este formato: paquete.nombre
     */
    public void importar(String clase){
        if(!clase.equals(""))
            imports.agregar(clase);
    }
}
