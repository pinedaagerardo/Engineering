/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package TablaSim;

import java.util.Iterator;
import java.util.Vector;

/**
 * tabla que almacena los tipos de datos y sus detalles necesarios para compilar
 * @author g
 */
public class TablaSimbolos {

    /**vector que almacena los paquetes*/
    public Vector paquetes=new Vector();
    /**vector que almacena las tablas y su estructura*/
    public Vector tablas=new Vector();

    /**
     * constructor de la clase
     */
    public TablaSimbolos(){
        crearPaquete("java.awt");
        crearPaquete("java.awt.event");
        crearPaquete("java.util");
        crearPaquete("java.io");
        crearPaquete("java.sql");
        crearPaquete("javax.swing");
        crearPaquete("javax.swing.tree");
        crearPaquete("javax.swing.table");
        crearPaquete("javax.swing.border");
        crearPaquete("javax.activation");
        crearPaquete("javax.mail");
        crearPaquete("javax.mail.internet");
        crearPaquete("javax.lang");

        agregarTipo("java.awt", "Color(int,int,int)");
        agregarTipo("java.awt", "Color(int,int,int,int)");
        agregarTipo("java.awt", "Color(float,float,float,float)");
        agregarTipo("java.awt", "Color(float,float,float)");
        agregarTipo("java.awt", "Color(Color)");
        agregarTipo("java.awt", "Color(int)");
        agregarTipo("java.awt", "EventQueue()");
        agregarTipo("java.awt", "Rectangle(int,int,int,int)");
        agregarTipo("java.awt", "Font(String,int,int)");
        agregarTipo("java.awt.event", "ActionListener()");
        agregarTipo("java.awt.event", "ActionEvent()");
        agregarTipo("java.util", "Properties()");
        agregarTipo("java.util", "Vector()");
        agregarTipo("java.io", "UnsupportedEncodingException()");
        agregarTipo("java.io", "FileFilter()");
        agregarTipo("java.sql", "Connection()");
        agregarTipo("java.sql", "Driver()");
        agregarTipo("java.sql", "DriverManager()");
        agregarTipo("java.sql", "PreparedStatement()");
        agregarTipo("java.sql", "ResultSet()");
        agregarTipo("java.sql", "SQLException()");
        agregarTipo("javax.swing", "JLabel(String)");
        agregarTipo("javax.swing", "ImageIcon(String)");
        agregarTipo("javax.swing", "JLabel(ImageIcon)");
        agregarTipo("javax.swing", "JLabel(String,ImageIcon)");
        agregarTipo("javax.swing", "JLabel(String,ImageIcon,int)");
        agregarTipo("javax.swing", "JButton(String)");
        agregarTipo("javax.swing", "AbstractButton()");
        agregarTipo("javax.swing", "JCheckBox(String)");
        agregarTipo("javax.swing", "JRadioButton(String,boolean)");
        agregarTipo("javax.swing", "ButtonGroup()");
        agregarTipo("javax.swing", "JComboBox()");
        agregarTipo("javax.swing", "JTextField(int)");
        agregarTipo("javax.swing", "JTextField(String,int)");
        agregarTipo("javax.swing", "JTextArea()");
        agregarTipo("javax.swing", "JTextArea(String)");
        agregarTipo("javax.swing", "JPasswordField()");
        agregarTipo("javax.swing", "JPasswordField(String)");
        agregarTipo("javax.swing", "JTree(DefaultTreeModel)");
        agregarTipo("javax.swing", "JTable(int,int)");
        agregarTipo("javax.swing", "JPanel()");
        agregarTipo("javax.swing", "JFileChooser()");
        agregarTipo("javax.swing", "JFrame()");
        agregarTipo("javax.swing", "JScrollPane()");
        agregarTipo("javax.swing", "JOptionPane()");
        agregarTipo("javax.swing", "BorderFactory()");
        agregarTipo("javax.swing.tree", "DefaultTreeModel(DefaultMutableTreeNode)");
        agregarTipo("javax.swing.tree", "DefaultMutableTreeNode(String)");
        agregarTipo("javax.swing.border", "Border()");
        agregarTipo("javax.swing.border", "LineBorder(Color,int,boolean)");
        agregarTipo("javax.swing.table", "DefaultTableModel(int,int)");
        agregarTipo("javax.mail", "Authenticator()");
        agregarTipo("javax.mail", "Session()");
        agregarTipo("javax.mail", "MessagingException()");
        agregarTipo("javax.mail", "Message(MimeMessage)");
        agregarTipo("javax.mail", "PasswordAuthentication(String,String)");
        agregarTipo("javax.mail.internet", "MimeMessage(Session)");
        agregarTipo("javax.mail.internet", "InternetAddress(String)");
        agregarTipo("javax.mail.internet", "InternetAddress(String,String)");
        agregarTipo("javax.lang", "Exception()");
        agregarTipo("javax.lang", "Exception(String)");
        agregarTipo("javax.lang", "Runnable()");
        agregarTipo("javax.lang", "Object()");

        crearTabla("java.awt", "public", "", "Color",null);
        crearTabla("java.awt", "public", "", "EventQueue",null);
        crearTabla("java.awt", "public", "", "Rectangle",null);
        crearTabla("java.awt", "public", "", "Font",null);
        crearTabla("java.awt.event", "public", "", "ActionListener",null);
        crearTabla("java.awt.event", "public", "", "ActionEvent",null);
        crearTabla("java.util", "public", "", "Properties",null);
        crearTabla("java.util", "public", "", "Vector",null);
        crearTabla("java.io", "public", "", "UnsupportedEncodingException",null);
        crearTabla("java.io", "public", "", "FileFilter",null);
        crearTabla("java.sql", "public", "", "Connection",null);
        crearTabla("java.sql", "public", "", "Driver",null);
        crearTabla("java.sql", "public", "", "DriverManager",null);
        crearTabla("java.sql", "public", "", "PreparedStatement",null);
        crearTabla("java.sql", "public", "", "ResultSet",null);
        crearTabla("java.sql", "public", "", "SQLException",null);
        crearTabla("javax.swing", "public", "", "JLabel",null);
        crearTabla("javax.swing", "public", "", "ImageIcon",null);
        crearTabla("javax.swing", "public", "", "JButton",null);
        crearTabla("javax.swing", "public", "abstract", "AbstractButton",null);
        crearTabla("javax.swing", "public", "", "JCheckBox",null);
        crearTabla("javax.swing", "public", "", "JRadioButton",null);
        crearTabla("javax.swing", "public", "", "ButtonGroup",null);
        crearTabla("javax.swing", "public", "", "JComboBox",null);
        crearTabla("javax.swing", "public", "", "JTextField",null);
        crearTabla("javax.swing", "public", "", "JTextArea",null);
        crearTabla("javax.swing", "public", "", "JPasswordField",null);
        crearTabla("javax.swing", "public", "", "JTree",null);
        crearTabla("javax.swing", "public", "", "JTable",null);
        crearTabla("javax.swing", "public", "", "JPanel",null);
        crearTabla("javax.swing", "public", "", "JFileChooser",null);
        crearTabla("javax.swing", "public", "", "JFrame",null);
        crearTabla("javax.swing", "public", "", "JScrollPane",null);
        crearTabla("javax.swing", "public", "", "JOptionPane",null);
        crearTabla("javax.swing", "public", "", "BorderFactory",null);
        crearTabla("javax.swing.tree", "public", "", "DefaultTreeModel",null);
        crearTabla("javax.swing.tree", "public", "", "DefaultMutableTreeNode",null);
        crearTabla("javax.swing.border", "public", "", "Border",null);
        crearTabla("javax.swing.border", "public", "", "LineBorder",null);
        crearTabla("javax.swing.table", "public", "", "DefaultTableModel",null);
        crearTabla("javax.mail", "public", "abstract", "Authenticator",null);
        crearTabla("javax.mail", "public", "final", "Session",null);
        crearTabla("javax.mail", "public", "", "MessagingException",null);
        crearTabla("javax.mail", "public", "abstract", "Message",null);
        crearTabla("javax.mail", "public", "final", "PasswordAuthentication",null);
        crearTabla("javax.mail.internet", "public", "", "MimeMessage",null);
        crearTabla("javax.mail.internet", "public", "", "InternetAddress",null);
        crearTabla("java.lang", "public", "", "Exception",null);
        crearTabla("java.lang", "public", "", "Runnable",null);
        crearTabla("java.lang", "public", "", "Object",null);

        agregarAtribMetodo("java.awt", "Color", "public static", "Color", "BLACK", false, "clase");
        agregarAtribMetodo("java.awt", "Color", "public static", "Color", "BLUE", false, "clase");
        agregarAtribMetodo("java.awt", "Color", "public static", "Color", "CYAN", false, "clase");
        agregarAtribMetodo("java.awt", "Color", "public static", "Color", "DARK_GRAY", false, "clase");
        agregarAtribMetodo("java.awt", "Color", "public static", "Color", "GRAY", false, "clase");
        agregarAtribMetodo("java.awt", "Color", "public static", "Color", "GREEN", false, "clase");
        agregarAtribMetodo("java.awt", "Color", "public static", "Color", "LIGHT_GRAY", false, "clase");
        agregarAtribMetodo("java.awt", "Color", "public static", "Color", "MAGENTA", false, "clase");
        agregarAtribMetodo("java.awt", "Color", "public static", "Color", "ORANGE", false, "clase");
        agregarAtribMetodo("java.awt", "Color", "public static", "Color", "PINK", false, "clase");
        agregarAtribMetodo("java.awt", "Color", "public static", "Color", "RED", false, "clase");
        agregarAtribMetodo("java.awt", "Color", "public static", "Color", "WHITE", false, "clase");
        agregarAtribMetodo("java.awt", "Color", "public static", "Color", "YELLOW", false, "clase");
        agregarAtribMetodo("java.awt", "EventQueue", "public static", "void", "invokeLater(Runnable)", true, "clase");
        agregarAtribMetodo("java.util", "Properties", "public", "Object", "put(Object,Object)", true, "clase");
        agregarAtribMetodo("java.util", "Vector", "public", "boolean", "add(Object)", true, "clase");
        agregarAtribMetodo("java.util", "Vector", "public", "void", "add(int,Object)", true, "clase");
        agregarAtribMetodo("java.util", "Vector", "public", "void", "addElement(Object)", true, "clase");
        agregarAtribMetodo("java.util", "Vector", "public", "boolean", "contains(Object)", true, "clase");
        agregarAtribMetodo("java.util", "Vector", "public", "Object", "elementAt(int)", true, "clase");
        agregarAtribMetodo("java.util", "Vector", "public", "Object", "get(int)", true, "clase");
        agregarAtribMetodo("java.util", "Vector", "public", "int", "indexOf(Object)", true, "clase");
        agregarAtribMetodo("java.util", "Vector", "public", "int", "indexOf(Object,int)", true, "clase");
        agregarAtribMetodo("java.util", "Vector", "public", "void", "insertElementAt(Object,int)", true, "clase");
        agregarAtribMetodo("java.util", "Vector", "public", "boolean", "isEmpty()", true, "clase");
        agregarAtribMetodo("java.util", "Vector", "public", "int", "lastIndexOf(Object)", true, "clase");
        agregarAtribMetodo("java.util", "Vector", "public", "int", "lastIndexOf(Object,int)", true, "clase");
        agregarAtribMetodo("java.util", "Vector", "public", "boolean", "remove(Object)", true, "clase");
        agregarAtribMetodo("java.util", "Vector", "public", "Object", "remove(int)", true, "clase");
        agregarAtribMetodo("java.util", "Vector", "public", "void", "removeAllElements()", true, "clase");
        agregarAtribMetodo("java.util", "Vector", "public", "boolean", "removeElement(Object)", true, "clase");
        agregarAtribMetodo("java.util", "Vector", "public", "void", "removeElementAt(int)", true, "clase");
        agregarAtribMetodo("java.util", "Vector", "public", "int", "size()", true, "clase");
        agregarAtribMetodo("java.sql", "Connection", "public", "PreparedStatement", "prepareStatement(String)", true, "clase");
        agregarAtribMetodo("java.sql", "Connection", "public", "PreparedStatement", "prepareStatement(String,String[])", true, "clase");
        agregarAtribMetodo("java.sql", "Connection", "public", "PreparedStatement", "prepareStatement(String,int[])", true, "clase");
        agregarAtribMetodo("java.sql", "Connection", "public", "void", "close()", true, "clase");
        agregarAtribMetodo("java.sql", "DriverManager", "public static", "Connection", "getConnection(String,String,String)", true, "clase");
        agregarAtribMetodo("java.sql", "PreparedStatement", "public", "ResultSet", "executeQuery()", true, "clase");
        agregarAtribMetodo("java.sql", "ResultSet", "public", "boolean", "next()", true, "clase");
        agregarAtribMetodo("java.sql", "ResultSet", "public", "Object", "getObject(String)", true, "clase");
        agregarAtribMetodo("java.sql", "ResultSet", "public", "Object", "getObject(int)", true, "clase");
        agregarAtribMetodo("java.sql", "ResultSet", "public", "void", "close()", true, "clase");
        agregarAtribMetodo("java.sql", "SQLException", "public", "void", "printStackTrace()", true, "clase");
        agregarAtribMetodo("java.sql", "SQLException", "public", "String", "getMessage()", true, "clase");
        agregarAtribMetodo("javax.swing", "JLabel", "public static", "int", "CENTER", false, "clase");
        agregarAtribMetodo("javax.swing", "JLabel", "public static", "int", "LEFT", false, "clase");
        agregarAtribMetodo("javax.swing", "JLabel", "public static", "int", "RIGHT", false, "clase");
        agregarAtribMetodo("javax.swing", "JLabel", "", "", "", false, "clase");
        javax.swing.JLabel a;
        agregarAtribMetodo("", "", "", "", "", true, "clase");
        agregarAtribMetodo("paquete", "tabla", "mods", "tipo", "nombre", true, "entorno");
    }

    /**
     * crea un nuevo paquete si no existe
     * @param nom el nombre del paquete
     */
    public void crearPaquete(String nom){
        if(paquetes.contains(nom))
            return;
        Paquete p=new Paquete(nom);
        paquetes.addElement(p);
    }

    /**
     * busca y devuelve un paquete o null si no lo encuentra
     * @param nombre nombre del paquete a buscar
     * @return el paquete a buscar o null
     */
    public Paquete getPaquete(String nombre){
        Iterator i=paquetes.iterator();
        while(i.hasNext()){
            Paquete p=(Paquete)i.next();
            if(p.nombre.equalsIgnoreCase(nombre)){
                return p;
            }
        }
        //System.out.println("Error interno: no se encontro el paquete "+nombre);
        return null;
    }

    /**
     * agrega un tipo de dato a un paquete si no lo contiene aun
     * @param paquete donde se guarda el tipo de dato
     * @param tipo el tipo de dato a guardar
     */
    public void agregarTipo(String paquete,String tipo){
        Paquete p=getPaquete(paquete);
        if(p==null) return;
        if(!existeTipo(p,tipo))
            p.agregar(tipo);
    }

    /**
     * dice si existe un tipo en el paquete p
     * @param p paquete en el cual se busca el tipo
     * @param tipo tipo a buscar
     * @return true si existe, false si no existe
     */
    public boolean existeTipo(Paquete p,String tipo){
        if(p.contiene(tipo))
            return true;
        return false;
    }

    /**
     * dice si existe un tipo en el paquete
     * @param paquete paquete en el cual se busca el tipo
     * @param tipo tipo a buscar
     * @return true si existe, false si no existe
     */
    public boolean existeTipo(String paquete, String tipo){
        Paquete p=getPaquete(paquete);
        if(p==null) return false;
        if(p.contiene(tipo))
            return true;
        return false;
    }

/* ***********************Tabla************************ */

    /**
     * crea una nueva tabla si no existe
     * @param paquete nombre del paquete al que pertenece
     * @param acceso modificador de acceso (ej. public)
     * @param mod2 segundo modificador (ej. static)
     * @param nombre nombre de la clase
     */
    public void crearTabla(String paquete,String acceso,String mod2,String nombre,TipoDato hereda){
        if(getTabla(paquete,nombre)==null){
            TipoDato t=new TipoDato(paquete, acceso, mod2, nombre, hereda);
            tablas.addElement(t);
        }
    }

    /**
     * busca y devuelve una tabla o null si no la encuentra
     * @param paquete paquete donde se encuentra la tabla
     * @param nombre nombre de la tabla a buscar
     * @return la tabla a buscar o null
     */
    public TipoDato getTabla(String paquete, String nombre){
        Iterator i=tablas.iterator();
        while(i.hasNext()){
            TipoDato t=(TipoDato)i.next();
            if(t.nombre.equals(nombre) && t.paquete.equals(paquete)){
                return t;
            }
        }
        //System.out.println("Error interno: no se encontro el tipo de dato "+nombre);
        return null;
    }

    /**
     * agrega un atributo/metodo a una tabla si no lo contiene aun
     * @param paquete paquete donde se encuentra la tabla
     * @param tabla tabla a la que se agrega el atributo/metodo
     * @param mods modificadores de acceso (ej. public, static)
     * @param tipo el tipo de dato
     * @param nombre nombre del atributo/metodo
     * @param esMetodo boolean que dice si es metodo o no
     * @param entorno el entorno del atributo/metodo. ej: clase,setText(String),etc..
     */
    public void agregarAtribMetodo(String paquete,String tabla,String mods,String tipo, String nombre, boolean esMetodo, String entorno){
        TipoDato t=getTabla(paquete,tabla);
        if(t==null) return;
        if(!existeAtribMetodo(t, nombre, esMetodo, entorno))
            t.agregar(mods, tipo, nombre, esMetodo, entorno);
    }

    /**
     * dice si existe un atributo/metodo en una tabla
     * @param t tabla en la cual se busca el atributo/metodo
     * @param nombre nombre del atributo/metodo a buscar
     * @param esMetodo dice si el atributo/metodo a buscar es metodo o no
     * @param entorno el entorno del atributo/metodo a buscar
     * @return true si existe, false si no existe
     */
    public boolean existeAtribMetodo(TipoDato t,String nombre, boolean esMetodo, String entorno){
        return t.contiene(nombre, esMetodo, entorno);
    }

    /**
     * dice si existe un atributo/metodo en una tabla
     * @param paquete paquete donde se encuentra la tabla
     * @param tabla tabla en la cual se busca el atributo/metodo
     * @param nombre nombre del atributo/metodo a buscar
     * @param esMetodo dice si el atributo/metodo a buscar es metodo o no
     * @param entorno el entorno del atributo/metodo a buscar
     * @return true si existe, false si no existe
     */
    public boolean existeAtribMetodo(String paquete,String tabla,String nombre, boolean esMetodo, String entorno){
        TipoDato t=getTabla(paquete,tabla);
        if(t!=null)
            return t.contiene(nombre, esMetodo, entorno);
        return false;
    }

/* ************************************************************ */

    /**
     * dice si la clase con nombre 'clase' y paquete 'paquete' tiene acceso
     * a 'otraClase'.
     * Retorna true solo si la clase 'otraClase' esta en su mismo paquete o
     * esta en su listado de clases importadas.
     * @param paquete paquete del tipo de dato o clase en donde se busca
     * @param clase nombre del tipo de dato o clase en donde se busca
     * @param otraClase clase a buscar.
     * @return true si tiene acceso, false de lo contrario
     */
    public boolean tieneAcceso(String paquete,String clase,String otraClase){
        int iInd=otraClase.lastIndexOf('.');
        String otroPaq=paquete,otroNom=clase;
        if(iInd!=-1){
            otroPaq=otraClase.substring(0, iInd);
            otroNom=otraClase.substring(iInd+1);
        }
        TipoDato t=getTabla(otroPaq,otroNom);
        if(t!=null) return true;

        TipoDato tActual=getTabla(paquete,clase);
        boolean cond1=tActual.estaImportado(otraClase);
        return cond1;
    }
}
