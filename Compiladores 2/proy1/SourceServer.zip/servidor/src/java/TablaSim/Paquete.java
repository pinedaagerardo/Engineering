/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package TablaSim;

import java.util.Vector;

/**
 * nodo que almacena los tipos de datos en un vector para poder clasificar
 * por paquetes
 * @author g
 */
public class Paquete {

    /**nombre del paquete*/
    public String nombre;
    /**vector con los tipos de datos que pertenecen al paquete*/
    public Vector tipos=new Vector();

    /**
     * constructor de la clase
     * @param nom nombre del paquete
     */
    public Paquete(String nom){
        nombre=nom;
    }

    /**
     * agrega un nuevo tipo a la lista del paquete
     * @param tipo nuevo tipo por agregar
     */
    public void agregar(String tipo){
        tipos.addElement(tipo);
    }

    /**
     * dice si existe o no en el paquete el tipo recibido como parametro
     * @param tipo el tipo a verificar si existe en el paquete
     * @return true si existe, false de lo contrario
     */
    public boolean contiene(String tipo){
        return tipos.contains(tipo);
    }
}
