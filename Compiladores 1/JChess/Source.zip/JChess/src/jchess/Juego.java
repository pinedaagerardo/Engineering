/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jchess;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.Timer;

/**
 * Clase que contiene la mayoria de los métodos usados en el juego.
 * @author gerardo
 */
public class Juego {

    /**Vector que contiene las piezas q fueron capturadas por las piezas blancas*/
    Vector carcelB;
    /**Vector que contiene las piezas q fueron capturadas por las piezas negras*/
    Vector carcelN;
    /**numero que dice el jugador actual en turno. 0 = jug 2; 1 = jug 1*/
    public int jugActual;
    /**timers. se usan en los ciclos*/
    Timer tDo,tWhile,tLoop;
    /**tiempo en milisegundos entre cada ejecucion en los metodos*/
    private final int delay;
    /**dice si hay errores o no*/
    public static int error;
    /**dice cuantos movimientos se han hecho; hay un limite de 3 por turno*/
    public byte cantMov;
    
    /**Constructor de la clase*/
    public Juego(){
        error=0;
        delay=2000;
        carcelB=new Vector();
        carcelN=new Vector();
        jugActual=1;
        cantMov=0;
    }
    
    /**
     * manda la pieza a la carcel correspondiente.
     * @param p la pieza capturada
     * @param l letra que dice el color de la pieza que capturo
     */
    public void Comer(Pieza p,char l){
        char letra=Character.toLowerCase(l);
        p.estaEncarcelada=true;
        p.casillaActual=null;
        switch(letra){
            case'n':
                p.setLocation(App.carcel[0][carcelN.size()].getLocation());
                carcelN.addElement(p);
                break;
            case'b':
                p.setLocation(App.carcel[1][carcelB.size()].getLocation());
                carcelB.addElement(p);
        }
    }

    /**
     * Metodo que pregunta por los nombres de los jugadores y los retorna a la
     * clase de donde fue llamado el metodo para poder desplegarlos ahi.
     * @return un array tipo String de 2 posiciones con los nombres de los jugadores
     */
    public String[] crearJugadores() {
        JLabel l1=new JLabel("Jugador 1: "),l2=new JLabel("Jugador 2: ");
        JTextField txtJ1=new JTextField(),txtJ2=new JTextField();
        Object array[]=new Object[4];
        array[0]=l1;
        array[1]=txtJ1;
        array[2]=l2;
        array[3]=txtJ2;
        JOptionPane.showMessageDialog(new JFrame(),array,"Jugadores",JOptionPane.PLAIN_MESSAGE+JOptionPane.OK_CANCEL_OPTION);
        txtJ1.setText(txtJ1.getText().replace(" ", ""));
        txtJ2.setText(txtJ2.getText().replace(" ", ""));
        if(txtJ1.getText().length()==0 || txtJ2.getText().length()==0){
            JOptionPane.showMessageDialog(new JFrame(),"No se escribió los nombres de los jugadores","Error",JOptionPane.ERROR_MESSAGE);
            return null;
        }
        if(txtJ1.getText().equalsIgnoreCase(txtJ2.getText())){
            JOptionPane.showMessageDialog(new JFrame(),"Los jugadores no pueden tener el mismo nombre","Error",JOptionPane.ERROR_MESSAGE);
            return null;
        }
        String jugadores[]={txtJ1.getText(),txtJ2.getText()};
        return jugadores;
    }
    
    /**
     * Crea un tablero random listo para jugarlo y si los usuarios no quieren
     * ese tablero, genera uno nuevo hasta que los usuarios escojan uno.
     * @param frame el JFrame donde se despliega la aplicación
     */
    void crearTablero(App frame) {
        Vector posB=new Vector(),posN=new Vector();
        
        for(int i=0;i<8;i++){
            //negros
            while(true){
                Point xyN=new Point(posicionRandom(),posicionRandom());
                if(!(posN.contains(xyN) || posB.contains(xyN))){
                    try{
                        frame.remove(App.p[0][i]);
                    }catch(Exception e){}
                    App.p[0][i]=new Pieza();
                    frame.add(App.p[0][i]);
                    App.p[0][i].setBorder(null);
                    App.p[0][i].setLocation(App.oculto[xyN.x][xyN.y].getLocation());
                    App.oculto[xyN.x][xyN.y].piezaActual=new Point(0,i);
                    App.p[0][i].casillaActual=new Point(xyN.x,xyN.y);
                    frame.repaint();
                    App.p[0][i].PosX=App.p[0][i].getLocation().x;
                    App.p[0][i].PosY=App.p[0][i].getLocation().y;
                    posN.addElement(xyN);
                    break;
                }
            }
            //blancos
            while(true){
                Point xyB=new Point(posicionRandom(),posicionRandom());
                if(!(posN.contains(xyB) || posB.contains(xyB))){
                    try{
                        frame.remove(App.p[1][i]);
                    }catch(Exception e){}
                    App.p[1][i]=new Pieza();
                    frame.add(App.p[1][i]);
                    App.p[1][i].setBorder(null);
                    App.p[1][i].setLocation(App.oculto[xyB.x][xyB.y].getLocation());
                    App.oculto[xyB.x][xyB.y].piezaActual=new Point(1,i);
                    App.p[1][i].casillaActual=new Point(xyB.x,xyB.y);
                    frame.repaint();
                    App.p[1][i].PosX=App.p[1][i].getLocation().x;
                    App.p[1][i].PosY=App.p[1][i].getLocation().y;
                    posB.addElement(xyB);
                    break;
                }
            }
        }
        
        App.p[0][0].setIcon("img/torreN.gif");App.p[0][7].setIcon("img/torreN.gif");
        App.p[0][1].setIcon("img/caballoN.gif");App.p[0][6].setIcon("img/caballoN.gif");
        App.p[0][2].setIcon("img/alfilN.gif");App.p[0][5].setIcon("img/alfilN.gif");
        App.p[0][3].setIcon("img/reyN.gif");App.p[0][4].setIcon("img/reinaN.gif");
        
        App.p[1][0].setIcon("img/torreB.gif");App.p[1][7].setIcon("img/torreB.gif");
        App.p[1][1].setIcon("img/caballoB.gif");App.p[1][6].setIcon("img/caballoB.gif");
        App.p[1][2].setIcon("img/alfilB.gif");App.p[1][5].setIcon("img/alfilB.gif");
        App.p[1][3].setIcon("img/reyB.gif");App.p[1][4].setIcon("img/reinaB.gif");
        
        frame.repaint();
        
        App.p[0][0].Name=new String("torre1");App.p[0][7].Name=new String("torre2");
        App.p[0][0].setToolTipText("torre1");App.p[0][7].setToolTipText("torre2");
        App.p[0][0].tipo=new String("torreN");App.p[0][7].tipo=new String("torreN");
        App.p[0][1].Name=new String("caballo1");App.p[0][6].Name=new String("caballo2");
        App.p[0][1].setToolTipText("caballo1");App.p[0][6].setToolTipText("caballo2");
        App.p[0][1].tipo=new String("caballoN");App.p[0][6].tipo=new String("caballoN");
        App.p[0][2].Name=new String("alfil1");App.p[0][5].Name=new String("alfil2");
        App.p[0][2].setToolTipText("alfil1");App.p[0][5].setToolTipText("alfil2");
        App.p[0][2].tipo=new String("alfilN");App.p[0][5].tipo=new String("alfilN");
        App.p[0][3].Name=new String("rey");App.p[0][4].Name=new String("reina");
        App.p[0][3].setToolTipText("rey");App.p[0][4].setToolTipText("reina");
        App.p[0][3].tipo=new String("reyN");App.p[0][4].tipo=new String("reinaN");
        
        App.p[1][0].Name=new String("torre1");App.p[1][7].Name=new String("torre2");
        App.p[1][0].setToolTipText("torre1");App.p[1][7].setToolTipText("torre2");
        App.p[1][0].tipo=new String("torreB");App.p[1][7].tipo=new String("torreB");
        App.p[1][1].Name=new String("caballo1");App.p[1][6].Name=new String("caballo2");
        App.p[1][1].setToolTipText("caballo1");App.p[1][6].setToolTipText("caballo2");
        App.p[1][1].tipo=new String("caballoB");App.p[1][6].tipo=new String("caballoB");
        App.p[1][2].Name=new String("alfil1");App.p[1][5].Name=new String("alfil2");
        App.p[1][2].setToolTipText("alfil1");App.p[1][5].setToolTipText("alfil2");
        App.p[1][2].tipo=new String("alfilB");App.p[1][5].tipo=new String("alfilB");
        App.p[1][3].Name=new String("rey");App.p[1][4].Name=new String("reina");
        App.p[1][3].setToolTipText("rey");App.p[1][4].setToolTipText("reina");
        App.p[1][3].tipo=new String("reyB");App.p[1][4].tipo=new String("reinaB");
        
        carcelB.removeAllElements();
        carcelN.removeAllElements();
    }
    
    /**
     * edita los atributos de las piezas
     * @param pieza la pieza a editar
     * @param atributo el atributo a cambiar
     * @param valor el nuevo valor
     * @param jchess el juego actual
     */
    public void ejecutarCuerpoEditar(Object pieza,String atributo,Object valor){
        try{
            Pieza p=getPieza(pieza.toString(),App.p);
            if(atributo.equalsIgnoreCase("name")){
                p.Name=new String(valor.toString());
                p.setToolTipText(valor.toString());
            }
            else
                if(atributo.equalsIgnoreCase("picture"))
                    p.setIcon(valor.toString());
        }catch(Exception e){}
    }

    /**
     * ejecuta en serie las instrucciones
     * @param v vector con instrucciones
     * @param mili el retraso en milisegundos entre cada ejecucion
     */
    private void doInOrder(final Vector v,int mili) {
        tDo=new Timer(mili,new ActionListener() {
            int i=0;
          public void actionPerformed(ActionEvent evt) {
              Object[] tmp=(Object[])v.elementAt(i++);
              ejecutarCuerpo(tmp[0],tmp[1].toString(),tmp[2],tmp[3]);
              if(i==v.size()) 
                  tDo.stop();
          }
      });
      tDo.start();
    }
    
    /**
     * ejecuta una parte de codigo
     * @param p pieza que se usa
     * @param metodo metodo que se aplica
     * @param param1 parametro 1
     * @param param2 parametro 2
     * @param jchess juego actual
     */
    public boolean ejecutarCuerpo(Object pieza,String metodo,Object param1,Object param2){
        if(cantMov==3){
            JOptionPane.showMessageDialog(new JFrame(),"Solo 3 movimientos por turno","cantidad de movimientos",JOptionPane.ERROR_MESSAGE);
            return false;
        }
        cantMov++;
        
        Pieza p=null;
        try{
            p=getPieza(pieza.toString(),App.p);
        }catch(Exception e){
            System.out.println(e.getMessage()+": pieza null");
            return false;
        }
        try{
            if(metodo.equalsIgnoreCase("move"))
                p.myMove(Integer.parseInt(param1.toString()), Integer.parseInt(param2.toString()));
            else
                if(metodo.equalsIgnoreCase("moveto"))
                    p.moveTo(getPieza(param1.toString(),App.p));
                else
                    if(metodo.equalsIgnoreCase("movetoward"))
                        p.moveToward(getPieza(param1.toString(),App.p),Integer.parseInt(param2.toString()));
                    else
                        if(metodo.equalsIgnoreCase("moveawayfrom"))
                            p.moveAwayFrom(getPieza(param1.toString(),App.p),Integer.parseInt(param2.toString()));
                        else
                            if(metodo.equalsIgnoreCase("donothing")){
                            }
                            else
                                if(metodo.equalsIgnoreCase("doinorder")){//solo tomo en cuenta metodos
                                    doInOrder((Vector)param1,delay);//tiene varios Object[]
                                }else
                                    if(metodo.equalsIgnoreCase("dotogheter")){
                                        doInOrder((Vector)param1,1);//tiene varios Object[]
                                    }else
                                        if(metodo.equalsIgnoreCase("if")){
                                             Object[] tmp=(Object[])param1;
                                            Vector[] tmp2=(Vector[])param2;
                                            metodoIf(tmp,tmp2);
                                        }else
                                            if(metodo.equalsIgnoreCase("loop")){
                                                Vector tmp=(Vector)param2;
                                                loop(Integer.parseInt(param1.toString()),tmp);
                                            }else
                                                if(metodo.equalsIgnoreCase("while")){
                                                    String[] tmp=(String[])param1;
                                                    Vector tmp2=(Vector)param2;
                                                    metodoWhile(tmp,tmp2);//condicion,datos
                                                }else
                                                    if(metodo.equalsIgnoreCase("print")){
                                                        App.txtHistoria.append(param1.toString()+"\n");
                                                    }else
                                                        if(metodo.equalsIgnoreCase("stats")){
                                                            //grafica
                                                        }else{
                                                            //error
                                                        }
        }catch(Exception e){
            System.out.println(e.getMessage()+": error metodo");
            return false;
        }
        return true;
    }
    
    /**
     * Dice si es valida una condicion recibida del parser
     * @param p la pieza usada en la condicion
     * @param attrib el atributo usado de la pieza
     * @param op el operador a usar en la condicion
     * @param val el valor a verificar
     * @return true o false, si la condicion es verdadera o falsa
     */
    private boolean esCondicionValida(Pieza p,String attrib,String op,String val){
        try{
            if(attrib.equalsIgnoreCase("posx"))
                if(op.equals("=="))
                    return (p.casillaActual.x==Integer.parseInt(val));
                else
                    if(op.equals("<"))
                        return (p.casillaActual.x<Integer.parseInt(val));
                    else
                        if(op.equals(">"))
                            return (p.casillaActual.x>Integer.parseInt(val));
                        else
                            if(op.equals("<="))
                                return (p.casillaActual.x<=Integer.parseInt(val));
                            else
                                if(op.equals(">="))
                                    return (p.casillaActual.x>=Integer.parseInt(val));
                                else
                                    if(op.equals("!="))
                                        return (p.casillaActual.x!=Integer.parseInt(val));
                                    else
                                        return false;
            else
                if(attrib.equalsIgnoreCase("posy"))
                    if(op.equals("=="))
                        return (p.casillaActual.y==Integer.parseInt(val));
                    else
                        if(op.equals("<"))
                            return (p.casillaActual.y<Integer.parseInt(val));
                        else
                            if(op.equals(">"))
                                return (p.casillaActual.y>Integer.parseInt(val));
                            else
                                if(op.equals("<="))
                                    return (p.casillaActual.y<=Integer.parseInt(val));
                                else
                                    if(op.equals(">="))
                                        return (p.casillaActual.y>=Integer.parseInt(val));
                                    else
                                        if(op.equals("!="))
                                            return (p.casillaActual.y!=Integer.parseInt(val));
                                        else
                                            return false;
                else
                    if(attrib.equalsIgnoreCase("name"))
                        if(op.equals("=="))
                            return (p.Name.equalsIgnoreCase(val));
                        else
                            if(op.equals("!="))
                                return (!p.Name.equalsIgnoreCase(val));
                            else
                                return false;
                    else
                        if(attrib.equalsIgnoreCase("picture"))
                            if(op.equals("=="))
                                return (p.Picture.equalsIgnoreCase(val));
                            else
                                if(op.equals("!="))
                                    return (!p.Picture.equalsIgnoreCase(val));
                                else
                                    return false;
                        else
                            return false;
        }catch(Exception e){return false;}
    }
    
    /**
     * Devuelve la pieza que su nombre coincida con el String recibido.
     * @param nombre el nombre con que se busca la pieza
     */
    public Pieza getPieza(String nombre,Pieza[][] p){
        for(int i=0;i<8;i++)
            if(p[jugActual][i].Name.equalsIgnoreCase(nombre)){
                if(p[jugActual][i].estaEncarcelada)
                    return null;
                
                return p[jugActual][i];
            }
        
        return null;
    }
    
    /**
     * Devuelve un número entero aleatorio entre 0 y 9
     * @return un número aleatorio entre 0 y 9
     */
    int posicionRandom(){
        int tmp=(int)(Math.random()*10);
        return tmp;
    }

    /**
     * ejecuta las instrucciones las veces que dice el parametro times
     * @param times la cantidad de veces que se repite el ciclo
     * @param tmp las instrucciones
     * @param jchess el juego actual
     */
    private void loop(final int times,final Vector v) {
        tLoop=new Timer(delay,new ActionListener() {
            int i=0,contador=0;
          public void actionPerformed(ActionEvent evt) {
              if(error==1){
                  error=0;
                  JOptionPane.showMessageDialog(new JFrame(),"Error","Error",JOptionPane.ERROR_MESSAGE);
                  tLoop.stop();
                  return;
              }
              
              while(i<v.size()){
                  Object[] tmp=(Object[])v.elementAt(i++);
                  ejecutarCuerpo(tmp[0],tmp[1].toString(),tmp[2],tmp[3]);
              }
              
              if(error==1){
                  error=0;
                  JOptionPane.showMessageDialog(new JFrame(),"Error","Error",JOptionPane.ERROR_MESSAGE);
                  tLoop.stop();
                  return;
              }
              
              i=0;
              contador++;
              if(contador==times)
                  tLoop.stop();
          }
      });
      tLoop.start();
    }

    /**
     * ejecuta la instruccion if
     * @param tmp la condicion
     * @param tmp2 las lineas a ejecutar
     * @param jchess el juego actual
     */
    private void metodoIf(Object[] condicion, Vector[] v) {
        if(esCondicionValida(getPieza(condicion[0].toString(), App.p),condicion[1].toString(),condicion[2].toString(),condicion[3].toString()))
            for(int i=0;i<v[0].size();i++){
                Object[] tmp=(Object[])v[0].elementAt(i);
                ejecutarCuerpo(tmp[0],tmp[1].toString(),tmp[2],tmp[3]);
            }
        else
            for(int i=0;i<v[1].size();i++){
                Object[] tmp=(Object[])v[1].elementAt(i);
                ejecutarCuerpo(tmp[0],tmp[1].toString(),tmp[2],tmp[3]);
            }
    }

    /**
     * repite las instrucciones mientras que es valida la condicion
     * @param condicion la condicion que valida el ciclo
     * @param v el vector de instrucciones
     * @param jchess el juego actual
     */
    private void metodoWhile(final String[] condicion,final Vector v) {
        tWhile=new Timer(delay,new ActionListener() {
            int i=0;
          public void actionPerformed(ActionEvent evt) {
              
              if(!esCondicionValida(getPieza(condicion[0],App.p),condicion[1],condicion[2],condicion[3])){
                  tWhile.stop();
                  return;
              }
              if(error==1){
                  error=0;
                  JOptionPane.showMessageDialog(new JFrame(),"Error","Error",JOptionPane.ERROR_MESSAGE);
                  tWhile.stop();
                  return;
              }
              
              while(i<v.size()){
                  Object[] tmp=(Object[])v.elementAt(i++);
                  ejecutarCuerpo(tmp[0],tmp[1].toString(),tmp[2],tmp[3]);
              }
              i=0;
              
              if(error==1){
                  error=0;
                  JOptionPane.showMessageDialog(new JFrame(),"Error","Error",JOptionPane.ERROR_MESSAGE);
                  tWhile.stop();
                  return;
              }
          }
      });
      tWhile.start();
    }
    
    /*public boolean Cargar(){//modificar
        File varArchivo;
        try{
            FileDialog dlg = new FileDialog(new JFrame(), "Cargar partida", FileDialog.LOAD);
            dlg.setVisible(true);
            if (dlg.getFile() == null) return false;
            varArchivo = new File(dlg.getDirectory() + dlg.getFile());
            return true;
        }catch(Exception e) {
            JOptionPane.showMessageDialog(new JFrame(),"El archivo no es una imágen válida","Error",JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }*/
}
