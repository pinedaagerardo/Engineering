/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jchess;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.Timer;

/**
 * Clase que hereda de un JLabel y se usa para las piezas del juego
 * @author gerardo
 */
public class Pieza extends JLabel {

    public final int w=50,h=w;
    /**Es la posición en pixeles de la coordenada X de la pieza*/
    public int PosX;
    /**Es la posición en pixeles de la coordenada Y de la pieza*/
    public int PosY;
    /**Es el nombre de la pieza*/
    public String Name;
    /**Dice si la pieza fue capturada*/
    boolean estaEncarcelada;
    /**Es el path del icono de la pieza*/
    public String Picture;
    /**Contiene un punto que indica la posición en el array de las piezas de la
     * pieza que esta situada sobre esta casilla.
     * SOLO SE USA PARA LAS CASILLAS OCULTAS.*/
    public Point piezaActual;
    /**Contiene un punto que indica la posición en el array oculto de la casilla
     * en la que esta situada la pieza.
     * SOLO SE USA PARA LAS PIEZAS DEL JUEGO.*/
    public Point casillaActual;
    /**Es el tipo de pieza, como "torre" o "rey"*/
    public String tipo;
    /**Es el reloj que se encarga de mover las piezas*/
    private Timer clk;
    
    /**
     * constructor de la clase
     */
    public Pieza(){
        casillaActual=piezaActual=null;
        estaEncarcelada=false;
        this.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        this.setSize(w, h);
        this.setVisible(true);
    }
    
    /**
     * Asigna un icono a la pieza. El icono se toma del path recibido como parametro.
     * retorna un valor booleano indicando si la operación falló o tuvo éxito.
     * @param path la ubicación del icono
     * @return true si tuvo exito la carga de la imagen, false de lo contrario
     */
    public boolean setIcon(String path){
        try{
            this.setIcon(new ImageIcon(path));
            Picture=new String(path);
            return true;
        }catch(Exception e){
            return false;
        }
    }
    
    /**
     * Mueve la pieza a la posición recibida como parámetro si es permitido.
     * @param fila la fila en el array a donde se tiene que mover la pieza
     * @param columna la columna en el array a donde se tiene que mover la pieza
     * @param pieza el nombre de la pieza
     * @param jchess el JFrame usado para jugar
     */
    public void myMove(int fila,int columna){
        if(estaEncarcelada){
            JOptionPane.showMessageDialog(new JFrame(),"La pieza "+Name+" esta encarcelada.","Error",JOptionPane.ERROR_MESSAGE);
            Juego.error=1;
            return;
        }
        if(!((fila>=0 && fila<10 && columna>=0 && columna<10) && !(fila==casillaActual.x && columna==casillaActual.y))){
            JOptionPane.showMessageDialog(new JFrame(),"Movimiento no válido.","Error",JOptionPane.ERROR_MESSAGE);
            Juego.error=1;
            return;
        }
        if(tipo.toLowerCase().startsWith("torre")){
            if(esMovimientoValido(0,fila,columna)){ //se puede mover en cruz?
                if(!esCaminoLibre(casillaActual.y,columna,fila,casillaActual.x,fila==casillaActual.x)){
                    JOptionPane.showMessageDialog(new JFrame(),"No se puede mover en esa dirección porque hay una pieza en el camino","Error",JOptionPane.ERROR_MESSAGE);
                    Juego.error=1;
                    return;
                }
                premover(fila,columna);
            }
            else{
                Juego.error=1;
                JOptionPane.showMessageDialog(new JFrame(),"La torre no puede moverse en esa dirección","Error",JOptionPane.ERROR_MESSAGE);
            }
        }
        else
            if(tipo.toLowerCase().startsWith("alfil")){
                if(esMovimientoValido(2,fila,columna)){ //se puede mover en diagonal?
                    if(!esCaminoLibreDiagonal(casillaActual.y,columna,fila,casillaActual.x)){
                        JOptionPane.showMessageDialog(new JFrame(),"No se puede mover en esa dirección porque hay una pieza en el camino","Error",JOptionPane.ERROR_MESSAGE);
                        Juego.error=1;
                        return;
                    }
                    premover(fila,columna);
                }
                else{
                    Juego.error=1;
                    JOptionPane.showMessageDialog(new JFrame(),"El alfil no puede moverse en esa dirección","Error",JOptionPane.ERROR_MESSAGE);
                }
            }
            else
                if(tipo.toLowerCase().startsWith("caballo")){
                    if(esMovimientoValido(1,fila,columna)) //es movimiento del caballo?
                        premover(fila,columna);
                    else{
                        Juego.error=1;
                        JOptionPane.showMessageDialog(new JFrame(),"El caballo no puede moverse en esa dirección","Error",JOptionPane.ERROR_MESSAGE);
                    }
                }
                else
                    if(tipo.toLowerCase().startsWith("rey")){
                        if(esMovimientoValido(3,fila,columna)) //es movimiento del rey?
                            premover(fila,columna);
                        else{
                            Juego.error=1;
                            JOptionPane.showMessageDialog(new JFrame(),"El rey no puede moverse en esa dirección","Error",JOptionPane.ERROR_MESSAGE);
                        }
                    }
                    else
                        if(tipo.toLowerCase().startsWith("reina")){
                            if(esMovimientoValido(2,fila,columna)){ //es movimiento del alfil?
                                if(!esCaminoLibreDiagonal(casillaActual.y,columna,fila,casillaActual.x)){
                                    Juego.error=1;
                                    JOptionPane.showMessageDialog(new JFrame(),"No se puede mover en esa dirección porque hay una pieza en el camino","Error",JOptionPane.ERROR_MESSAGE);
                                    return;
                                }
                                premover(fila,columna);
                            }
                            else
                                if(esMovimientoValido(0,fila,columna)){ //es ,movimiento de la torre?
                                    if(!esCaminoLibre(casillaActual.y,columna,fila,casillaActual.x,fila==casillaActual.x)){
                                        Juego.error=1;
                                        JOptionPane.showMessageDialog(new JFrame(),"No se puede mover en esa dirección porque hay una pieza en el camino","Error",JOptionPane.ERROR_MESSAGE);
                                        return;
                                    }
                                    premover(fila,columna);
                                }
                                else{
                                Juego.error=1;
                                    JOptionPane.showMessageDialog(new JFrame(),"La reina no puede moverse en esa dirección","Error",JOptionPane.ERROR_MESSAGE);
                                }
                        }
        
        //this.setLocation(App.oculto[fila][columna].getLocation());
    }
    
    /**
     * Valida el movimiento de una pieza.
     * 0 = torre
     * 1 = caballo
     * 2 = alfil
     * 3 = rey
     * default lo puse para que no marque error por el retorno boolean
     * @param pieza un numero que representa la pieza
     * @param fila la fila destino
     * @param columna la columna destino
     * @return true o false, es movimiento valido de la pieza o no?
     */
    private boolean esMovimientoValido(int pieza,int fila,int columna){
        switch(pieza){
            case 0:
                return (fila==casillaActual.x || columna==casillaActual.y);
            case 1:
                return ((Math.abs(fila-casillaActual.x)==2 && Math.abs(columna-casillaActual.y)==1) || (Math.abs(fila-casillaActual.x)==1 && Math.abs(columna-casillaActual.y)==2));
            case 2:
                return (Math.abs(fila-casillaActual.x)==Math.abs(columna-casillaActual.y));
            case 3:
                return(Math.abs(fila-casillaActual.x)<=1 && Math.abs(columna-casillaActual.y)<=1);
            default:
                return false;
        }
    }
    
    /**
     * Valida si la pieza se tiene que mover, tiene que comer o intercambiar con
     * otra pieza y lo ejecuta.
     * @param fila la fila destino
     * @param columna la columna destino
     * @param jchess el juego actual
     */
    private void premover(int fila,int columna){
        if(App.oculto[fila][columna].piezaActual==null)
            mover(fila,columna,App.oculto[fila][columna].getLocation(),this,null);
        else{
            int x=App.oculto[fila][columna].piezaActual.x;
            int y=App.oculto[fila][columna].piezaActual.y;
            String t=App.p[x][y].tipo.toLowerCase();
            if(t.charAt(t.length()-1)==tipo.toLowerCase().charAt(tipo.length()-1))
                intercambiar(fila,columna,App.oculto[fila][columna].getLocation());
            else{
                mover(fila,columna,App.oculto[fila][columna].getLocation(),this,null);
                App.juego.Comer(App.p[x][y],tipo.charAt(tipo.length()-1));
            }
        }
    }
    
    /**
     * Dice si el camino que tiene que recorrer la pieza esta obstruido o no.
     * @param colActual la columna actual de la pieza
     * @param columnaFinal la columna final de la pieza
     * @param filaFinal la fila final de la pieza
     * @param filaActual la fila actual de la pieza
     * @param esMismaFila indica si la nueva casilla de la pieza esta en la misma
     * fila o en la misma columna que la casilla actual
     * @return true si el camino no esta obstruido, false de lo contrario
     */
    private boolean esCaminoLibre(int colActual,int columnaFinal,int filaFinal,int filaActual,boolean esMismaFila){
        if(esMismaFila){
            for(int tmpCol=colActual+1;tmpCol<columnaFinal;tmpCol++)
                if(App.oculto[filaFinal][tmpCol].piezaActual!=null)
                    return false;

            for(int tmpCol=colActual-1;tmpCol>columnaFinal;tmpCol--)
                if(App.oculto[filaFinal][tmpCol].piezaActual!=null)
                    return false;
        }
        else{
            for(int tmpFila=filaActual+1;tmpFila<filaFinal;tmpFila++)
                if(App.oculto[tmpFila][columnaFinal].piezaActual!=null)
                    return false;

            for(int tmpFila=filaActual-1;tmpFila>filaFinal;tmpFila--)
                if(App.oculto[tmpFila][columnaFinal].piezaActual!=null)
                    return false;
        }
        return true;
    }
    
    /**
     * Dice si el camino diagonal que tiene que recorrer la pieza esta obstruido
     * o no.
     * @param colActual la columna actual de la pieza
     * @param columnaFinal la columna final de la pieza
     * @param filaFinal la fila final de la pieza
     * @param filaActual la fila actual de la pieza
     * @return true si el camino no esta obstruido, false de lo contrario
     */
    private boolean esCaminoLibreDiagonal(int colActual,int columnaFinal,int filaFinal,int filaActual){
        if(filaFinal>filaActual){
            if(columnaFinal>colActual){
                int tmpCol=colActual+1;
                for(int tmpFila=filaActual+1;tmpFila<filaFinal;tmpFila++,tmpCol++)
                    if(App.oculto[tmpFila][tmpCol].piezaActual!=null)
                        return false;
            }else{
                int tmpCol=colActual-1;
                for(int tmpFila=filaActual+1;tmpFila<filaFinal;tmpFila++,tmpCol--)
                    if(App.oculto[tmpFila][tmpCol].piezaActual!=null)
                        return false;
            }
        }else{
            if(columnaFinal>colActual){
                int tmpCol=colActual+1;
                for(int tmpFila=filaActual-1;tmpFila>filaFinal;tmpFila--,tmpCol++)
                    if(App.oculto[tmpFila][tmpCol].piezaActual!=null)
                        return false;
            }else{
                int tmpCol=colActual-1;
                for(int tmpFila=filaActual-1;tmpFila>filaFinal;tmpFila--,tmpCol--)
                    if(App.oculto[tmpFila][tmpCol].piezaActual!=null)
                        return false;
            }
        }
        return true;
    }

    /**
     * intercambia de lugar dos piezas
     * @param filaFinal la fila destino de la pieza actual
     * @param columnaFinal la columna destino de la pieza actual
     * @param ptoFinal el punto en pixeles destino de la pieza actual
     * @param jchess el juego actual
     */
    private void intercambiar(int filaFinal, int columnaFinal, Point ptoFinal) {
        Point ptoPfinal=App.oculto[filaFinal][columnaFinal].piezaActual;
        Pieza p=App.p[ptoPfinal.x][ptoPfinal.y];
        mover(filaFinal, columnaFinal, ptoFinal, this,p);
    }

    /**
     * Mueve la pieza a una posición determinada
     * @param f el numero de fila en el tablero a donde se quiere mover la pieza
     * @param c el numero de columna en el tablero a donde se quiere mover la pieza
     * @param p el punto en pixeles a donde se quiere mover la pieza
     * @param pieza la pieza que se quiere mover
     */
    private void mover(final int f,final int c,final Point p,final Pieza pieza,final Pieza pieza2) {
        clk=new Timer(10,new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                if(pieza.getLocation().x<p.x)
                    pieza.setLocation(pieza.getLocation().x+10, pieza.getLocation().y);
                if(pieza.getLocation().x>p.x)
                    pieza.setLocation(pieza.getLocation().x-10, pieza.getLocation().y);
                if(pieza.getLocation().y<p.y)
                    pieza.setLocation(pieza.getLocation().x, pieza.getLocation().y+10);
                if(pieza.getLocation().y>p.y)
                    pieza.setLocation(pieza.getLocation().x, pieza.getLocation().y-10);
                
                if(pieza.getLocation().x==p.x && pieza.getLocation().y==p.y){
                    if(pieza2!=null){
                        if(pieza2.getLocation().x<PosX)
                            pieza2.setLocation(pieza2.getLocation().x+10, pieza2.getLocation().y);
                        if(pieza2.getLocation().x>PosX)
                            pieza2.setLocation(pieza2.getLocation().x-10, pieza2.getLocation().y);
                        if(pieza2.getLocation().y<PosY)
                            pieza2.setLocation(pieza2.getLocation().x, pieza2.getLocation().y+10);
                        if(pieza2.getLocation().y>PosY)
                            pieza2.setLocation(pieza2.getLocation().x, pieza2.getLocation().y-10);

                        if(pieza2.getLocation().x==PosX && pieza2.getLocation().y==PosY){
                            clk.stop();
                            pieza2.PosX=PosX;
                            pieza2.PosY=PosY;
                            Point tmpP=App.oculto[casillaActual.x][casillaActual.y].piezaActual.getLocation();
                            Point tmpP2=App.oculto[pieza2.casillaActual.x][pieza2.casillaActual.y].piezaActual.getLocation();
                            App.oculto[pieza2.casillaActual.x][pieza2.casillaActual.y].piezaActual=null;
                            pieza2.casillaActual.setLocation(casillaActual);
                            App.oculto[casillaActual.x][casillaActual.y].piezaActual=new Point(tmpP2);
                            
                            PosX=p.x;
                            PosY=p.y;
                            casillaActual.setLocation(f,c);
                            App.oculto[f][c].piezaActual=new Point(tmpP);
                        }
                    }else{
                        clk.stop();
                        PosX=p.x;
                        PosY=p.y;
                        Point tmpP=App.oculto[casillaActual.x][casillaActual.y].piezaActual.getLocation();
                        App.oculto[casillaActual.x][casillaActual.y].piezaActual=null;
                        casillaActual.setLocation(f,c);
                        App.oculto[f][c].piezaActual=new Point(tmpP);
                    }
                }
            }
        });
        
        clk.start();
        
    }

    /**
     * Intercambia de posicion dos piezas
     * @param p la pieza destino
     * @param jchess el juego actual
     */
    public void moveTo(Pieza p){
        if(p.estaEncarcelada){
            Juego.error=1;
            JOptionPane.showMessageDialog(new JFrame(),"Movimiento no válido","Error",JOptionPane.ERROR_MESSAGE);
            return;
        }
        this.myMove(p.casillaActual.x, p.casillaActual.y);
    }
    
    /**
     * Acerca la pieza actual x casillas hacia la pieza p
     * @param p la pieza hacia donde se mueve la pieza actual
     * @param x la cantidad de casillas que se acerca la pieza actual
     * @param jchess el juego actual
     */
    public void moveToward(Pieza p,int x){
        if(p.estaEncarcelada){
            Juego.error=1;
            JOptionPane.showMessageDialog(new JFrame(),"Movimiento no válido","Error",JOptionPane.ERROR_MESSAGE);
            return;
        }
        Point pto=p.casillaActual;
        if(casillaActual.x>pto.x){
            if(casillaActual.y>pto.y){
                if(esMovimientoValido(2, pto.x, pto.y)){
                    this.myMove(casillaActual.x-x, casillaActual.y-x);
                    return;
                }
            }else{
                if(casillaActual.y==pto.y){
                    if(esMovimientoValido(0, pto.x, pto.y)){
                        this.myMove(casillaActual.x-x, casillaActual.y);
                        return;
                    }
                }else{
                    if(esMovimientoValido(2, pto.x, pto.y)){
                        this.myMove(casillaActual.x-x, casillaActual.y+x);
                        return;
                    }
                }
            }
        }else{
            if(casillaActual.x==pto.x){
                if(casillaActual.y<pto.y){
                    if(esMovimientoValido(0, pto.x, pto.y)){
                        this.myMove(casillaActual.x, casillaActual.y+x);
                        return;
                    }
                }else{
                    if(esMovimientoValido(0, pto.x, pto.y)){
                        this.myMove(casillaActual.x, casillaActual.y-x);
                        return;
                    }
                }
            }else{
                if(casillaActual.y<pto.y){
                    if(esMovimientoValido(2, pto.x, pto.y)){
                        this.myMove(casillaActual.x+x, casillaActual.y+x);
                        return;
                    }
                }else{
                    if(casillaActual.y==pto.y){
                        if(esMovimientoValido(0, pto.x, pto.y)){
                            this.myMove(casillaActual.x+x, casillaActual.y);
                            return;
                        }
                    }else{
                        if(esMovimientoValido(2, pto.x, pto.y)){
                            this.myMove(casillaActual.x+x, casillaActual.y-x);
                            return;
                        }
                    }
                }
            }
        }
        
        Juego.error=1;
        JOptionPane.showMessageDialog(new JFrame(), "No se puede mover en esa dirección", "Error", JOptionPane.ERROR_MESSAGE);
    }

    /**
     * Aleja la pieza actual x casillas de la pieza p
     * @param p la pieza de donde se aleja la pieza actual
     * @param x la cantidad de casillas que se aleja la pieza actual
     * @param jchess el juego actual
     */
    public void moveAwayFrom(Pieza p,int x){
        moveToward(p,0-x);
    }
    
}
