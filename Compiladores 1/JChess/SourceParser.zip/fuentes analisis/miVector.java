package jchess;
import java.util.*;

public class miVector{
	
	private Vector[] vectorif;
	private Vector vectordo;

	public miVector(){
		vectorif=new Vector[2];
		vectorif[0]=new Vector();
		vectorif[1]=new Vector();
		
		vectordo=new Vector();
	}

	public void addIf(Object[] dato){
		vectorif[0].addElement(dato);
	}

	public void addElse(Object[] dato){
		vectorif[1].addElement(dato);
	}

	public Vector[] getDatosIf(){
		return vectorif;
	}

	public void limpiarIf(){
		vectorif[0].clear();
		vectorif[1].clear();
	}

	public void addDo(Object[] dato){
		vectordo.addElement(dato);
	}

	public Vector getDatosDo(){
		return vectordo;
	}

	public void limpiarDo(){
		vectordo.clear();
	}
}
