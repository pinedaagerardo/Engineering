import javax.swing.*;
import java.io.*;
import java.util.*;


public class reporte{

public static boolean existe=false;
private static Date d;
private static GregorianCalendar g;

public static void reportar(int lin,int col, String ti, String desc){
	try{
	RandomAccessFile fileout=new RandomAccessFile("Reporte de errores.htm","rw");
	if(!existe){
		fileout.setLength(0);
		fileout.writeBytes("<html>\n");
		fileout.writeBytes("<head>\n");
		fileout.writeBytes("<title>Reporte de errores</title>\n");
		fileout.writeBytes("</head>\n");
		fileout.writeBytes("<body bgcolor=#000F00 text=white>\n");
		fileout.writeBytes("<br><p>\n");
		fileout.writeBytes("<marquee behavior=alternate width=50% height=60 align=center><b><i>Reporte de Errores<i></b></marquee>\n");
		fileout.writeBytes("<br><br><p>\n");
		fileout.writeBytes("<table width=100% border=1>\n");
		fileout.writeBytes("<tr align=center>\n");
		fileout.writeBytes("<td width=13%> <strong>LINEA</strong> </td>\n");
		fileout.writeBytes("<td width=13%> <strong>COLUMNA</strong> </td>\n");
		fileout.writeBytes("<td width=13%> <strong>TIPO</strong> </td>\n");
		fileout.writeBytes("<td width=35%> <strong>DESCRIPCION</strong> </td>\n");
		fileout.writeBytes("<td width=13%> <strong>FECHA</strong> </td>\n");
		fileout.writeBytes("<td width=13%> <strong>HORA</strong> </td>\n");
		fileout.writeBytes("</tr>\n");
		fileout.writeBytes("</table></body></html>");
		existe=true;
	}
	d=new Date();
	g=new GregorianCalendar();
	g.setTime(d);
	fileout.seek((fileout.length())-22);
	fileout.writeBytes("<tr align=center>\n");
	fileout.writeBytes("<td width=13%> <strong>"+lin+"</strong> </td>\n");
	fileout.writeBytes("<td width=13%> <strong>"+col+"</strong> </td>\n");
	fileout.writeBytes("<td width=13%> <strong>"+ti+"</strong> </td>\n");
	fileout.writeBytes("<td width=35%> <strong>"+desc+"</strong> </td>\n");
	fileout.writeBytes("<td width=13%> <strong>"+g.get(Calendar.DATE)+"/"+(g.get(Calendar.MONTH)+1)+"/"+g.get(Calendar.YEAR)+"</strong> </td>\n");
	fileout.writeBytes("<td width=13%> <strong>"+g.get(Calendar.HOUR)+":"+g.get(Calendar.MINUTE)+":"+g.get(Calendar.SECOND)+"</strong> </td>\n");
	fileout.writeBytes("</tr>\n");
	fileout.close();
	}catch(IOException e){JOptionPane.showMessageDialog(null,"No se pudo guardar","Error",JOptionPane.ERROR_MESSAGE);}
}
}
