public class myToken{

public int linea,columna;
public String lexema;

public myToken(String lex,int lin,int col){
linea=lin;
columna=col;
lexema=lex;
}

public String getLexema(){
return lexema;
}

public int getLinea(){
return linea;
}

public int getColumna(){
return columna;
}
}
