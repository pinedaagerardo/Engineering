package sopadeletras;

/**
 * clase que maneja los simbolos de los analizadores
 * @author gerardo
 */
public class myToken{

public int linea,columna;
public String lexema;

/**
 * es el constructor. crea un nuevo myToken
 * @param lex el lexema del token
 * @param lin la linea del token
 * @param col la columna del token
 */
public myToken(String lex,int lin,int col){
linea=lin;
columna=col;
lexema=lex;
}

/**
 * devuelve el lexema del token como un String
 * @return un String conteniendo el lexema del token
 */
public String getLexema(){
return lexema;
}

/**
 * devuelve la linea del token como Integer
 * @return un Integer conteniendo la linea del token
 */
public int getLinea(){
return linea;
}

/**
 * devuelve la columna del token como Integer
 * @return un Integer conteniendo la columna del token
 */
public int getColumna(){
return columna;
}
}
