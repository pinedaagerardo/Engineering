/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sopadeletras;

/**
 *
 * @author gerardo
 */
public class Main {

    /**esta clase solo inicializa la aplicacion
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        myGui app=new myGui();
        app.setVisible(true);
    }

}
