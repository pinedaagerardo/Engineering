/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sopadeletras;

import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.util.Vector;
import javax.swing.SwingConstants;

/**
 * Clase que maneja todo lo relacionado con el pintado de la tabla
 * @author gerardo
 */
public class ColorRenderer extends JLabel implements TableCellRenderer {

    //private Font myFont; //la letra que voy a usar
    
    private Vector filas,columnas; //vectores que almacenan las coordenadas de las celdas que se van a pintar
    
    /**Constructor de la clase.
     * Recibe como parametro 2 vectores que tienen las coordenadas de las celdas
     * que se van a pintar.
     * los vectores tienen que estar sincronizados, entonces para saber la coordenada
     * de una celda cualquiera debemos hacer:
     * [f.elementAt(3) , c.elementAt(3)] ó [f.elementAt(x) , c.elementAt(x)]
     * debemos darle la misma posicion a los vectores porque asi esta sincronizado
     * uno con el otro y nos devuelve las coordenadas de la misma celda. ejemplo:
     * 
     * si queremos tomar la fila y la columna de la primera celda que se tiene que
     * pintar, hacemos:
     * fila = f.elementAt(0);
     * columna = c.elementAt(0)
     * 
     * @param f vector que contiene las filas de las celdas que se van a pintar
     * @param c vector que contiene las columnas de las celdas que se van a pintar
     */
    public ColorRenderer(Vector f,Vector c) {
        /*myFont=new Font("DejaVu Sans", Font.PLAIN, 13);
        setFont(myFont);*/
        
        setHorizontalAlignment(SwingConstants.CENTER);
        setOpaque(true); //es necesario para que se pueda ver el color del fondo
        filas=f;
        columnas=c;
    }

    /**Metodo que verifica celda por celda y compara con los vectores que
     * contienen las celdas que se van a pintar, y pinta las celdas en las que
     * encuentra coincidencias.
     * 
     */
    public Component getTableCellRendererComponent(JTable table,Object valor,boolean isSelected, boolean hasFocus,int row, int column){
        for(int i=0; i<filas.size() ;i++){
            if(row==Integer.parseInt(filas.elementAt(i).toString()) && column==Integer.parseInt(columnas.elementAt(i).toString())){
                setBackground(Color.GRAY);
                setText((valor==null)?"":valor.toString());
                return this; //encontro coincidencia entonces pinta la celda actual
            }
        }
        
        setText((valor==null)?"":valor.toString());
        setBackground(null);
        return this; //no encontro coincidencia entonces no pinta la celda actual
    }
}
