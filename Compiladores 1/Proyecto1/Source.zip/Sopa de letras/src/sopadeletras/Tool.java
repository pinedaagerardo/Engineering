/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sopadeletras;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Vector;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

/**
 * Esta clase tiene herramientas que sirven para desplegar mensajes, agregar
 * datos a tablas, etc.
 * @author gerardo
 */
public class Tool {
    
    /** Metodo que sirve para mandar un mensaje a la pantalla usando la clase
     * JOptionPane. Muestra como mensaje el parametro ex o el parametro msg si
     * ex es tipo null.
     * <n>
     * @param frame El frame al que pertenece el mensaje.
     * @param ex La excepcion que se muestra como mensaje (en caso de usar try-catch).
     * @param msg El mensaje a mostrar solo en caso que ex sea tipo null.
     * @param titulo El titulo del mensaje.
     * @param tipo El tipo de mensaje que se va a mostrar. Ej: JOptionPane.ERROR_MESSAGE
     */
    public void mensaje(JFrame frame,Exception ex,String msg,String titulo,int tipo) {
        String cad;
        JOptionPane.showMessageDialog(frame,cad=((ex!=null&&ex.getMessage()!=null)?ex.getMessage():msg),titulo,tipo);
        myGui.reportar(titulo+": "+cad);
    }
    
    /** Metodo que sirve para mostrar un dialogo con una pregunta para que el
     * usuario de una respuesta afirmativa o negativa. Retorna un valor boolean
     * dependiendo de la respuesta del usuario.
     * @param frame El frame al que pertenece el dialogo.
     * @param pregunta La pregunta a mostrar.
     * @param titulo El titulo del mensaje.
     * @return True si el usuario da una respuesta afirmativa, de lo contrario
     * False.
     */
    public boolean preguntar(JFrame frame,String pregunta,String titulo) {
        JOptionPane pane=new JOptionPane(pregunta,JOptionPane.QUESTION_MESSAGE,JOptionPane.YES_NO_OPTION);
        JDialog dialog=pane.createDialog(frame,titulo);
        dialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        dialog.setVisible(true);
        Object s=pane.getValue();
        if(((Integer)s).intValue()==JOptionPane.NO_OPTION)return false;
        else return true;
    }

    /**Metodo que recibe un vector de datos y los inserta a una tabla.
     * Si hay mas celdas que datos en el vector, las celdas sin dato se convierten
     * en un espacio en blanco; si hay mas datos que celdas, solo se asignan los
     * datos necesarios para llenar la tabla.
     * 
     * @param tabla la tabla a llenar con los datos del vector
     * @param V el vector que contiene los datos
     */
    public void llenarTabla(JTable tabla,Vector V) {
        int tmpCols,tmpFilas,pos=V.size()-1;
        Vector datos=new Vector();
        for(int i=pos;i>=0;i--)
            datos.addElement(V.elementAt(i));
        tmpCols=tabla.getColumnCount();
        tmpFilas=tabla.getRowCount();
        
        while(datos.size()<(tabla.getColumnCount()*tabla.getRowCount()))
            datos.addElement(" ");
        
        pos=0;
        String tmp;
        
        if(preguntar(new myGui(),"¿llenar horizontalmente?","forma de llenado"))
            for(int x=0;x<tmpFilas;x++)
                for(int y=0;y<tmpCols;y++){
                    tabla.setValueAt(tmp=datos.elementAt(pos++).toString().toUpperCase(), x, y);
                    myGui.array[x][y]=tmp;
                }
        else
            for(int x=0;x<tmpCols;x++)
                for(int y=0;y<tmpFilas;y++){
                    tabla.setValueAt(tmp=datos.elementAt(pos++).toString().toUpperCase(), y, x);
                    myGui.array[y][x]=tmp;
                }
    }

    /** Metodo que sirve para quitar todas las celdas de una tabla.
     * @param tabla la tabla a la que se aplica los cambios
     * @param modelo El modelo de la tabla
     */
    public void limpiarTabla(JTable tabla,DefaultTableModel modelo) {
        tabla.setDefaultRenderer(String.class, null);
        modelo.setRowCount(0);
    }
    
    /**Metodo que crea todas las celdas de la tabla y les asigna sus dimensiones
     * 
     * @param tabla la tabla a la que se le aplica los cambios
     * @param modelo el modelo que usa la tabla
     * @param medida el largo y alto que va a tener las celdas
     * @param filas la cantidad de filas que se quiere asignar a la tabla
     * @param columnas la cantidad de columnas que se quiere asignar a la tabla
     */
    public void crearTabla(JTable tabla,DefaultTableModel modelo,int medida,int filas,int columnas){
        modelo.setRowCount(filas);
        modelo.setColumnCount(columnas);
        for (int i=0;i<columnas;i++){
            tabla.getColumnModel().getColumn(i).setMinWidth(10);
            tabla.getColumnModel().getColumn(i).setPreferredWidth(medida);
        }
        tabla.setRowHeight(medida);
    }
        
        /** Metodo que muestra el archivo de entrada en el texto recibido como
         * parametro
         * @param frame la ventana donde se mostraria un mensaje de error si
         * llegara a ocurrir
         * @param text el texto donde se va a mostrar el archivo de entrada
         * @param archivoEntrada el archivo de entrada que se quiere mostrar en
         * el texto recibido
         */
        public void mostrarArchivo(JFrame frame,JTextArea text,File archivoEntrada){
            try{
                text.setText("");
                BufferedReader lector=new BufferedReader(new FileReader(archivoEntrada));
                String var;
                while( (var=lector.readLine())!=null ) text.append(var+"\n");
            }catch(Exception e){
                mensaje(frame,e,"Error de lectura","Error",JOptionPane.ERROR_MESSAGE);
            }
        }
        
        /**Metodo que carga algun archivo y lo parsea dependiendo del tipo de
         * archivo que sea.
         * 
         * @param frame el frame al que pertenece el JFileChooser
         * @param tipo el tipo de archivo que se va a tratar. Puede ser "pal" o "let"
         * @param option string que dice si hay que procesar un .pal con posicion o sin posicion.
         * sus valores pueden ser "con" o "sin".
         * @return true si se cargo el archivo y no tenia errores, false de lo contrario.
         */
        public boolean Abrir (JFrame frame, String tipo,String option) {
            final String t=tipo;
            JFileChooser fc=new JFileChooser();
            
            javax.swing.filechooser.FileFilter fflet=new javax.swing.filechooser.FileFilter() {
                public boolean accept(File f) {
                    return f.isDirectory() || f.getName().toLowerCase().endsWith("."+t);
                }
                public String getDescription() {
                    return ("."+t);
                }
            };
            
            fc.addChoosableFileFilter(fflet);
            try {
                int y=fc.showOpenDialog(frame);
                if(y==JFileChooser.APPROVE_OPTION)
                    if(fc.getSelectedFile()==null) return false;
                    if (fc.getSelectedFile().getName().toLowerCase().endsWith("."+t)){
                        String path = fc.getSelectedFile().getAbsolutePath().toString();
                        //scanner y parser*********************
                        if(tipo.equalsIgnoreCase("let")){
                            procesarLET(path);
                        }
                        else{
                            if(option.equalsIgnoreCase("con"))
                                procesarPALcon(path);
                            else
                                procesarPALsin(path);
                        }
                        //*************************************
                    }else{
                    mensaje(frame, null, "El archivo es incorrecto", "Error", JOptionPane.ERROR_MESSAGE);
                    return false;
                    }
                }catch(Exception e){
                    return false;
                }
            
            return true;
        }

        /**
         * metodo que procesa el analisis del archivo recibido como parametro.
         * este metodo analiza los archivos '.let'
         * @param path el archivo a analizar
         */
    private void procesarLET(String path) {
        myGui.reportar("Procesando "+path);
        
        letscanner scanner;
        letparser parser;
        try{
            scanner=new letscanner(new FileReader(path));
            parser=new letparser(scanner);
            try{
                parser.parse();
                myGui.reportar("Proceso Completado");
            }
            catch(Exception e){
                myGui.reportar("El archivo tiene errores");
            }
        }catch(java.io.FileNotFoundException e){
            myGui.reportar(e.getMessage());
        }
    }

    /**
     * metodo que procesa el analisis del archivo recibido como parametro.
     * este metodo analiza los archivos '.pal' con posicion
     * @param path el archivo a analizar
     */
    private void procesarPALcon(String path) {
        myGui.reportar("Procesando "+path);
        
        pal1scanner scanner;
        pal1parser parser;
        try{
            scanner=new pal1scanner(new FileReader(path));
            parser=new pal1parser(scanner);
            try{
                parser.parse();
                myGui.reportar("Proceso Completado");
            }
            catch(Exception e){
                myGui.reportar("El archivo tiene errores");
            }
        }catch(java.io.FileNotFoundException e){
            myGui.reportar(e.getMessage());
        }
    }

    /**
     * metodo que procesa el analisis del archivo recibido como parametro.
     * este metodo analiza los archivos '.pal' sin posicion
     * @param path el archivo a analizar
     */
    private void procesarPALsin(String path) {
        myGui.reportar("Procesando "+path);
        
        pal2scanner scanner;
        pal2parser parser;
        try{
            scanner=new pal2scanner(new FileReader(path));
            parser=new pal2parser(scanner);
            try{
                parser.parse();
                myGui.reportar("Proceso Completado");
            }
            catch(Exception e){
                myGui.reportar("El archivo tiene errores");
            }
        }catch(java.io.FileNotFoundException e){
            myGui.reportar(e.getMessage());
        }
    }
        
}
