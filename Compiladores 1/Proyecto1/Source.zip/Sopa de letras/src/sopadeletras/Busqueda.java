/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sopadeletras;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

/**
 * Clase que maneja las busquedas en la sopa de letras
 * @author gerardo
 */
public class Busqueda {

    int row[],column[];
    String on[],palabras[];
    public JTextArea texto=new JTextArea();
    
    /**hace busquedas sobre archivos que tienen posicion detallada
     * 
     * @param filas vector que almacena las filas a pintar
     * @param columnas vector que almacena las columnas a pintar
     */
    void conPosicion(Vector filas, Vector columnas) {
        myGui.reportar("Comenzando busquedas");
        instanciar();
        
        for(int i=0;i<palabras.length;i++){
            
            boolean admite=true;
            try{
                String strTMP=myGui.array[row[i]][column[i]];
            }catch(Exception e){
                myGui.reportar("Error: no existe la celda ["+(row[i]+1)+"]["+(1+column[i])+"]");
                admite=false;
            }
            
            if(admite){
            
            String cad=""; //para ir concatenando las letras
            int tam=palabras[i].length(); //longitud de la palabra a buscar
            Vector tmpf=new Vector(); /**cuidado al ponerlos adentro del ciclo**/
            Vector tmpc=new Vector(); /**cuidado al ponerlos adentro del ciclo**/
            if(on[i].equalsIgnoreCase(" ")){
                /***********************busquedas sin "on"*********************/
                //  r
                for(int j=0;(column[i]+j)<myGui.array[i].length && j<tam;j++){
                        int index;
                        cad=cad+(myGui.array[row[i]][column[i]+j]);
                        if(cad.charAt(index=(cad.length()-1))!=palabras[i].charAt(index))
                            break;
                        tmpf.addElement(row[i]);
                        tmpc.addElement(column[i]+j);
                    }
                    if(cad.equalsIgnoreCase(palabras[i])){
                        filas.addAll((Vector)tmpf.clone());
                        columnas.addAll((Vector)tmpc.clone());
                        tmpc.removeAllElements();tmpf.removeAllElements();
                    }cad="";
                //  l
                for(int j=0;(column[i]-j)>=0 && j<tam;j++){
                        int index;
                        cad=cad+(myGui.array[row[i]][column[i]-j]);
                        if(cad.charAt(index=(cad.length()-1))!=palabras[i].charAt(index))
                            break;
                        tmpf.addElement(row[i]);
                        tmpc.addElement(column[i]-j);
                    }
                    if(cad.equalsIgnoreCase(palabras[i])){
                        filas.addAll((Vector)tmpf.clone());
                        columnas.addAll((Vector)tmpc.clone());
                        tmpc.removeAllElements();tmpf.removeAllElements();
                    }cad="";
                //  u
                for(int j=0;(row[i]-j)>=0 && j<tam;j++){
                        int index;
                        cad=cad+(myGui.array[row[i]-j][column[i]]);
                        if(cad.charAt(index=(cad.length()-1))!=palabras[i].charAt(index))
                            break;
                        tmpf.addElement(row[i]-j);
                        tmpc.addElement(column[i]);
                    }
                    if(cad.equalsIgnoreCase(palabras[i])){
                        filas.addAll((Vector)tmpf.clone());
                        columnas.addAll((Vector)tmpc.clone());
                        tmpc.removeAllElements();tmpf.removeAllElements();
                    }cad="";
                //  d
                for(int j=0;(row[i]+j)<myGui.array.length && j<tam;j++){
                        int index;
                        cad=cad+(myGui.array[row[i]+j][column[i]]);
                        if(cad.charAt(index=(cad.length()-1))!=palabras[i].charAt(index))
                            break;
                        tmpf.addElement(row[i]+j);
                        tmpc.addElement(column[i]);
                    }
                    if(cad.equalsIgnoreCase(palabras[i])){
                        filas.addAll((Vector)tmpf.clone());
                        columnas.addAll((Vector)tmpc.clone());
                        tmpc.removeAllElements();tmpf.removeAllElements();
                    }cad="";
                //  ld
                for(int j=0;(row[i]+j)<myGui.array.length && (column[i]-j)>=0 && j<tam;j++){
                        int index;
                        cad=cad+(myGui.array[row[i]+j][column[i]-j]);
                        if(cad.charAt(index=(cad.length()-1))!=palabras[i].charAt(index))
                            break;
                        tmpf.addElement(row[i]+j);
                        tmpc.addElement(column[i]-j);
                    }
                    if(cad.equalsIgnoreCase(palabras[i])){
                        filas.addAll((Vector)tmpf.clone());
                        columnas.addAll((Vector)tmpc.clone());
                        tmpc.removeAllElements();tmpf.removeAllElements();
                    }cad="";
                //  lu
                for(int j=0;(row[i]-j)>=0 && (column[i]-j)>=0 && j<tam;j++){
                        int index;
                        cad=cad+(myGui.array[row[i]-j][column[i]-j]);
                        if(cad.charAt(index=(cad.length()-1))!=palabras[i].charAt(index))
                            break;
                        tmpf.addElement(row[i]-j);
                        tmpc.addElement(column[i]-j);
                    }
                    if(cad.equalsIgnoreCase(palabras[i])){
                        filas.addAll((Vector)tmpf.clone());
                        columnas.addAll((Vector)tmpc.clone());
                        tmpc.removeAllElements();tmpf.removeAllElements();
                    }cad="";
                //  ru
                for(int j=0;(row[i]-j)>=0 && (column[i]+j)<myGui.array[i].length && j<tam;j++){
                        int index;
                        cad=cad+(myGui.array[row[i]-j][column[i]+j]);
                        if(cad.charAt(index=(cad.length()-1))!=palabras[i].charAt(index))
                            break;
                        tmpf.addElement(row[i]-j);
                        tmpc.addElement(column[i]+j);
                    }
                    if(cad.equalsIgnoreCase(palabras[i])){
                        filas.addAll((Vector)tmpf.clone());
                        columnas.addAll((Vector)tmpc.clone());
                        tmpc.removeAllElements();tmpf.removeAllElements();
                    }cad="";
                //  rd
                for(int j=0;(row[i]+j)<myGui.array.length && (column[i]+j)<myGui.array[i].length && j<tam;j++){
                        int index;
                        cad=cad+(myGui.array[row[i]+j][column[i]+j]);
                        if(cad.charAt(index=(cad.length()-1))!=palabras[i].charAt(index))
                            break;
                        tmpf.addElement(row[i]+j);
                        tmpc.addElement(column[i]+j);
                    }
                    if(cad.equalsIgnoreCase(palabras[i])){
                        filas.addAll((Vector)tmpf.clone());
                        columnas.addAll((Vector)tmpc.clone());
                        tmpc.removeAllElements();tmpf.removeAllElements();
                    }cad="";
                /********************fin de busquedas sin "on"******************/
            }else{
                /********************busquedas con "on"***********************/
                if(on[i].equalsIgnoreCase("r")){
                    for(int j=0;(column[i]+j)<myGui.array[i].length && j<tam;j++){
                        int index;
                        cad=cad+(myGui.array[row[i]][column[i]+j]);
                        if(cad.charAt(index=(cad.length()-1))!=palabras[i].charAt(index))
                            break;
                        tmpf.addElement(row[i]);
                        tmpc.addElement(column[i]+j);
                    }
                    if(cad.equalsIgnoreCase(palabras[i])){
                        filas.addAll((Vector)tmpf.clone());
                        columnas.addAll((Vector)tmpc.clone());
                    }else myGui.reportar("no se encontro: SEARCH #"+palabras[i]+"# WHERE ROW="+(row[i]+1)+" AND COLUMN="+(column[i]+1)+" ON FILA");
                }else
                if(on[i].equalsIgnoreCase("l")){
                    for(int j=0;(column[i]-j)>=0 && j<tam;j++){
                        int index;
                        cad=cad+(myGui.array[row[i]][column[i]-j]);
                        if(cad.charAt(index=(cad.length()-1))!=palabras[i].charAt(index))
                            break;
                        tmpf.addElement(row[i]);
                        tmpc.addElement(column[i]-j);
                    }
                    if(cad.equalsIgnoreCase(palabras[i])){
                        filas.addAll((Vector)tmpf.clone());
                        columnas.addAll((Vector)tmpc.clone());
                    }else myGui.reportar("no se encontro: SEARCH #"+palabras[i]+"# WHERE ROW="+(row[i]+1)+" AND COLUMN="+(column[i]+1)+" ON NOT(FILA)");
                }else
                if(on[i].equalsIgnoreCase("u")){
                    for(int j=0;(row[i]-j)>=0 && j<tam;j++){
                        int index;
                        cad=cad+(myGui.array[row[i]-j][column[i]]);
                        if(cad.charAt(index=(cad.length()-1))!=palabras[i].charAt(index))
                            break;
                        tmpf.addElement(row[i]-j);
                        tmpc.addElement(column[i]);
                    }
                    if(cad.equalsIgnoreCase(palabras[i])){
                        filas.addAll((Vector)tmpf.clone());
                        columnas.addAll((Vector)tmpc.clone());
                    }else myGui.reportar("no se encontro: SEARCH #"+palabras[i]+"# WHERE ROW="+(row[i]+1)+" AND COLUMN="+(column[i]+1)+" ON NOT(COLUMNA)");
                }else
                if(on[i].equalsIgnoreCase("d")){
                    for(int j=0;(row[i]+j)<myGui.array.length && j<tam;j++){
                        int index;
                        cad=cad+(myGui.array[row[i]+j][column[i]]);
                        if(cad.charAt(index=(cad.length()-1))!=palabras[i].charAt(index))
                            break;
                        tmpf.addElement(row[i]+j);
                        tmpc.addElement(column[i]);
                    }
                    if(cad.equalsIgnoreCase(palabras[i])){
                        filas.addAll((Vector)tmpf.clone());
                        columnas.addAll((Vector)tmpc.clone());
                    }else myGui.reportar("no se encontro: SEARCH #"+palabras[i]+"# WHERE ROW="+(row[i]+1)+" AND COLUMN="+(column[i]+1)+" ON COLUMNA");
                }else
                if(on[i].equalsIgnoreCase("ld")){
                    for(int j=0;(row[i]+j)<myGui.array.length && (column[i]-j)>=0 && j<tam;j++){
                        int index;
                        cad=cad+(myGui.array[row[i]+j][column[i]-j]);
                        if(cad.charAt(index=(cad.length()-1))!=palabras[i].charAt(index))
                            break;
                        tmpf.addElement(row[i]+j);
                        tmpc.addElement(column[i]-j);
                    }
                    if(cad.equalsIgnoreCase(palabras[i])){
                        filas.addAll((Vector)tmpf.clone());
                        columnas.addAll((Vector)tmpc.clone());
                    }else myGui.reportar("no se encontro: SEARCH #"+palabras[i]+"# WHERE ROW="+(row[i]+1)+" AND COLUMN="+(column[i]+1)+" ON DIAGONAL_IZQUIERDA_ABAJO)");
                }else
                if(on[i].equalsIgnoreCase("lu")){
                    for(int j=0;(row[i]-j)>=0 && (column[i]-j)>=0 && j<tam;j++){
                        int index;
                        cad=cad+(myGui.array[row[i]-j][column[i]-j]);
                        if(cad.charAt(index=(cad.length()-1))!=palabras[i].charAt(index))
                            break;
                        tmpf.addElement(row[i]-j);
                        tmpc.addElement(column[i]-j);
                    }
                    if(cad.equalsIgnoreCase(palabras[i])){
                        filas.addAll((Vector)tmpf.clone());
                        columnas.addAll((Vector)tmpc.clone());
                    }else myGui.reportar("no se encontro: SEARCH #"+palabras[i]+"# WHERE ROW="+(row[i]+1)+" AND COLUMN="+(column[i]+1)+" ON DIAGONAL_IZQUIERDA_ARRIBA");
                }else
                if(on[i].equalsIgnoreCase("ru")){
                    for(int j=0;(row[i]-j)>=0 && (column[i]+j)<myGui.array[i].length && j<tam;j++){
                        int index;
                        cad=cad+(myGui.array[row[i]-j][column[i]+j]);
                        if(cad.charAt(index=(cad.length()-1))!=palabras[i].charAt(index))
                            break;
                        tmpf.addElement(row[i]-j);
                        tmpc.addElement(column[i]+j);
                    }
                    if(cad.equalsIgnoreCase(palabras[i])){
                        filas.addAll((Vector)tmpf.clone());
                        columnas.addAll((Vector)tmpc.clone());
                    }else myGui.reportar("no se encontro: SEARCH #"+palabras[i]+"# WHERE ROW="+(row[i]+1)+" AND COLUMN="+(column[i]+1)+" ON DIAGONAL_DERECHA_ARRIBA");
                }else
                if(on[i].equalsIgnoreCase("rd")){
                    for(int j=0;(row[i]+j)<myGui.array.length && (column[i]+j)<myGui.array[i].length && j<tam;j++){
                        int index;
                        cad=cad+(myGui.array[row[i]+j][column[i]+j]);
                        if(cad.charAt(index=(cad.length()-1))!=palabras[i].charAt(index))
                            break;
                        tmpf.addElement(row[i]+j);
                        tmpc.addElement(column[i]+j);
                    }
                    if(cad.equalsIgnoreCase(palabras[i])){
                        filas.addAll((Vector)tmpf.clone());
                        columnas.addAll((Vector)tmpc.clone());
                    }else myGui.reportar("no se encontro: SEARCH #"+palabras[i]+"# WHERE ROW="+(row[i]+1)+" AND COLUMN="+(column[i]+1)+" ON DIAGONAL_DERECHA_ABAJO");
                }
                /****************fin de busquedas con "on"**********************/
            }
            }
        } myGui.reportar("Se ha completado las busquedas");
    }

    /**hace busquedas sobre archivos no que tienen posicion detallada
     * 
     * @param filas vector que almacena las filas a pintar
     * @param columnas vector que almacena las columnas a pintar
     */
    void sinPosicion(Vector filas, Vector columnas) {
        myGui.reportar("Comenzando busquedas");
        
        palabras=new String[myGui.palabras.size()];
        for(int i=0;i<myGui.palabras.size();i++)
            palabras[i]=myGui.palabras.elementAt(i).toString();
        
        for(int z=0;z<palabras.length;z++){
            //rectas
            for(int j=0;j<myGui.array.length;j++){
                String cad="";
                for(int i=0;i<myGui.array[0].length;i++)
                    cad=cad+myGui.array[j][i];
                if(cad.contains(palabras[z])){
                    for(int x=0;x<palabras[z].length();x++){
                        filas.addElement(j);
                        columnas.addElement(cad.indexOf(palabras[z])+x);
                        if(x==0)almacenar(palabras[z],j,cad.indexOf(palabras[z])+x,"FILA");
                    }
                }
            }
            for(int j=0;j<myGui.array.length;j++){
                String cad="";
                for(int i=myGui.array[0].length-1;i>=0;i--)
                    cad=cad+myGui.array[j][i];
                if(cad.contains(palabras[z])){
                    for(int x=0;x<palabras[z].length();x++){
                        filas.addElement(j);
                        columnas.addElement(cad.length()-1-(cad.indexOf(palabras[z])+x));
                        if(x==0)almacenar(palabras[z],j,cad.length()-1-(cad.indexOf(palabras[z])+x),"NOT(FILA)");
                    }
                }
            }
            for(int j=0;j<myGui.array.length;j++){
                String cad="";
                for(int i=0;i<myGui.array.length;i++)
                    cad=cad+myGui.array[i][j];
                if(cad.contains(palabras[z])){
                    for(int x=0;x<palabras[z].length();x++){
                        columnas.addElement(j);
                        filas.addElement(cad.indexOf(palabras[z])+x);
                        if(x==0)almacenar(palabras[z],cad.indexOf(palabras[z])+x,j,"COLUMNA");
                    }
                }
            }
            for(int j=0;j<myGui.array.length;j++){
                String cad="";
                for(int i=myGui.array.length-1;i>=0;i--)
                    cad=cad+myGui.array[i][j];
                if(cad.contains(palabras[z])){
                    for(int x=0;x<palabras[z].length();x++){
                        columnas.addElement(j);
                        filas.addElement(cad.length()-1-(cad.indexOf(palabras[z])+x));
                        if(x==0)almacenar(palabras[z],cad.length()-1-(cad.indexOf(palabras[z])+x),j,"NOT(COLUMNA)");
                    }
                }
            }
            
            //diagonales
            Vector tmpf=new Vector();
            Vector tmpc=new Vector();
            
            //recorriendo la parte media de la matriz
            for(int i=0;i<myGui.array[0].length;i++){
                //  ru
                int index=0;
                for(int j=0;(myGui.array.length-1-j)>=0 && (j+i)<myGui.array[0].length;j++){
                    if(myGui.array[myGui.array.length-1-j][j+i].equalsIgnoreCase(String.valueOf(palabras[z].charAt(index++)))){
                        tmpf.addElement(myGui.array.length-1-j);
                        tmpc.addElement(j+i);
                        if(index==palabras[z].length()){
                            index=0;
                            filas.addAll((Vector)tmpf.clone());
                            columnas.addAll((Vector)tmpc.clone());
                            almacenar(palabras[z],Integer.parseInt(tmpf.firstElement().toString()),Integer.parseInt(tmpc.firstElement().toString()),"diagonal_derecha_arriba");
                            tmpf.removeAllElements();tmpc.removeAllElements();
                        }
                    }else{
                        index=0;
                        tmpf.removeAllElements();tmpc.removeAllElements();
                    }
                }
                //  lu
                index=0;
                for(int j=0;(myGui.array.length-1-j)>=0 && myGui.array[0].length-1-j-i>=0;j++){
                    if(myGui.array[myGui.array.length-1-j][myGui.array[0].length-1-j-i].equalsIgnoreCase(String.valueOf(palabras[z].charAt(index++)))){
                        tmpf.addElement(myGui.array.length-1-j);
                        tmpc.addElement(myGui.array[0].length-1-j-i);
                        if(index==palabras[z].length()){
                            index=0;
                            filas.addAll((Vector)tmpf.clone());
                            columnas.addAll((Vector)tmpc.clone());
                            almacenar(palabras[z],Integer.parseInt(tmpf.firstElement().toString()),Integer.parseInt(tmpc.firstElement().toString()),"diagonal_izquierda_arriba");
                            tmpf.removeAllElements();tmpc.removeAllElements();
                        }
                    }else{
                        index=0;
                        tmpf.removeAllElements();tmpc.removeAllElements();
                    }
                }
                //  rd
                index=0;
                for(int j=0;j<myGui.array.length && (j+i)<myGui.array[0].length;j++){
                    if(myGui.array[j][j+i].equalsIgnoreCase(String.valueOf(palabras[z].charAt(index++)))){
                        tmpf.addElement(j);
                        tmpc.addElement(j+i);
                        if(index==palabras[z].length()){
                            index=0;
                            filas.addAll((Vector)tmpf.clone());
                            columnas.addAll((Vector)tmpc.clone());
                            almacenar(palabras[z],Integer.parseInt(tmpf.firstElement().toString()),Integer.parseInt(tmpc.firstElement().toString()),"diagonal_derecha_abajo");
                            tmpf.removeAllElements();tmpc.removeAllElements();
                        }
                    }else{
                        index=0;
                        tmpf.removeAllElements();tmpc.removeAllElements();
                    }
                }
                //  ld
                index=0;
                for(int j=0;j<myGui.array.length && (j+i)<myGui.array[0].length;j++){
                    if(myGui.array[j][myGui.array[0].length-1-(j+i)].equalsIgnoreCase(String.valueOf(palabras[z].charAt(index++)))){
                        tmpf.addElement(j);
                        tmpc.addElement(myGui.array[0].length-1-(j+i));
                        if(index==palabras[z].length()){
                            index=0;
                            filas.addAll((Vector)tmpf.clone());
                            columnas.addAll((Vector)tmpc.clone());
                            almacenar(palabras[z],Integer.parseInt(tmpf.firstElement().toString()),Integer.parseInt(tmpc.firstElement().toString()),"diagonal_izquierda_abajo");
                            tmpf.removeAllElements();tmpc.removeAllElements();
                        }
                    }else{
                        index=0;
                        tmpf.removeAllElements();tmpc.removeAllElements();
                    }
                }
            }
            //recorriendo la parte de los lados de la matriz
            for(int i=0;i<myGui.array.length;i++){
                //  lado izquierdo: ru,rd
                //  ru
                int index=0;
                for(int j=0;(myGui.array.length-1-(j+i))>=0 && j<myGui.array[0].length;j++){
                    if(myGui.array[myGui.array.length-1-(j+i)][j].equalsIgnoreCase(String.valueOf(palabras[z].charAt(index++)))){
                        tmpf.addElement(myGui.array.length-1-(j+i));
                        tmpc.addElement(j);
                        if(index==palabras[z].length()){
                            index=0;
                            filas.addAll((Vector)tmpf.clone());
                            columnas.addAll((Vector)tmpc.clone());
                            almacenar(palabras[z],Integer.parseInt(tmpf.firstElement().toString()),Integer.parseInt(tmpc.firstElement().toString()),"diagonal_derecha_arriba");
                            tmpf.removeAllElements();tmpc.removeAllElements();
                        }
                    }else{
                        index=0;
                        tmpf.removeAllElements();tmpc.removeAllElements();
                    }
                }
                //  rd
                index=0;
                for(int j=0;(j+i)<myGui.array.length && j<myGui.array[0].length;j++){
                    if(myGui.array[j+i][j].equalsIgnoreCase(String.valueOf(palabras[z].charAt(index++)))){
                        tmpf.addElement(j+i);
                        tmpc.addElement(j);
                        if(index==palabras[z].length()){
                            index=0;
                            filas.addAll((Vector)tmpf.clone());
                            columnas.addAll((Vector)tmpc.clone());
                            almacenar(palabras[z],Integer.parseInt(tmpf.firstElement().toString()),Integer.parseInt(tmpc.firstElement().toString()),"diagonal_derecha_abajo");
                            tmpf.removeAllElements();tmpc.removeAllElements();
                        }
                    }else{
                        index=0;
                        tmpf.removeAllElements();tmpc.removeAllElements();
                    }
                }
                //  lado derecho: lu,ld
                //  lu
                index=0;
                for(int j=0;(myGui.array.length-1-j-i)>=0 && myGui.array[0].length-1-j>=0;j++){
                    if(myGui.array[myGui.array.length-1-j-i][myGui.array[0].length-1-j].equalsIgnoreCase(String.valueOf(palabras[z].charAt(index++)))){
                        tmpf.addElement(myGui.array.length-1-j-i);
                        tmpc.addElement(myGui.array[0].length-1-j);
                        if(index==palabras[z].length()){
                            index=0;
                            filas.addAll((Vector)tmpf.clone());
                            columnas.addAll((Vector)tmpc.clone());
                            almacenar(palabras[z],Integer.parseInt(tmpf.firstElement().toString()),Integer.parseInt(tmpc.firstElement().toString()),"diagonal_izquierda_arriba");
                            tmpf.removeAllElements();tmpc.removeAllElements();
                        }
                    }else{
                        index=0;
                        tmpf.removeAllElements();tmpc.removeAllElements();
                    }
                }
                //  ld
                index=0;
                for(int j=0;(j+i)<myGui.array.length && (myGui.array[0].length-1-j)>=0;j++){
                    if(myGui.array[j+i][myGui.array[0].length-1-j].equalsIgnoreCase(String.valueOf(palabras[z].charAt(index++)))){
                        tmpf.addElement(j+i);
                        tmpc.addElement(myGui.array[0].length-1-j);
                        if(index==palabras[z].length()){
                            index=0;
                            filas.addAll((Vector)tmpf.clone());
                            columnas.addAll((Vector)tmpc.clone());
                            almacenar(palabras[z],Integer.parseInt(tmpf.firstElement().toString()),Integer.parseInt(tmpc.firstElement().toString()),"diagonal_izquierda_abajo");
                            tmpf.removeAllElements();tmpc.removeAllElements();
                        }
                    }else{
                        index=0;
                        tmpf.removeAllElements();tmpc.removeAllElements();
                    }
                }
            }
        }
        
        myGui.reportar("Se ha completado las busquedas");
    }

    /**
     * almacena informacion para guardarla en el archivo '.res' cuando ya este lista
     * @param palabra la palabra a buscar
     * @param fila la fila a buscar
     * @param col la columna a buscar
     * @param on la forma de busqueda
     */
    private void almacenar(String palabra, int fila, int col, String on) {
        texto.append("SEARCH #"+palabra+"# WHERE ROW="+(fila+1)+" AND COLUMN="+(col+1)+" ON "+on);
        texto.append(";\n");
    }

    /**
     * instancia algunos array para no hacer referencia tantas veces a la clase principal
     */
    private void instanciar() {
        row=new int[myGui.row.size()];
        column=new int[myGui.column.size()];
        on=new String[myGui.on.size()];
        palabras=new String[myGui.palabras.size()];
        for(int i=0;i<myGui.on.size();i++){
            row[i]=(Integer.parseInt(myGui.row.elementAt(i).toString()))-1;
            column[i]=(Integer.parseInt(myGui.column.elementAt(i).toString()))-1;
            on[i]=myGui.on.elementAt(i).toString();
            palabras[i]=myGui.palabras.elementAt(i).toString();
        }
    }
    
    /**
     * Genera el archivo de salida '.res' tomando la informacion de un JTextArea invisible
     */
    public void generar() {
        myGui.reportar("Generando \'salida.res\'");
        File archivo=new File("salida.res");
        try{
            PrintWriter out = new PrintWriter(new FileWriter(archivo));
            out.print(texto.getText());
            out.close();
        }catch(Exception e){
            new Tool().mensaje(null, e, "No se pudo guardar", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        myGui.reportar("\'salida.res\' ha sido generado");
    }

}
