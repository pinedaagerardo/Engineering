/*
 * File:   WriterSerial.cpp
 * Author: darkcronosgt
 *
 * Created on May 8, 2011, 10:48 PM
 */

#define _MULTI_THREADED
#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <unistd.h>
#include <errno.h>
#include <string>
#include <fstream>
#include <string.h>
#include <sys/sem.h>
#include <pthread.h>
#include <iostream>
#include <sstream>
#include <fcntl.h>   /* Archivo para control de definiciones */
#include <termios.h> /* POSIX terminal control definitions */
#include <sys/shm.h>
#define cls()			printf( "\033[H\033[J" )

using namespace std;

int machineId = 0;
int existPrinter = 0; // 1 - Si, 2 - No
char fileName[256] = "";
int commandId = 0;

struct file {
    int file_id;
    int pc_id;
    char file_name[256];
    file *next;
};


file *indices_file;

void agregarArchivo(int file_id, int pc_id, const char *file_name) {
    if (indices_file == NULL) {
        indices_file = (struct file *) malloc(sizeof (struct file));
        indices_file->file_id = file_id;
        indices_file->pc_id = pc_id;
        strcpy(indices_file->file_name, file_name);
        indices_file->next = NULL;
    } else {
        file *tmpClienteFile = (struct file *) malloc(sizeof (struct file));
        tmpClienteFile->file_id = file_id;
        tmpClienteFile->pc_id = pc_id;
        strcpy(tmpClienteFile->file_name, file_name);
        tmpClienteFile->next = NULL;
        file *tmp = indices_file;
        while (tmp->next != NULL) {
            tmp = tmp->next;
        }
        tmp->next = tmpClienteFile;
    }
}

file *buscarArchivo(int file_id, int pc_id) {
    if (indices_file == NULL) {
        //printf("No a cargado datos aun en memoria, se abortara este tipo de busqueda.\n");
        return NULL;
    }
    file *tmp = indices_file;
    while (tmp != NULL) {
        if (tmp->file_id == file_id && tmp->pc_id == pc_id) {
            return tmp;

        }
        tmp = tmp->next;
    }
    return NULL;
}


struct sembuf sb = {0, -1, 0};
pid_t pid;
vector<file> filesList;
int fileCorrelativeKey = 0;
int pc1 = 0;
int pc2 = 0;
int pc3 = 0;

typedef struct tmp_msgbuf {
    long mtype;
    char paquete[1025];
} message_serial;

typedef struct msgbufs {
    long mtype;
    char mtext[1024];
    char file_name[128];
    int doc_id;
    int type; /* 1 - File Name Metadata, 2 - File Content, 3 - File end, 4 - Normal msg,
                5 - ID, 6 - dir -7 print, 8 - Type*/
    long size;
    int source;
    int dest;
} message_buf;

typedef struct data_sctruct {
    int command;
    int source;
    int dest;
    int msg_id;
    int long1; /* 1 - File Name Metadata, 2 - File Content, 3 - File end, 4 - Normal msg,
                5 - ID, 6 - dir -7 print, 8 - Type*/
    int long2;
    int status;
    char content1[1015];
    char content2[1015];
    char content[1025];
} data_buf;

string convert(double value) {
    std::stringstream out;
    out << value;
    return out.str();
}

string convert(long value) {
    std::stringstream out;
    out << value;
    return out.str();
}

string convert(char *value) {
    std::stringstream out;
    out << value;
    return out.str();
}

string convert(int value) {
    std::stringstream out;
    out << value;
    return out.str();
}

string convert(size_t value) {
    std::stringstream out;
    out << value;
    return out.str();
}

void cleanChar(char *clean, int len) {
    for (int c = 0; c < len; c++) {
        clean[c] = '\0';
    }
}

void extractChar(char *dest, const char *source, int posini, int posfin) {
    int pos = 0;
    for (int c = posini; c < posfin; c++) {
        dest[pos] = source[c];
        pos = pos + 1;
    }
    //printf("Se llenaron : %i \n", pos);
}

file getFileName(int file_id, int pc_id, char *fileName) {
    printf(" [%i]  -  [%i]  -  [%s] - {%i}\n", file_id, pc_id, fileName, filesList.size());
    char *returnFileName;
    bool exist = false;
    for (int c = 0; c < filesList.size(); c++) {
        if (filesList.at(c).file_id == file_id && filesList.at(c).pc_id == pc_id) {
            //returnFileName=filesList.at(c).file_name;
            return filesList.at(c);
            //printf("Restoring filename -->\n");
            //exist = true;
            //break;
        }
    }

    if (!exist) {
        file newFile;
        newFile.file_id = file_id;
        returnFileName = fileName;
        strcpy(newFile.file_name, fileName);
        //printf("Saving filename --> %s\n",newFile.file_name);
        newFile.pc_id = pc_id;
        filesList.push_back(newFile);
        return newFile;
        //filesList.push_back(newFile);
        //printf("Saving filename --> %s {%i} \n",newFile.file_name,filesList.size());
    }
    //printf("Writing to file --> %s\n",returnFileName);
    //return returnFileName;
}

bool getFileName(char *fileName) {
    for (int c = 0; c < filesList.size(); c++) {
        if (strcmp(filesList.at(c).file_name, fileName) == 0) return true;
    }
    return false;
}

int generateFileId(char *fileName) {
    file newFile;
    int id = 0;
    if (!getFileName(fileName)) {
        fileCorrelativeKey = fileCorrelativeKey + 1;
        newFile.file_id = fileCorrelativeKey;
        strcpy(newFile.file_name, fileName);
        filesList.push_back(newFile);
        return fileCorrelativeKey;
    }
    return id;
}

void sendMessageOut(key_t msgKey, const char *msg) {
    int direccion;
    int msgflg = 0666;
    if ((direccion = msgget(msgKey, msgflg)) < 0) {
        perror("semget");
        exit(1);
    }
    message_serial package;
    package.mtype = 1;
    cleanChar(package.paquete, 1025);
    extractChar(package.paquete, msg, 0, 1025);
    if (strlen(package.paquete) > 1025)
        package.paquete[1024] = '\0';
    if (msgsnd(direccion, &package, sizeof (package), IPC_NOWAIT) < 0) {
        perror("msgsnd");
    }
}

void sendMessageSerial(key_t msgKey, char *msg) {
    int direccion = -2;
    int msgflg = 0666;
    if ((direccion = msgget(msgKey, msgflg)) < 0) {
        perror("semget");
        exit(1);
    }
    message_serial paquete;
    paquete.mtype = 1;
    cleanChar(paquete.paquete, 1025);
    strcpy(paquete.paquete, msg);
    //printf("\nTrying to write to queue: %i\n", direccion);
    if (msgsnd(direccion, &paquete, sizeof (paquete), IPC_NOWAIT) < 0) {
        perror("msgsnd");
    }
    //printf("Cool, it was done successfully.\n");
}

message_buf receiveMessageOut(key_t msgKey) {
    int direccion;
    int msgflg = 0666;
    if ((direccion = msgget(msgKey, msgflg)) < 0) {
        perror("semget");
        exit(1);
    }
    message_buf ssbufe;
    if (msgrcv(direccion, &ssbufe, sizeof (ssbufe), 1, 0) < 0) {
        perror("msgrcv");
    }
    return ssbufe;
}

data_buf receiveMessageSerial(key_t msgKey) {
    int direccion;
    if ((direccion = msgget(msgKey, 0666)) < 0) {
        perror("semget");
        exit(1);
    }
    message_serial package;
    if (msgrcv(direccion, &package, sizeof (package), 1, 0) < 0) {
        perror("msgrcv");
    }

    data_buf pack_received;
    char tmpBlock[4];
    char tmpBlockUnique[1];
    cleanChar(pack_received.content, 1025);
    cleanChar(pack_received.content1, 1015);
    cleanChar(pack_received.content2, 1015);
    //printf("Trying to get 3\n");
    tmpBlockUnique[0] = package.paquete[0];
    //printf("Trying to get 4\n");
    //0] =  tmpBlockUnique[0];
    //printf("Trying to get 5\n");
    pack_received.command = atoi(tmpBlockUnique);
    //printf("Trying to get 6\n");
    tmpBlockUnique[0] = package.paquete[1];
    //printf("Trying to get 7\n");
    pack_received.source = atoi(tmpBlockUnique);
    //printf("Trying to get 8\n");
    tmpBlockUnique[0] = package.paquete[2];
    //printf("Trying to get 9\n");
    pack_received.dest = atoi(tmpBlockUnique);
    //printf("Trying to get 10\n");
    extractChar(tmpBlock, package.paquete, 3, 7);
    //printf("Trying to get 11\n");
    pack_received.msg_id = atoi(tmpBlock);
    //printf("Trying to get 12\n");
    extractChar(tmpBlock, package.paquete, 7, 11);
    //printf("Trying to get 13\n");
    int tmpSizeBlock = atoi(tmpBlock);
    //printf("Trying to get 14\n");
    pack_received.long1 = tmpSizeBlock;
    //printf("Trying to get 15\n");
    extractChar(tmpBlock, package.paquete, 11, 15);
    //printf("Trying to get 16\n");
    tmpSizeBlock = atoi(tmpBlock);
    //printf("Trying to get 17\n");
    pack_received.long2 = tmpSizeBlock;
    //printf("Trying to get 18\n");
    tmpBlockUnique[0] = package.paquete[15];
    //printf("Trying to get 19\n");
    pack_received.status = atoi(tmpBlockUnique);
    //printf("Trying to get 20\n");
    if (pack_received.long1 > 0 && pack_received.status != 3) {
        extractChar(pack_received.content1, package.paquete, 16, 16 + pack_received.long1);
        pack_received.content1[16 + pack_received.long1] = '\0';
        //printf("Trying to get 21\n");
    } else {
        cleanChar(pack_received.content1, 1015);
        pack_received.content1[0] = '\0';
        //printf("Trying to get 22\n");
    }
    if (pack_received.long2 > 0) {
        extractChar(pack_received.content2, package.paquete, 16 + pack_received.long1, 16 + pack_received.long1 + pack_received.long2);
        //printf("Trying to get 23\n");
    } else {
        cleanChar(pack_received.content2, 1015);
        pack_received.content2[0] = '\0';
        //printf("Trying to get 24\n");
    }
    if (pack_received.command == ((pack_received.command / 1000) * 1000)) {
        pack_received.command = pack_received.command / 1000;
    }
    if (pack_received.command > 1999 && pack_received.command < 2999) {
        pack_received.command = 2;
    } else if (pack_received.command > 2999 && pack_received.command < 3999) {
        pack_received.command = 3;
    } else if (pack_received.command > 3999 && pack_received.command < 4999) {
        pack_received.command = 4;
    } else if (pack_received.command > 4999 && pack_received.command < 5999) {
        pack_received.command = 5;
    } else if (pack_received.command > 5999 && pack_received.command < 6999) {
        pack_received.command = 6;
    }

    if (pack_received.status > 9999 && pack_received.status < 19999) {
        pack_received.status = 1;
    } else if (pack_received.status > 19999 && pack_received.status < 29999) {
        pack_received.status = 2;
    } else if (pack_received.status > 29999 && pack_received.status < 39999) {
        pack_received.status = 3;
    }
    //printf("Trying to get 25\n");
    cleanChar(pack_received.content, 1025);
    //printf("Trying to get 26\n");
    //extractChar(pack_received.content, package.paquete,0,1025);
    strcpy(pack_received.content, package.paquete);
    //printf("Trying to get 27\n");
    //printf("Command -> %i\n", pack_received.command);
    //printf("Source  -> %i\n", pack_received.source);
    //printf("Destine -> %i\n", pack_received.dest);
    //printf("Id Msg  -> %i\n", pack_received.msg_id);
    //printf("Long1   -> %i\n", pack_received.long1);
    //printf("Long1   -> %i\n", pack_received.long2);
    //printf("Status  -> %i\n", pack_received.status);
    //printf("...Done, continuing.\n");
    return pack_received;
}

void downSem(key_t semKey) {
    int mutex;
    if ((mutex = semget(semKey, 1, 0)) == -1) {
        perror("semget");
        exit(1);
    }
    if (semop(mutex, &sb, 1) == -1) {
        perror("semop");
        exit(1);
    }
}

void upSem(key_t semKey) {
    int mutex;

    if ((mutex = semget(semKey, 1, 0)) == -1) {
        perror("semget");
        exit(1);
    }
    sb.sem_op = 1; /* liberar recurso */
    if (semop(mutex, &sb, 1) == -1) {
        perror("semop");
        exit(1);
    }
}

int change_queue_mode(int qid, int size) {
    struct msqid_ds info;
    msgctl(qid, IPC_STAT, &info);
    info.msg_qbytes = size;
    msgctl(qid, IPC_SET, &info);
    return (0);
}

/*
void copyFile(char *files_data[1][2]) {
    char fileName[strlen(files_data[0][0]) + 5];
    //strcpy(fileName, "/tmp/");
    strcpy(fileName, files_data[0][0]);
    //ofstream f(fd);
    //char *tmpname = strdup(fileName);
    ofstream outFile;
    outFile.open(fileName, ofstream::out | ofstream::app); //opens the file for binary output
    outFile.write(files_data[0][1], strlen(files_data[0][1]));
    outFile.close();
    pthread_exit(NULL);
}
 */

void copyFile(char *dest, char bufferStream[]) {
    char fileName[strlen(dest) + 5];
    strcpy(fileName, dest);
    ofstream outFile;
    outFile.open(fileName, ofstream::out | ofstream::app); //opens the file for binary output
    outFile.write(bufferStream, strlen(bufferStream));
    outFile.close();

}

void insertCommand(char *bufferStream, const char *command) {
    strcat(bufferStream, command);
}

void insertSource(char *bufferStream, const char *source) {
    strcat(bufferStream, source);
}

void insertDest(char *bufferStream, const char *dest) {
    strcat(bufferStream, dest);
    //bufferStream[2] = dest;
}

void insertIDMsg(char *bufferStream, const char *id) {
    int lastPos = 0;
    for (int c = 0; c < (4 - strlen(id)); c++) {
        lastPos = 3 + c;
        bufferStream[lastPos] = '0';
    }
    strcat(bufferStream, id);
}

void insertLength(char *bufferStream, const char *length, int pos) {
    int lastPos = 0;
    for (int c = 0; c < (4 - strlen(length)); c++) {
        lastPos = pos + c;
        bufferStream[lastPos] = '0';
    }
    strcat(bufferStream, length);
}

void insertStatus(char *bufferStream, const char *status) {
    strcat(bufferStream, status);
}

void fillRestChar(char *bufferStream, const char status, int length) {
    int pos = strlen(bufferStream);
    int final = length - pos;
    for (int c = 0; c < final; c++) {
        bufferStream[pos] = ' ';
        pos = pos + 1;
    }
    if (strlen(bufferStream) > 1025) {
        bufferStream[1025] = '\0';
    }
}

long fileSize(char *fileName) {
    long begin, end;
    ifstream myfile(fileName);
    begin = myfile.tellg();
    myfile.seekg(0, ios::end);
    end = myfile.tellg();
    myfile.close();
    return (end - begin);
}

union semun {
    int val;
    struct semid_ds *buf;
    ushort *array;
};

/*void addLine(string line, int mode) {
    if (mode == 1) {
        ofstream myfile("factura.txt", ios::in|ios::trunc);
        if (myfile.is_open()) {
            myfile << "---------------------------------------------\n";
            myfile.close();
        } else cout << "Unable to open file";
    } else {
        ofstream myfile("factura.txt", ios::in|ios::app);
        if (myfile.is_open()) {
            myfile << line << "\n";
            myfile.close();
        } else cout << "Unable to open file";
    }

}*/

int main(int argc, char** argv) {
    key_t receiverStreamKey = 123456;
    key_t sendStreamKey = 123456 + 1;
    key_t serialKey = 123456 + 9;
    key_t fileStreamKey = 123456 + 3;
    key_t memKey = 654321 + 21;
    int msqid;
    int id_mem;
    int *contador = NULL;
    int msgflg = IPC_CREAT | 0666;
    char msg[10];
    char buffer[1025];
    char smsHeader[16];
    printf("Por Favor, indique el ID de la PC que agregara a la red (numero entero): "); //LE QUITE COMENTARIOS
    //string caracter = "2";
    string caracter = "";
    getline(cin, caracter); //LE QUITE COMENTARIOS
    std::istringstream iss(caracter.c_str());
    iss >> machineId;
    id_mem = shmget(memKey, sizeof (int) *100, 0777 | IPC_CREAT);
    if (id_mem == -1) {
        perror("Error en shmget - no se creo la memoria");
        exit(1);
    }
    filesList.clear();
    //Asiganamos al puntero entero la memoria creada
    contador = (int *) shmat(id_mem, (char *) 0, 0);
    if (contador == NULL) {
        perror("No se pudo asignar la memoria compartida");
        exit(1);
    }
    contador[0] = machineId;
    contador[1] = 0;
    cleanChar(msg, 10);
    if ((msqid = msgget(receiverStreamKey, msgflg)) < 0) {
        perror("msgget");
    }
    if ((msqid = msgget(sendStreamKey, msgflg)) < 0) {
        perror("msgget");
    }
    if ((msqid = msgget(fileStreamKey, msgflg)) < 0) {
        perror("msgget");
    }
    /*
    if ((msqid = msgget(serialKey, 0666)) < 0) {
        perror("msgget");
    }
     */
    int continuar = 1;
    data_buf sbufe;
    while (continuar == 1) {
        printf(".\n");
        sleep(1);
        sbufe = receiveMessageSerial(receiverStreamKey);
        //printf("Received [%s] from %i", sbufe.content,sbufe.dest);
        if (sbufe.dest != machineId && sbufe.dest != 0) {
            //if (sbufe.dest != machineId) {
            printf("\nNo es para esta maquina, Redireccionando el mensaje a la pc %i", sbufe.dest);
            sendMessageSerial(serialKey, sbufe.content);
            //printf("\nNo es para esta maquina, Redireccionando el mensaje a la pc %i", sbufe.dest);
        } else if (sbufe.command == 1) {
            printf("\nCliente [%i] dice: > %s\n", sbufe.source, sbufe.content1);
        } else if (sbufe.command == 8) {
            //printf("client [%i] says > %s\n", sbufe.source, sbufe.content1);
            //YO COMENTE ESTO:
            //            string line;
            //            line =  "";
            //            line.append(sbufe.content1);
            //            //COMENTADOaddLine(line, 2);
            //            //COMENTADOaddLine("---------------------------------------------", 2);
            //            //addLine(line, 2);
            //            cls();
            //            ifstream myReadFile;
            //            myReadFile.open("factura.txt");
            //            line = "";
            //            if (myReadFile.is_open()) {
            //                while (!myReadFile.eof()) {
            //                     getline (myReadFile,line);
            //                     cout << line << endl;
            //                    //myReadFile >> output;
            //                    //cout << output;
            //                }
            //            }
            //            myReadFile.close();
        } else if (sbufe.command == 2) {
            if (sbufe.status == 1) {
                agregarArchivo(sbufe.msg_id, sbufe.source, sbufe.content2);
            } else if (sbufe.status == 2) {
                file *tmpFile = buscarArchivo(sbufe.msg_id, sbufe.source);
                copyFile(tmpFile->file_name, sbufe.content1);
            } else if (sbufe.status == 3) {
                file *tmpFile = buscarArchivo(sbufe.msg_id, sbufe.source);
                printf("Se termino de recibir archivo --> %s de la maquina [%i].\n", tmpFile->file_name, sbufe.source);
                string response = "Archivo recibido satisfactoriamente.";
                cleanChar(buffer, 1025);
                cleanChar(smsHeader, 16);
                insertCommand(smsHeader, convert(1).c_str());
                insertSource(smsHeader, convert(sbufe.dest).c_str());
                insertDest(smsHeader, convert(sbufe.source).c_str());
                insertIDMsg(smsHeader, convert(contador[1]).c_str());
                insertLength(smsHeader, convert(response.size()).c_str(), 7);
                insertLength(smsHeader, convert(0).c_str(), 11);
                insertStatus(smsHeader, convert(1).c_str());
                strcat(buffer, smsHeader);
                strcat(buffer, response.c_str());
                //strcat(buffer,tokens.at(5).c_str());
                fillRestChar(buffer, '0', 1025);
                //sendMessageOut(receiverStreamKey,tokens.at(1).c_str(),"", 0, 4, 0,contador[0],atoi(tokens.at(3).c_str()));
                sendMessageOut(receiverStreamKey, buffer);

            }
            //sendMessageOut(sendStreamKey, "received", strlen(sbufe.mtext), 5);
        } else if (sbufe.command == 3) {
            if (sbufe.status == 1) {
                printf("Cliente [%i] type > %s\n", sbufe.source, sbufe.content1);
            } else if (sbufe.status == 2) {
                printf("%s\n", sbufe.content1);
            } else if (sbufe.status == 3) {
                printf("----------------------------------------------------------------\n");
            }

        } else if (sbufe.command == 4) {
            if (sbufe.status == 1) {
                agregarArchivo(sbufe.msg_id, sbufe.source, "tmpPrintFile.txt");
            } else if (sbufe.status == 2) {
                file *tmpFile = buscarArchivo(sbufe.msg_id, sbufe.source);
                copyFile(tmpFile->file_name, sbufe.content1);
            } else if (sbufe.status == 3) {
                file *tmpFile = buscarArchivo(sbufe.msg_id, sbufe.source);
                char cmd[250];
                cleanChar(cmd, 250);
                strcpy(cmd, "lpr ");
                strcat(cmd, tmpFile->file_name);
                system(cmd);
                printf("\nClient [%i] print el archivo --> %s", sbufe.source, tmpFile->file_name);
            }

        } else if (sbufe.command == 5) {
            if (sbufe.status == 1) {
                printf("Cliente [%i] dir > %s\n", sbufe.source, sbufe.content1);
            } else if (sbufe.status == 2) {
                printf("%s\n", sbufe.content1);
            } else if (sbufe.status == 3) {
                printf("----------------------------------------------------------------\n");
            }
        }
    }
    return (EXIT_SUCCESS);
}