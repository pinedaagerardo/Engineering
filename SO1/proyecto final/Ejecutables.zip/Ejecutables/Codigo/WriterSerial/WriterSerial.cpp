/* 
 * File:   WriterSerial.cpp
 * Author: darkcronosgt
 *
 * Created on May 13, 2011, 10:48 PM
 */

#include <termios.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#include "SerialPort.h"
//#include "comunicacion_serial/cola_mensajes/cola_mensajes.h"
//#include "comunicacion_serial/semaforo/semaforo.h"

/*
 Descripcion del MSJ:
 * Digito 1: palabra reservada que se esta utilizando
 * Digito 2: id maquina origen en la red
 * Digito 3: id maquina destino en la red
 * Digito 4 - 7: indentificadores del mensaje
 * Digito 8 - ...: indican el largo de la linea que se lee.
 * Este ultimo va incrementando dependiendo de que tan extenso sea el archivo.
 */

using namespace std;
//------------------
//-- CONSTANTES
//------------------

//--TIMEOUT en segundos

typedef struct tmp_msgbuf{
  long mtype;
  char paquete[1025];
}message_serial;

#define TIMEOUT 2
void emisor(void);
int serial_fd; //-- Descriptor puerto serial

/**********************/
/*  MAIN PROGRAM      */

/**********************/
int main(int argc, char* argv[]) {
    char puerto[10]=""; //-- Puerto a usar
    //Asignamos que puerto serial vamos a abrir
    strcpy(puerto, "/dev/ttyS0");
    //Asignamos el puerto serial pero con el cable USB-SERIAL
    //strcpy(puerto, "/dev/ttyUSB0");
    //-- Abre el puerto serial
    //-- Se configura la velocidad del puerto a 9600 baudios
    serial_fd = abrir_puerto(puerto, B9600);
    //serial_fd = abrir_puerto(puerto, B1200);
    //-- Chequeo de puerto
    if (serial_fd == -1) {
        printf("Error al abrir el puerto: %s\n", puerto);
        perror("Abierto");
        exit(0);
    } else {
        printf("Puerto abierto exitosamente.\n");
    }
    emisor();
    //-- Cierra el puerto serial
    cerrar_puerto(serial_fd);
    return 0;
}

void emisor() {
    cout << "Emisor: " << PC << ": \n";
    fflush(stdout);
    int msqid;
    //Key de la cola
    //Generamos la cola de mensajes
    if ((msqid = msgget(123456 + 9, 0666 | IPC_CREAT)) < 0) {
        perror("msgget"); //Informa si hay q error
        exit(1);
    }
    while (1) {
        message_serial Paquete;
        //semaforo_bloqueado();
        if (msgrcv(msqid, &Paquete, sizeof (Paquete), 0, 0) == -1) {
            perror("msgrcv\n"); //Informamos si existe un error
            exit(1);
        }
        //-- Muestra el dato Recibido
        if (strlen(Paquete.paquete)==1024){
            enviar(serial_fd, Paquete.paquete, 1025);
            //Se esta enviando el paquete
            cout << "Enviando paquete..." << endl;
        }
        printf("mensaje: %s",Paquete.paquete);
        cout<<endl;
        //fflush(stdout);
        //-- Envia mensaje al puerto serial
        //semaforo_desbloqueado();
        sleep(1);
    }
}