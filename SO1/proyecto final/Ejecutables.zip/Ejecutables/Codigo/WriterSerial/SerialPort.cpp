/* 
 * File:   SerialPort.cpp
 * Author: singleroot
 *
 * Created on January 6, 2010, 10:50 PM
 */

#include "SerialPort.h"
/*
 *
 */
/******************************************************************************/
/* Abre Puerto Serial                                                         */
/*----------------------------------------------------------------------------*/
/* Entrada:                                                                   */
/*   -serial_name: Nombre Dispositivo Serial                                  */
/*   -baud: Velocidad del Dispositivo                                         */
/*                                                                            */
/******************************************************************************/
int abrir_puerto(char *nombre_puerto, speed_t baudios)
{
  struct termios newtermios;
  int fd;
  // Abre puerto serial
  fd = open(nombre_puerto,O_RDWR | O_NOCTTY);
  // Configura atributo puerto serial:
  //   -- No parity
  //   -- 8 data bits
  //   -- otros valores...
  newtermios.c_cflag= CBAUD | CS8 | CLOCAL | CREAD;
  newtermios.c_iflag=IGNPAR;
  newtermios.c_oflag=0;
  newtermios.c_lflag=0;
  newtermios.c_cc[VMIN]=1;
  newtermios.c_cc[VTIME]=0;
  // Agregamos velocidad
  cfsetospeed(&newtermios,baudios);
  cfsetispeed(&newtermios,baudios);
  // Limpia el buffer de entrada
  if (tcflush(fd,TCIFLUSH)==-1) {
    return -1;
  }
  // Limpia el buffer de salida
  if (tcflush(fd,TCOFLUSH)==-1) {
    return -1;
  }
  //-- Configura el puerto Serial!!
  if (tcsetattr(fd,TCSANOW,&newtermios)==-1) {
    return -1;
  }
  //-- Retorna el descriptor
  return fd;
}
/*****************************************************/
/* Envia un String al puerto serial.                 */
/*                                                   */
/* Entrada:                                          */
/*   -serial_fd: Descripcio Dispositivo Serial       */
/*   -data:      Envia el String                     */
/*   -size:      Longitud del String                 */
/*****************************************************/
void enviar(int serial_fd, char *data, int size)
{
  write(serial_fd, data, size);
}
/*************************************************************************/
/* Recibe informacion del Puerto Serial                                  */
/*-----------------------------------------------------------------------*/
/* Entrada:                                                              */
/*   -serial_fd: Descripcion Dispositivo Serial                          */
/*   -size: Maximo de datos a Recibir                                    */
/*   -timeout_usec: Tiempo destinado a recibir el Dato                   */
/*                                                                       */
/* Salida:                                                               */
/*   -data: Recibe el dato del puerto serial                             */
/*                                              (n bytes)                */
/* Retorna:                                                              */
/*   -El numero de bytes recibidos.                                      */
/*   -Si es cero es porque no recibio nada!                              */
/*************************************************************************/
int leer(int serial_fd, char *data, int size, int timeout_usec)
{
  fd_set fds;
  struct timeval timeout;
  int count=0;
  int ret;
  int n;
  timeout_usec=timeout_usec*1000000;
  //-- Espera por el dato.
  do {
      //-- Variable fds a esperar por el puerto serial
      FD_ZERO(&fds);
      FD_SET (serial_fd, &fds);
      //-- Configuracion tiempo de espera.
      timeout.tv_sec = 0;
      timeout.tv_usec = timeout_usec;
      //-- Espera por data
      ret=select (FD_SETSIZE,&fds, NULL, NULL,&timeout);
    //-- Si estos son datos espera y lee el puerto
      if (ret==1) {
        //-- Lee el data (n bytes)
        n=read (serial_fd, &data[count], size-count);
        //-- El numero de bytes lo incrementa a uno
        count+=n;
        //-- El ultimo byte es siempre 0 (para imprimir el string)
        data[count]=0;
      }
    //-- Repeti el ciclo hasta que el byte fue recibido o el tiempo de espera termino
  } while (count<size && ret==1);
  //-- Retorna el numero de bytes leidos. 0 si el tiempo de espera se termino
  return count;
}
/********************************************************************/
/* Cierra el puerto Serial                                          */
/*------------------------------------------------------------------*/
/* Entrada:                                                         */
/*   fd: Descripcion del puerto Serial                              */
/********************************************************************/
void cerrar_puerto(int fd)
{
  close(fd);
}