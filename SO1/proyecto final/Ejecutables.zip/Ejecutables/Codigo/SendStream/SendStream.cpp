/*
 * File:   WriterSerial.cpp
 * Author: darkcronosgt
 *
 * Created on May 10, 2011, 10:48 PM
 */

#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include <iostream>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/sem.h>
#include <pthread.h>
#include <string>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string.h>

#define cls()			printf( "\033[H\033[J" )
#define position(row,col)	printf( "\033[%d;%dH", (row), (col) )
#define position_flush(row,col)	printf( "\033[%d;%dH\n", (row), (col) )

using namespace std;

int commandId = 0;

typedef struct msgbufs {
    long mtype;
    char mtext[1025];
    char file_name[128];
    int doc_id;
    int type; /*1 - File Name Metadata, 2 - File Content, 3 - File end, 4 - Normal msg,
               * 5 - ID, 6 - dir -7 print, 8 - Type*/
    long size;
    int source;
    int dest;
} message_buf;

typedef struct data_sctruct {
    int command;
    int source;
    int dest;
    int msg_id;
    int long1; /* 1 - File Name Metadata, 2 - File Content, 3 - File end, 4 - Normal msg,
                * 5 - ID, 6 - dir -7 print, 8 - Type*/
    int long2;
    int status;
    char *content1;
    char *content2;
} data_buf;

typedef struct tmp_msgbuf {
    long mtype;
    char paquete[1025];
} message_serial;

string convert(double value) {
    std::stringstream out;
    out << value;
    return out.str();
}

string convert(long value) {
    std::stringstream out;
    out << value;
    return out.str();
}

string convert(char *value) {
    std::stringstream out;
    out << value;
    return out.str();
}

string convert(int value) {
    std::stringstream out;
    out << value;
    return out.str();
}

string convert(size_t value) {
    std::stringstream out;
    out << value;
    return out.str();
}

void cleanChar(char *clean, int len) {
    for (int c = 0; c < len; c++) {
        clean[c] = '\0';
    }
}

void extractChar(char *dest, const char *source, int posini, int posfin) {
    int pos = 0;
    for (int c = posini; c < posfin; c++) {
        dest[pos] = source[c];
        pos = pos + 1;
    }
}

void cpChar(char *dest, const char *source, int leng) {
    //int pos = 0;
    for (int c = 0; c < leng; c++) {
        dest[c] = source[c];
        //pos = pos + 1;
    }
}

void sendMessageOut(key_t msgKey, const char *msg) {
    int direccion;
    int msgflg = 0666;
    if ((direccion = msgget(msgKey, msgflg)) < 0) {
        perror("semget");
        exit(1);
    }
    message_serial package;
    package.mtype = 1;
    cleanChar(package.paquete, 1025);
    cpChar(package.paquete, msg,1025);
    //extractChar(package.paquete, msg, 0, 1025);
    if (strlen(package.paquete) > 1025)
        for (int c=1024;c<strlen(package.paquete);c++)
            package.paquete[c] = '\0';
    //strcpy(package.paquete, msg);
    /*
    message_buf sbufe;
    sbufe.mtype = 1;
    cleanChar(sbufe.mtext, 1024);
    cleanChar(sbufe.file_name, 128);
    strcpy(sbufe.mtext, msg);
    strcpy(sbufe.file_name, name);
    sbufe.doc_id = doc;
    sbufe.type = type;
    sbufe.size = size;
    sbufe.source = source;
    sbufe.dest = dest;
     */
    if (msgsnd(direccion, &package, sizeof (package), IPC_NOWAIT) < 0) {
        perror("msgsnd");
    }
}

void insertCommand(char *bufferStream, const char *command) {
    strcat(bufferStream, command);
}

void insertSource(char *bufferStream, const char *source) {
    strcat(bufferStream, source);
}

void insertDest(char *bufferStream, const char *dest) {
    strcat(bufferStream, dest);
    //bufferStream[2] = dest;
}

void insertIDMsg(char *bufferStream, const char *id) {
    int lastPos = 0;
    for (int c = 0; c < (4 - strlen(id)); c++) {
        lastPos = 3 + c;
        bufferStream[lastPos] = '0';
    }
    strcat(bufferStream, id);

}

void insertLength(char *bufferStream, const char *length, int pos) {
    int lastPos = 0;
    for (int c = 0; c < (4 - strlen(length)); c++) {
        lastPos = pos + c;
        bufferStream[lastPos] = '0';
    }
    strcat(bufferStream, length);

}

void insertStatus(char *bufferStream, const char *status) {
    strcat(bufferStream, status);
}

void fillRestChar(char *bufferStream, const char status, int length) {
    int pos = strlen(bufferStream);
    int final = length - pos;
    for (int c = 0; c < final; c++) {
        bufferStream[pos] = ' ';
        pos = pos + 1;
    }
    if (strlen(bufferStream) > 1025) {
        bufferStream[1025] = '\0';
    }
}

message_buf receiveMessageOut(key_t msgKey) {
    int direccion;
    int msgflg = 0666;
    if ((direccion = msgget(msgKey, msgflg)) < 0) {
        perror("semget");
        exit(1);
    }
    message_buf ssbufe;
    if (msgrcv(direccion, &ssbufe, sizeof (ssbufe), 1, 0) < 0) {
        perror("msgrcv");
    }
    return ssbufe;
}

int change_queue_mode(int qid, int size) {
    struct msqid_ds info;
    msgctl(qid, IPC_STAT, &info);
    info.msg_qbytes = size;
    msgctl(qid, IPC_SET, &info);
    return (0);
}

void copyFile(char *dest, char bufferStream[]) {
    ofstream outFile;
    outFile.open(dest, ios::out | ios::app); //opens the file for binary output
    outFile.write(bufferStream, strlen(bufferStream));
    outFile.close();
}

long fileSize(const char *fileName) {
    long begin, end;
    ifstream myfile(fileName);
    begin = myfile.tellg();
    myfile.seekg(0, ios::end);
    end = myfile.tellg();
    myfile.close();
    return (end - begin);
}

void Tokenize(const string& str, vector<string>& tokens, const string& delimiters = " ") {
    string::size_type lastPos = str.find_first_not_of(delimiters, 0);
    string::size_type pos = str.find_first_of(delimiters, lastPos);
    while (string::npos != pos || string::npos != lastPos) {
        tokens.push_back(str.substr(lastPos, pos - lastPos));
        lastPos = str.find_first_not_of(delimiters, pos);
        pos = str.find_first_of(delimiters, lastPos);
    }
}

using std::cout;
using std::cin;
using std::endl;

using namespace std;
// just creating a constant for the name of the database
//static const char *DATABASE_FILE = "db.dat";

// the data that will go into the database
string convert(float value){
    std::string s;
    std::stringstream out;
    out << value;
    return out.str();
}

/*struct Inventario {
    int codigo;
    char nombre[50];
    int existencia;
    float precio;
};*/

// this function takes a pointer to a Person struct
// that will be filled with the data in the file
//NO CREO QUE SIRVA PARA MIS FINES xD
/*void addLine(string line, int mode) {
    if (mode == 1) {
        ofstream myfile("factura.txt", ios::in|ios::trunc);
        if (myfile.is_open()) {
            myfile << "---------------------------------------------\n";
            myfile.close();
        } else cout << "Unable to open file";
    } else {
        ofstream myfile("factura.txt", ios::in|ios::app);
        if (myfile.is_open()) {
            myfile << line << "\n";
            myfile.close();
        } else cout << "Unable to open file";
    }

}*/

//NO ME SIRVE!!!
/*bool LoadDB(Inventario *per) {
    // first parameter is the name of the file
    // second is the open flags.
    //    `in` says you will read from the file
    //    `binary` says you will read binary data instead of simple text
    std::ifstream fin(DATABASE_FILE, ios_base::in | ios_base::binary);

    // if we couldn't open the file (it may not exist); fail
    if (!fin.is_open())
        return false;

    // the file is open; tell the read function to look at `per` as a
    // char pointer instead of a Person pointer so that `fin` can place
    // one byte at a time into the struct
    // the second parameter tells read() how many bytes to read
    // Note: do not use the ">>" operator to read from a binary file
    while (fin.read((char*) per, sizeof (Inventario))) {
        cout << "Loaded Database...\n";
        cout << "Codigo     = " << per->codigo << endl;
        cout << "Nombe      = " << per->nombre << endl;
        cout << "Existencia = " << per->existencia << endl;
        cout << "Precio     = " << per->precio << endl;
        cout << endl;
    }

    fin.close(); // close the file - not necessary, but we should be neat

    // success
    return true;
}*/



// this function takes a pointer to a Person struct
// that will be written into the file
//NO SIRVE
/*bool SaveDB(Inventario *per) {
    // these flags say:
    //    `out` - we will be writing data into the file
    //    `binary` - we will be writing binary data and not simple text
    //    `trunc` - if the file already exists, truncate (wipe out) the existing data
    std::ofstream fout(DATABASE_FILE, ios_base::out | ios_base::binary | ios_base::trunc);
    // couldn't open it (disk error?); fail
    if (!fout.is_open())
        return false;

    // notice this time we cast the Person pointer to a const char* because we aren't
    // altering the structure this time; rather we're just looking at it's contents.

    fout.write((const char*) per, sizeof (Inventario));
    fout.close(); // close the file - not necessary, but we should be neat

    // success
    return true;
}*/

/* Write a new record to the file at the current position */
/*void writerecord(Inventario *precord) {
    std::ofstream fout(DATABASE_FILE, ios_base::out | ios_base::binary | ios_base::app);
    // couldn't open it (disk error?); fail
    if (!fout.is_open())
        return;

    // notice this time we cast the Person pointer to a const char* because we aren't
    // altering the structure this time; rather we're just looking at it's contents.
    fout.write((const char*) precord, sizeof (Inventario));
    fout.close();
}*/

/*float actualizar(ios::pos_type posicion, Inventario *curr, int cantidad, int tipo) {
    float result = 0;
    Inventario inv;
    fstream myFile(DATABASE_FILE, ios::in | ios::out | ios::binary);
    myFile.seekp(posicion);
    inv.codigo = curr->codigo;
    strcpy(inv.nombre, curr->nombre);
    inv.precio = curr->precio;
    if (tipo == 1) {
        inv.existencia = curr->existencia + cantidad;
    } else {
        if ((curr->existencia - cantidad) >= 0) {
            inv.existencia = curr->existencia - cantidad;
            result = cantidad * curr->precio;
            string line = "";
            line = "Total factura: ";
            line.append(convert(result));
            addLine(line,2);
        } else {
            string line = "";
            line = "Total factura: ";
            line.append("No aplica, la existencia de producto es insuficiente.");
            addLine(line,2);
            result = -1;
        }

    }
    myFile.write((char*) &inv, sizeof (Inventario));
    //cout << "Done." <<  endl;
    myFile.close();
    return result;
}*/

/*float comprar(int codigo, int cantidad) {
    float result = 0;
    Inventario inv;
    ios::pos_type posicion = -1;
    fstream myFile(DATABASE_FILE, ios::in | ios::out | ios::binary);
    myFile.seekg(0);
    string line = "";
    while (!myFile.eof()) {
        myFile.read((char*) &inv, sizeof (Inventario));
        if (inv.codigo == codigo) {
            line = "Producto: ";
            line.append(inv.nombre);
            addLine(line,2);
            line = "Precio: ";
            line.append(convert(inv.precio));
            addLine(line,2);
            break;
        }
        posicion = myFile.tellg();
        myFile.seekg(posicion);
    }

    myFile.close();
    result = actualizar(posicion, &inv, cantidad, 2);
    //if (result==0){

    //}
    return result;
}*/

/*void comprarProducto(int codigo, int cantidad) {
    Inventario *inv;
    ifstream inbook(DATABASE_FILE, ios_base::in | ios_base::binary);
    ofstream outbook(DATABASE_FILE, ios_base::out | ios_base::binary | ios_base::app);
    while (!inbook.eof()) {
        inbook.read((char*) inv, sizeof (Inventario));
        //cout << "Reading: "<< inv->codigo << endl;
        if (inv->codigo == codigo) {
            outbook.seekp(SEEK_CUR);
            outbook.write((char*) inv, sizeof (Inventario));
            break;
        }
    }
}*/


/*
void facturar() {
    key_t receiverStreamKey = 123456;
    char nit[20];
    char nombre[100];
    char direccion[200];
    int codigo;
    int cantidad;
    cout << "Nit: ";
    (cin >> nit).get();
    cout << "Nombre: ";
    cin.getline(nombre, 100);
    //(cin >> nombre).get();
    cout << "Direccion: ";
    cin.getline(direccion, 200);
    //(cin >> direccion).get();
    cout << "Codigo producto: ";
    (cin >> codigo).get();
    cout << "Cantidad: ";
    (cin >> cantidad).get();

    ////////////
    char smsHeader[16];
    char buffer[1025];
    commandId = commandId + 1;
    string theSMS = "";
    theSMS.append(convert(codigo));
    theSMS.append(" ");
    theSMS.append(convert(cantidad));
    cleanChar(buffer, 1025);
    cleanChar(smsHeader, 16);
    insertCommand(smsHeader, convert(9).c_str());
    insertSource(smsHeader, "2");
    insertDest(smsHeader, "1");
    insertIDMsg(smsHeader, convert(commandId).c_str());
    insertLength(smsHeader, convert(theSMS.size()).c_str(), 7);
    insertLength(smsHeader, convert(0).c_str(), 11);
    insertStatus(smsHeader, convert(1).c_str());
    strcat(buffer, smsHeader);
    strcat(buffer, theSMS.c_str());
    fillRestChar(buffer, '0', 1025);
    sendMessageOut(receiverStreamKey, buffer);
    ////////////
    addLine("", 1);
    //cout << "---------------------------------------------" << endl;

    string line = "";
    line = "Nit: ";
    line.append(nit);
    addLine(line, 2);
    //cout << "Nit: " << nit << endl;
    //cout << "Nombre: " << nombre << endl;
    line = "Nombre: ";
    line.append(nombre);
    addLine(line, 2);
    //cout << "Direccion: " << direccion << endl;
    line = "Direccion: ";
    line.append(direccion);
    addLine(line, 2);
    //cout << "Codigo: " << codigo << endl;
    line = "Codigo: ";
    line.append(convert(codigo));
    addLine(line, 2);
}*/


/////////////////////////

int main(int argc, char** argv) {
    key_t receiverStreamKey = 123456;
    key_t fileStreamKey = 123456 + 3;
    char buffer[1025];
    char buffer_line[1025];
    char smsHeader[16];
    int id_mem;
    int *contador = NULL;
    key_t memKey = 654321 + 21;
    char fileName[128];
    id_mem = shmget(memKey, sizeof (int) *100, 0777);
    if (id_mem == -1) {
        perror("Error en shmget - no se creo la memoria");
        exit(1);
    }
    //Asignamos al puntero entero la memoria creada
    contador = (int *) shmat(id_mem, (char *) 0, 0);
    if (contador == NULL) {
        perror("No se pudo asignar la memoria compartida");
        exit(1);
    }
    while (true) {
        printf("localhost[%i]#: ", contador[0]);
        //sleep(2);
        string caracter = "";
        getline(cin, caracter);//LE QUITE COMENTARIOS
        printf("\n");
        //ESTO NO ME VA A SERVIR facturar();
        sleep(2);
       vector<string> tokens;//ACA VOY A MODIFICAR
        //string str(line);//QUITE LOS COMENTARIOS
        Tokenize(caracter, tokens, " ");
        //cout << "Codigo    : " << tokens.at(0) << endl;
        if (strcmp(tokens.at(0).c_str(), "sadsa") == 0) {
            printf("\nEnviando archivo...");
            strcpy(fileName, argv[2]);
            ifstream inFile(fileName);
            // -->sendMessageOut(receiverStreamKey, fileName, fileName, 1, 1, 0);
            int fileId = 1;
            int sended = 0;
            int counter = 0;
            while (!inFile.eof()) //if not at end of file, continue reading numbers
            {
                cleanChar(buffer, 1025);
                inFile.read(buffer, 1020);
                position(5, 5);
                counter = counter + 1;
                printf("[%i] Enviando %i bytes\n", counter, (strlen(buffer) + 4));
                // -->sendMessageOut(receiverStreamKey, buffer, fileName, fileId, 2, 0);
                sended = sended + 1;
                if (sended == 1) {
                    printf(".");
                    sleep(1);
                    sended = 0;
                }
            }
            inFile.clear();
            cleanChar(buffer, 1025);
            // -->sendMessageOut(receiverStreamKey, buffer, fileName, fileId, 3, fileSize(fileName));
            message_buf sbufe = receiveMessageOut(fileStreamKey);
            printf("\nServidor dice: > El archivo %s %s .", fileName, sbufe.mtext);
        } else if (strcmp(tokens.at(0).c_str(), "send") == 0) {
            commandId = commandId + 1;
            //send "Hola por alli amiguito" to 1
            //Tokenize(caracter, tokens, " ");
            int laspos = caracter.find_last_of("\"");
            int inipos = caracter.find_first_of("\"");
            string theMachine = caracter.substr(laspos + 5, 1);
            string theSMS = caracter.substr(inipos + 1, (laspos - inipos) - 1);
            cleanChar(buffer, 1025);
            cleanChar(smsHeader, 16);
            insertCommand(smsHeader, convert(1).c_str());
            insertSource(smsHeader, convert(contador[0]).c_str());
            insertDest(smsHeader, theMachine.c_str());
            insertIDMsg(smsHeader, convert(commandId).c_str());
            insertLength(smsHeader, convert(theSMS.size()).c_str(), 7);
            insertLength(smsHeader, convert(0).c_str(), 11);
            insertStatus(smsHeader, convert(1).c_str());
            strcat(buffer, smsHeader);
            strcat(buffer, theSMS.c_str());
            //strcat(buffer,tokens.at(5).c_str());
            fillRestChar(buffer, '0', 1025);
            //sendMessageOut(receiverStreamKey,tokens.at(1).c_str(),"", 0, 4, 0,contador[0],atoi(tokens.at(3).c_str()));
            sendMessageOut(receiverStreamKey, buffer);
            //printf("\nEl mensaje %s fue enviado exitosamente.", argv[2]);
        } else if (strcmp(tokens.at(0).c_str(), "copy") == 0) {
            commandId = commandId + 1;
            //sendMessageOut(key_t msgKey, const char *msg, char *name, int doc, int type, long size, int source, int dest)
            cleanChar(buffer, 1025);
            cleanChar(smsHeader, 16);
            insertCommand(smsHeader, convert(2).c_str());
            insertSource(smsHeader, tokens.at(1).c_str());
            insertDest(smsHeader, tokens.at(4).c_str());
            insertIDMsg(smsHeader, convert(commandId).c_str());
            insertLength(smsHeader, convert(tokens.at(2).size()).c_str(), 7);
            insertLength(smsHeader, convert(tokens.at(5).size()).c_str(), 11);
            insertStatus(smsHeader, convert(1).c_str());
            strcat(buffer, smsHeader);
            strcat(buffer, tokens.at(2).c_str());
            strcat(buffer, tokens.at(5).c_str());
            fillRestChar(buffer, '0', 1025);

            sendMessageOut(receiverStreamKey, buffer);
            //Now... send the message to start the copy file... just metadata, the contents comes next
            ifstream inFile(tokens.at(2).c_str());
            // -->sendMessageOut(receiverStreamKey, fileName, fileName, 1, 1, 0);
            int sended = 0;
            int counter = 0;
            cleanChar(buffer, 1025);
            while (!inFile.eof()) { //if not at end of file, continue reading numbers
                cleanChar(buffer_line, 1025);
                inFile.read(buffer_line, (1025 - 16));
                cleanChar(buffer, 1025);
                cleanChar(smsHeader, 16);
                insertCommand(smsHeader, convert(2).c_str());
                insertSource(smsHeader, tokens.at(1).c_str());
                insertDest(smsHeader, tokens.at(4).c_str());
                insertIDMsg(smsHeader, convert(commandId).c_str());
                insertLength(smsHeader, convert(strlen(buffer_line)).c_str(), 7);
                insertLength(smsHeader, convert(0).c_str(), 11);
                insertStatus(smsHeader, convert(2).c_str());
                strcat(buffer, smsHeader);
                strcat(buffer, buffer_line);
                fillRestChar(buffer, '0', 1025);
                counter = counter + 1;
                sendMessageOut(receiverStreamKey, buffer);
                sended = sended + 1;
                if (sended == 1) {
                    sleep(1);
                    sended = 0;
                }
            }
            inFile.clear();
            cleanChar(buffer, 1025);
            cleanChar(smsHeader, 16);
            insertCommand(smsHeader, convert(2).c_str());
            insertSource(smsHeader, tokens.at(1).c_str());
            insertDest(smsHeader, tokens.at(4).c_str());
            insertIDMsg(smsHeader, convert(commandId).c_str());
            insertLength(smsHeader, convert(fileSize(tokens.at(2).c_str())).c_str(), 7);
            insertLength(smsHeader, convert(0).c_str(), 11);
            insertStatus(smsHeader, convert(3).c_str());
            strcat(buffer, smsHeader);
            strcat(buffer, convert(fileSize(tokens.at(2).c_str())).c_str());
            fillRestChar(buffer, '0', 1025);
            sendMessageOut(receiverStreamKey, buffer);
        } else if (strcmp(tokens.at(0).c_str(), "type") == 0) {
            ifstream inFile(tokens.at(2).c_str());
            //type 1 dfa.txt to 1
            commandId = commandId + 1;
            //sendMessageOut(key_t msgKey, const char *msg, char *name, int doc, int type, long size, int source, int dest)
            cleanChar(buffer, 1025);
            cleanChar(smsHeader, 16);
            insertCommand(smsHeader, convert(3).c_str());
            insertSource(smsHeader, tokens.at(1).c_str());
            insertDest(smsHeader, tokens.at(4).c_str());
            insertIDMsg(smsHeader, convert(commandId).c_str());
            insertLength(smsHeader, convert(tokens.at(2).size()).c_str(), 7);
            insertLength(smsHeader, convert(0).c_str(), 11);
            insertStatus(smsHeader, convert(1).c_str());
            strcat(buffer, smsHeader);
            strcat(buffer, tokens.at(2).c_str());
            //strcat(buffer,tokens.at(5).c_str());
            fillRestChar(buffer, '0', 1025);
            sendMessageOut(receiverStreamKey, buffer);
            int sended = 0;
            int counter = 0;
            while (!inFile.eof()) { //if not at end of file, continue reading numbers
                cleanChar(buffer_line, 1025);
                inFile.read(buffer_line, (1025 - 16));
                cleanChar(buffer, 1025);
                cleanChar(smsHeader, 16);
                insertCommand(smsHeader, convert(3).c_str());
                insertSource(smsHeader, tokens.at(1).c_str());
                insertDest(smsHeader, tokens.at(4).c_str());
                insertIDMsg(smsHeader, convert(commandId).c_str());
                insertLength(smsHeader, convert(strlen(buffer_line)).c_str(), 7);
                insertLength(smsHeader, convert(0).c_str(), 11);
                insertStatus(smsHeader, convert(2).c_str());
                strcat(buffer, smsHeader);
                strcat(buffer, buffer_line);
                fillRestChar(buffer, '0', 1025);
                counter = counter + 1;
                sendMessageOut(receiverStreamKey, buffer);
                sended = sended + 1;
                if (sended == 1) {
                    sleep(1);
                    sended = 0;
                }
            }
            inFile.close();
            cleanChar(buffer, 1025);
            cleanChar(smsHeader, 16);
            insertCommand(smsHeader, convert(3).c_str());
            insertSource(smsHeader, tokens.at(1).c_str());
            insertDest(smsHeader, tokens.at(4).c_str());
            insertIDMsg(smsHeader, convert(commandId).c_str());
            insertLength(smsHeader, convert(0).c_str(), 7);
            insertLength(smsHeader, convert(0).c_str(), 11);
            insertStatus(smsHeader, convert(3).c_str());
            strcat(buffer, smsHeader);
            fillRestChar(buffer, '0', 1025);
            counter = counter + 1;
            sendMessageOut(receiverStreamKey, buffer);
        } else if (strcmp(tokens.at(0).c_str(), "print") == 0) {
            //print 1 dfa.txt to 1


            ifstream inFile(tokens.at(2).c_str());
            //type 1 dfa.txt to 1
            commandId = commandId + 1;
            //sendMessageOut(key_t msgKey, const char *msg, char *name, int doc, int type, long size, int source, int dest)
            cleanChar(buffer, 1025);
            cleanChar(smsHeader, 16);
            insertCommand(smsHeader, convert(4).c_str());
            insertSource(smsHeader, tokens.at(1).c_str());
            insertDest(smsHeader, tokens.at(4).c_str());
            insertIDMsg(smsHeader, convert(commandId).c_str());
            insertLength(smsHeader, convert(tokens.at(2).size()).c_str(), 7);
            insertLength(smsHeader, convert(0).c_str(), 11);
            insertStatus(smsHeader, convert(1).c_str());
            strcat(buffer, smsHeader);
            strcat(buffer, tokens.at(2).c_str());
            //strcat(buffer,tokens.at(5).c_str());
            fillRestChar(buffer, '0', 1025);
            sendMessageOut(receiverStreamKey, buffer);
            int sended = 0;
            int counter = 0;
            while (!inFile.eof()) { //if not at end of file, continue reading numbers
                cleanChar(buffer_line, 1025);
                inFile.read(buffer_line, (1025 - 16));
                cleanChar(buffer, 1025);
                cleanChar(smsHeader, 16);
                insertCommand(smsHeader, convert(4).c_str());
                insertSource(smsHeader, tokens.at(1).c_str());
                insertDest(smsHeader, tokens.at(4).c_str());
                insertIDMsg(smsHeader, convert(commandId).c_str());
                insertLength(smsHeader, convert(strlen(buffer_line)).c_str(), 7);
                insertLength(smsHeader, convert(0).c_str(), 11);
                insertStatus(smsHeader, convert(2).c_str());
                strcat(buffer, smsHeader);
                strcat(buffer, buffer_line);
                fillRestChar(buffer, '0', 1025);
                counter = counter + 1;
                sendMessageOut(receiverStreamKey, buffer);
                sended = sended + 1;
                if (sended == 1) {
                    sleep(1);
                    sended = 0;
                }
            }
            inFile.close();
            cleanChar(buffer, 1025);
            cleanChar(smsHeader, 16);
            insertCommand(smsHeader, convert(4).c_str());
            insertSource(smsHeader, tokens.at(1).c_str());
            insertDest(smsHeader, tokens.at(4).c_str());
            insertIDMsg(smsHeader, convert(commandId).c_str());
            insertLength(smsHeader, convert(0).c_str(), 7);
            insertLength(smsHeader, convert(0).c_str(), 11);
            insertStatus(smsHeader, convert(3).c_str());
            strcat(buffer, smsHeader);
            fillRestChar(buffer, '0', 1025);
            counter = counter + 1;
            sendMessageOut(receiverStreamKey, buffer);
        } else if (strcmp(tokens.at(0).c_str(), "dir") == 0) {
            //dir 1 /home to 1
            commandId = commandId + 1;
            cleanChar(buffer, 1025);
            cleanChar(smsHeader, 16);
            insertCommand(smsHeader, convert(5).c_str());
            insertSource(smsHeader, tokens.at(1).c_str());
            insertDest(smsHeader, tokens.at(4).c_str());
            insertIDMsg(smsHeader, convert(commandId).c_str());
            insertLength(smsHeader, convert(tokens.at(2).size()).c_str(), 7);
            insertLength(smsHeader, convert(0).c_str(), 11);
            insertStatus(smsHeader, convert(1).c_str());
            strcat(buffer, smsHeader);
            strcat(buffer, tokens.at(2).c_str());
            fillRestChar(buffer, '0', 1025);
            sendMessageOut(receiverStreamKey, buffer);
            char cmd[250];
            cleanChar(cmd, 250);
            strcpy(cmd, "ls ");
            strcat(cmd, tokens.at(2).c_str());
            strcat(cmd, " -la > tmp.txt");
            system(cmd);
            sleep(2);
            ifstream inFile("tmp.txt");
            int sended = 0;
            int counter = 0;
            // -->sendMessageOut(receiverStreamKey, fileName, fileName, 1, 1, 0);
            while (!inFile.eof()) { //if not at end of file, continue reading numbers
                if (inFile.is_open()){
                    cleanChar(buffer_line, 1025);
                    inFile.read(buffer_line, (1025 - 16));

                }
                cleanChar(buffer, 1025);
                cleanChar(smsHeader, 16);
                insertCommand(smsHeader, convert(5).c_str());
                insertSource(smsHeader, tokens.at(1).c_str());
                insertDest(smsHeader, tokens.at(4).c_str());
                insertIDMsg(smsHeader, convert(commandId).c_str());
                insertLength(smsHeader, convert(strlen(buffer_line)).c_str(), 7);
                insertLength(smsHeader, convert(0).c_str(), 11);
                insertStatus(smsHeader, convert(2).c_str());
                strcat(buffer, smsHeader);
                strcat(buffer, buffer_line);
                fillRestChar(buffer, '0', 1025);
                counter = counter + 1;
                sendMessageOut(receiverStreamKey, buffer);
                sended = sended + 1;
                if (sended == 1) {
                    sleep(1);
                    sended = 0;
                }
            }
            inFile.close();
            cleanChar(buffer, 1025);
            cleanChar(smsHeader, 16);
            insertCommand(smsHeader, convert(5).c_str());
            insertSource(smsHeader, tokens.at(1).c_str());
            insertDest(smsHeader, tokens.at(4).c_str());
            insertIDMsg(smsHeader, convert(commandId).c_str());
            insertLength(smsHeader, convert(0).c_str(), 7);
            insertLength(smsHeader, convert(0).c_str(), 11);
            insertStatus(smsHeader, convert(3).c_str());
            strcat(buffer, smsHeader);
            fillRestChar(buffer, '0', 1025);
            counter = counter + 1;
            sendMessageOut(receiverStreamKey, buffer);
        } else if (strcmp(tokens.at(0).c_str(), "exit") == 0) {
            exit(1);
        }
    }
    if (argc < 2) {
        printf("\nEnvio de mensajes serial v1.0");
        return 0;
    }
    return (EXIT_SUCCESS);
}