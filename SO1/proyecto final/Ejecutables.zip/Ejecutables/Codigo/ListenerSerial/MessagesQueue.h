/* 
 * File:   MessagesQueue.h
 * Author: singleroot
 *
 * Created on January 4, 2010, 10:21 PM
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <errno.h>
#include <sys/sem.h>
#include <unistd.h>

#ifndef _MESSAGESQUEUE_H
#define	_MESSAGESQUEUE_H

#define archivo "cola"
#define clave_archivo 33
// Estructura para enviar cola mensajes
struct Tipo_Mensaje
{
 long Id_Mensaje;
 int Dato_Numerico;
 char Mensaje[1024];
}Mensaje;

key_t Clave;
int Id_Cola_Mensajes;

/*--------------------------------------*/
/* FUNCIONES MANEJO DE COLA DE MENSAJES */
/*--------------------------------------*/

void creaColaEmisor();
void EnviaColaEmisor(int n, char * msg);
void CerrarColaEmisor();
char * RecibeColaEmisor(int n);

void creaColaEmisor(){

   //Obtenemos clave del archivo
   Clave = ftok (archivo, clave_archivo);

   //Crea la cola de Mensajes
   Id_Cola_Mensajes = msgget (Clave, 0600 | IPC_CREAT);
   //printf("Cola Mensajes creada %d\n",Id_Cola_Mensajes);
}

void EnviaColaEmisor(int n, char * msg){
   //Obtenemos clave del archivo estado
   Clave = ftok (archivo, clave_archivo);
   // Se rellenan los campos del mensaje que se quiere enviar.
   Mensaje.Id_Mensaje = n;
   Mensaje.Dato_Numerico = 2;
   strcpy (Mensaje.Mensaje, msg);

   // Se envia el mensaje.
   msgsnd (Id_Cola_Mensajes, (struct msgbuf *)&Mensaje, sizeof(Mensaje.Dato_Numerico)+sizeof(Mensaje.Mensaje), IPC_NOWAIT);
}

void CerrarColaEmisor(){
   msgctl (Id_Cola_Mensajes, IPC_RMID, (struct msqid_ds *)NULL);
}

char * RecibeColaEmisor(int n){
   //Recibe mensaje
   msgrcv (Id_Cola_Mensajes, (struct msgbuf *)&Mensaje, sizeof(Mensaje.Dato_Numerico) + sizeof(Mensaje.Mensaje), n, 0);
   return Mensaje.Mensaje;
}



#endif	/* _MESSAGESQUEUE_H */

