/*
 * File:   WriterSerial.cpp
 * Author: darkcronosgt
 *
 * Created on May 8, 2011, 10:48 PM
 */

#include <stdlib.h>
#include <termios.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include "SerialPort.h"
#include "MessagesQueue.h"

using namespace std;
//------------------
//-- CONSTANTES
//------------------

//--TIMEOUT en segundos
#define TIMEOUT 2

typedef struct tmp_msgbuf {
    long mtype;
    char paquete[1025];
} message_serial;

bool check(char *clean){
    bool result = false;
    int cont = 0;
    for (int c = 0; c < 100; c++) {
        if (clean[c] == '\0'){
            cont = cont + 1;
        }
    }
    if (cont>60){
        result = true;
    }
    return result;
}
void cleanChar(char *clean, int len) {
    for (int c = 0; c < len; c++) {
        clean[c] = '\0';
    }
}

void sendMessageSerialToQueue(key_t msgKey, char *msg) {
    int direccion = -2;
    if ((direccion = msgget(msgKey, 0666)) < 0) {
        perror("semget");
        exit(1);
    }
    message_serial paquete;
    paquete.mtype = 1;
    cleanChar(paquete.paquete, 1025);
    strcpy(paquete.paquete, msg);
    if (strlen(paquete.paquete) > 1025)
        paquete.paquete[1024] = '\0';
    printf("Esta en cola");
    //printf("\nTrying to write to queue: %i {%i}\n", direccion, strlen(paquete.paquete));
    if (msgsnd(direccion, &paquete, sizeof (paquete), IPC_NOWAIT) < 0) {
        perror("msgsnd");
    }
    else{
        //printf("\nTrying to write to queue: %i {%i}\n", direccion, strlen(paquete.paquete));
    }
}

/**********************/
/*  MAIN PROGRAM      */

/**********************/
int main(int argc, char* argv[]) {
    int serial_fd; //-- Descriptor puerto serial
    char data[1025]=""; //-- Recibe data
    char puerto[11]; //-- Puerto a usar


    //Asignamos que puerto serial
    //strcpy(puerto, "/dev/ttyS0");
    //Asignamos el puerto serial pero con el cable USB-SERIAL
    strcpy(puerto, "/dev/ttyUSB0");

    /*Abre el puerto serial
    Se configura la velocidad del puerto a 9600 baudios*/
    serial_fd = abrir_puerto(puerto, B9600);
    //serial_fd = abrir_puerto(puerto, B1200);
    //serial_fd = abrir_puerto(puerto, B115200);

    //-- Chequeo de puerto
    if (serial_fd == -1) {
        printf("Error al abrir el puerto: %s\n", puerto);
        perror("Abierto");
        exit(0);
    } else {
        printf("Puerto abierto exitosamente.\n");
    }
    //Aca debe ir el numero de la PC
    //printf("%s # \n", PC);
    fflush(stdout);
    while (1) {
        //-- Espera a recibir dato
        int n;
        //printf("Esperando informacion%s...\n",data);
        n = leer(serial_fd, data, 1025, TIMEOUT);
        if (n > 40) {
            //-- Muestra el dato Recibido
            printf("Intentando Enviar a: %s ...",data);
            if (!check(data)){
                printf("_1%s",data);
                sendMessageSerialToQueue(123456, data);
                printf(" Enviado....");
                printf("_2%s",data);
            }else{
                printf(" No se envio....\n");
            }
            //printf ("%s # ",PC);
            //fflush(stdout);
            //printf ("%s (%d bytes)\n",data,n);
        } else {
            //Se acabo tiempo de espera
        }
    }
    //-- Cierra el puerto serial
    cerrar_puerto(serial_fd);
    return 0;
}