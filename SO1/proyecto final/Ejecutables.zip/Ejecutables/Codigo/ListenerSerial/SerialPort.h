/* 
 * File:   SerialPort.h
 * Author: singleroot
 *
 * Created on January 4, 2010, 10:17 PM
 */
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>


#ifndef _SERIALPORT_H
#define	_SERIALPORT_H

//CONSTANTES
#define PC       "PC1"
#define NO_PC 1

/*-----------------------------*/
/* FUNCIONES MANEJO DE PUERTOS */
/*-----------------------------*/

int  abrir_puerto(char *serial_name, speed_t baud);
void enviar(int serial_fd, char *data, int size);
int  leer(int serial_fd, char *data, int size, int timeout_usec);
void cerrar_puerto(int fd);


#endif	/* _SERIALPORT_H */

