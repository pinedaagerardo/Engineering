/*
 * Main.java
 *
 * Created on 15 de abril de 2007, 01:54 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package juegos;

/**
 *
 * @author ONIXX
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Menu menu=new Menu();
        menu.setVisible(true);
    }
    
}
